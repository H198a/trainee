//
//  HomeVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 06/03/25.
//

import UIKit
import CoreData

class HomeVC: UIViewController {
//MARK: IBOutlet and Variable Declaration
    @IBOutlet weak var homeTblView: UITableView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var TblView: UITableView!
    @IBOutlet weak var sideView: UIView!
    @IBOutlet weak var LblAvilbleBalance: UILabel!
    var totalAmount = 0.0
    
    var transactions: [(title: String, date: Date, amount: Double, imageName: String, currency: String, colorView: UIColor, type: Int32, isDelete: Bool)] = []
    private var sideViewIsOpen = false
    
    var nameArr = ["Records","Bank Sync","Imports","Reciepts","Tags","Cards","Set Budget","CVV","Lists","Settings"]
    var imgArr = ["Records","Bank Sync","Imports","Reciepts","Tags","Cards","Set Budget","CVV","Lists","Settings"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchTransactions()
        homeTblView.backgroundColor = .clear
        sideView.isHidden = true
        TblView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        homeTblView.register(UINib(nibName: "TableViewCellHome", bundle: nil), forCellReuseIdentifier: "TableViewCellHome")

        let swipeLeftGesture = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipeLeft))
           swipeLeftGesture.direction = .left
           view.addGestureRecognizer(swipeLeftGesture)
           
           // Optionally, you can add a swipe gesture to open the side view from left swipe too
           let swipeRightGesture = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipeRight))
           swipeRightGesture.direction = .right
           view.addGestureRecognizer(swipeRightGesture)

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchTransactions()
        navigationController?.setNavigationBarHidden(true, animated: true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
  
    @objc func handleSwipeLeft() {
           // Handle swipe left (to close the side view)
           if sideViewIsOpen {
               closeSideView()
           }
       }

       @objc func handleSwipeRight() {
           // Handle swipe right (to open the side view)
           if !sideViewIsOpen {
               openSideView()
           }
       }
    @IBAction func SideViewBtn(_ sender: Any) {
        toggleSideView()
    }
    
    @IBAction func PlusBtnClick(_ sender: Any) {
        let incomeVC = self.storyboard?.instantiateViewController(withIdentifier: "IncomeVC") as! IncomeVC
        self.navigationController?.pushViewController(incomeVC , animated: true)
    }
}
//MARK: Custom Funciton
extension HomeVC{
    func toggleSideView() {
        if sideViewIsOpen {
            closeSideView()
        } else {
            openSideView()
        }
    }
    
    func openSideView() {
        // Animate the side view to appear
        sideView.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.sideView.frame.origin.x = 0 // Move sideView to its original position
        }) { _ in
            self.sideViewIsOpen = true
        }
    }
    
    func closeSideView() {
        // Animate the side view to slide out
        UIView.animate(withDuration: 0.3, animations: {
            self.sideView.frame.origin.x = -self.sideView.frame.width // Move sideView out of the screen
        }) { _ in
            self.sideView.isHidden = true
            self.sideViewIsOpen = false
        }
    }
    func fetchTransactions() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        transactions.removeAll()
        totalAmount = 0.0

        let incomeFetch: NSFetchRequest<Income> = Income.fetchRequest()
        let expenseFetch: NSFetchRequest<Expense> = Expense.fetchRequest()

        // Only fetch non-deleted transactions
        incomeFetch.predicate = NSPredicate(format: "isDeletedData == %@", NSNumber(value: false))
        //NSNumber is used to cinvert true false into premitive into NSNumber object because NSPredicate uses NSNumber  object to filter data from coredata
        expenseFetch.predicate = NSPredicate(format: "isDeletedData == %@", NSNumber(value: false))

        do {
            let incomeResults = try context.fetch(incomeFetch)
            let expenseResults = try context.fetch(expenseFetch)

            // Process income transactions
            for income in incomeResults {
                let title = income.title ?? ""
                let date = income.date ?? Date()
                let amountString = Double(income.amount ?? "") ?? 0.0
                let imageName = income.image ?? "defaultImage"
                let currency = income.currency ?? ""
                let newType = income.type
                let newColorView = ViewBackgroundColor.shared.hexStringToUIColor(hex: income.viewColor ?? "")
                transactions.append((title: title, date: date, amount: amountString, imageName: imageName, currency: currency, colorView: newColorView, type: newType, isDelete: false))
                totalAmount += amountString
            }

            // Process expense transactions
            for expense in expenseResults {
                let title = expense.title ?? ""
                let date = expense.date ?? Date()
                let amountString = Double(expense.amount ?? "") ?? 0.0
                let imageName = expense.image ?? "defaultImage"
                let currency = expense.currency ?? ""
                let newType = expense.type
                let newColorView = ViewBackgroundColor.shared.hexStringToUIColor(hex: expense.viewColor ?? "")
                transactions.append((title: title, date: date, amount: -amountString, imageName: imageName, currency: currency, colorView: newColorView, type: newType, isDelete: false))
                totalAmount -= amountString
            }

            transactions.sort { $0.date > $1.date }

            DispatchQueue.main.async {
                self.homeTblView.reloadData()
                self.LblAvilbleBalance.text = "\(String(format: "%.2f", self.totalAmount))"
            }

        } catch {
            print("Failed to fetch transactions: \(error)")
        }

    }

    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    func decodeBase64ToImage(base64String: String) -> UIImage? {
        guard let imageData = Data(base64Encoded: base64String, options: .ignoreUnknownCharacters) else { return nil }
        return UIImage(data: imageData)
    }
}
//MARK: TableviewDataSource, Delegate
extension HomeVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1{
            return transactions.filter { !$0.isDelete }.count
           
        } else if tableView.tag == 0{
            return nameArr.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCellHome", for: indexPath) as! TableViewCellHome
            let visibleTransactions = transactions.filter { !$0.isDelete }
            let transaction = visibleTransactions[indexPath.row]
            cell.LblHead.text = transaction.title
//            transaction.isDelete = true
            let formatter = DateFormatter()
            formatter.dateFormat = "MMM dd, yyyy"
            cell.LblDate.text = formatter.string(from: transaction.date)
            
            let text = transaction.type
            if text == 0 {//expense
                cell.LblCurrency.text = "-\(transaction.currency)"
                if !transaction.imageName.isEmpty, let image = UIImage(named: transaction.imageName) {
                    cell.colorImg.image = image
                } else {
                    cell.colorImg.image = UIImage(named: "") // Default image
                }
            } else{//income
                cell.LblCurrency.text = "+\(transaction.currency)"
                cell.colorImg.image = decodeBase64ToImage(base64String: transaction.imageName) ?? UIImage(named: "Ellipse 8")
            }
            
            cell.LblAmonut.text = transaction.amount >= 0 ?  "\(transaction.amount)" : "\(abs(transaction.amount))"
//            if !transaction.imageName.isEmpty, let image = UIImage(named: transaction.imageName) {
//                cell.colorImg.image = image
//            } else {
//                cell.colorImg.image = UIImage(named: "") // Default image
//            }
            
            cell.ColorView.backgroundColor =  transaction.colorView
            cell.ImgColoriew.backgroundColor = transaction.colorView
            print("Number of rows in tableview 1 : \(transactions.count)")
            return cell
        }else if tableView.tag == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
            cell.TblImg.image = UIImage(named: imgArr[indexPath.row])
            cell.TblLbl.text = nameArr[indexPath.row]
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let transactionToDelete = transactions[indexPath.row]

            // Create an alert for confirmation
            let alert = UIAlertController(title: transactionToDelete.title, message: "Are you sure you want to delete?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
                // Update totalAmount based on the transaction type
                if transactionToDelete.type == 0 { // Expense
                    self.totalAmount += transactionToDelete.amount
                } else { // Income
                    self.totalAmount -= transactionToDelete.amount
                }

                // Update Core Data: Mark the record as deleted
                guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
                let context = appDelegate.persistentContainer.viewContext

                if transactionToDelete.type == 0 { // Expense
                    let fetchRequest: NSFetchRequest<Expense> = Expense.fetchRequest()
                    fetchRequest.predicate = NSPredicate(format: "title == %@ AND date == %@", transactionToDelete.title, transactionToDelete.date as CVarArg)//from coreData fetch only that data which are same date and title to delete tablviewdata

                    do {
                        let results = try context.fetch(fetchRequest)
                        if let expenseToUpdate = results.first {
                            expenseToUpdate.isDeletedData = true // Mark as deleted
                            try context.save()
                        }
                    } catch {
                        print("Failed to update expense: \(error)")
                    }
                } else { // Income
                    let fetchRequest: NSFetchRequest<Income> = Income.fetchRequest()
                    fetchRequest.predicate = NSPredicate(format: "title == %@ AND date == %@", transactionToDelete.title, transactionToDelete.date as CVarArg)

                    do {
                        let results = try context.fetch(fetchRequest)
                        if let incomeToUpdate = results.first {
                            incomeToUpdate.isDeletedData = true // Mark as deleted
                            try context.save()
                        }
                    } catch {
                        print("Failed to update income: \(error)")
                    }
                }

                // Remove the transaction from the array (only the deleted one)
                self.transactions.remove(at: indexPath.row)

                // Update the tableview by deleting the row
                tableView.deleteRows(at: [indexPath], with: .fade)

                // Update the balance label
                self.LblAvilbleBalance.text = "\(String(format: "%.2f", self.totalAmount))"
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            present(alert, animated: true)
        }
    }



}


