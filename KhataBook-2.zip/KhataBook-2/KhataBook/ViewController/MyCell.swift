//
//  MyCell.swift
//  KhataBook
//
//  Created by Hemaxi S on 12/03/25.
//

import UIKit
import DropDown

class MyCell: DropDownCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var dropdownView: UIView!
    
}


class MyDropDownCell: DropDownCell {
    
//    @IBOutlet weak var logoImageView: UIImageView!
    
}
