//
//  ProfileVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 11/03/25.
//

import UIKit

class ProfileVC: UIViewController {

    @IBOutlet weak var qrImg: UIImageView!//img
    @IBOutlet weak var profileImg: UIImageView!//img
    @IBOutlet weak var subImageView: UIView!//view
    @IBOutlet weak var mainImgView: UIView!//view
    @IBOutlet weak var firstView: UIView!//view
    @IBOutlet weak var bankImage: UIView!
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var thirdView: UIView!
    @IBOutlet weak var creditcard: UIView!
    @IBOutlet weak var debitCar: UIView!
    @IBOutlet weak var cardImg: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
}
//MARK: SetUp UI
extension ProfileVC{
    func setUP(){
        firstView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        secondView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        thirdView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        
        firstView.layer.cornerRadius = 10
        secondView.layer.cornerRadius = 10
        thirdView.layer.cornerRadius = 10
        
        creditcard.layer.cornerRadius = 10
        debitCar.layer.cornerRadius = 10
        bankImage.layer.cornerRadius = 10
        cardImg.layer.cornerRadius = 10
        
        subImageView.layer.cornerRadius = subImageView.frame.height / 2
//        profileImg.layer.cornerRadius = profileImg.frame.height / 2
        mainImgView.layer.cornerRadius = mainImgView.frame.height / 2
       // qrImg.layer.cornerRadius = qrImg.frame.height / 2
    }
}
