//
//  ExpenseVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 07/03/25.
//

import UIKit
import iOSDropDown
import CoreData

class ExpenseVC: UIViewController {
    //MARK: IBOutlet and Variable Declaration
    @IBOutlet weak var TxtDesc: DropDown!
    @IBOutlet weak var TxtPayment: DropDown!
    @IBOutlet weak var TxtCurrency: DropDown!
    @IBOutlet weak var TxtAmount: DropDown!
    @IBOutlet weak var TxtGrocery: DropDown!
    @IBOutlet weak var TxtDate: DropDown!
    
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var paymentView: UIView!
    @IBOutlet weak var currencyView: UIView!
    @IBOutlet weak var amountView: UIView!
    @IBOutlet weak var GroceryView: UIView!
    @IBOutlet weak var DateView: UIView!
    
    @IBOutlet weak var btnGrocery: UIButton!
    @IBOutlet weak var btnPayment: UIButton!
    @IBOutlet weak var btnCurrency: UIButton!
    @IBOutlet weak var btnAmount: UIButton!
    
    let dropDown = DropDown()
    let groceryDropDown = DropDown()
    let paymentDropDown = DropDown()
    let currencyDropDown = DropDown()
    let amountDropDown = DropDown()
    
    let listArr = ["Grocery", "Electronics", "Apparels", "Investments", "Life"]
       let imgArr = ["Grocery", "Electronics", "Apparels", "Investments", "Life"]
    let groceryImages: [String: String] = [
        "Grocery": "grocery_image",
        "Electronics": "electronics_image",
        "Apparels": "apparels_image",
        "Investments": "investments_image",
        "Life": "life_image"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        DispatchQueue.main.async {
            self.setupDropDown(textField: self.TxtGrocery, data: self.listArr, images: self.imgArr)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
}
//MARK: SetUp UI
extension ExpenseVC{
    func setUP(){
        //corner Radius
        descriptionView.layer.cornerRadius = 20
        paymentView.layer.cornerRadius = 20
        GroceryView.layer.cornerRadius = 20
        amountView.layer.cornerRadius = 20
        DateView.layer.cornerRadius = 20
        currencyView.layer.cornerRadius = 20
        //transperent color
        DateView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        descriptionView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        paymentView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        GroceryView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        amountView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        currencyView.backgroundColor = UIColor.white.withAlphaComponent(0.1)        
        //Border Width
        descriptionView.layer.borderWidth = 1
        paymentView.layer.borderWidth = 1
        GroceryView.layer.borderWidth = 1
        amountView.layer.borderWidth = 1
        DateView.layer.borderWidth = 1
        currencyView.layer.borderWidth = 1
    }
    
    func setupDropdowns() {
        setupDropDown(textField: TxtGrocery, data: ["Grocery", "Electronics", "Apparels", "Investments", "Life"], images: ["User", "User", "User", "User", "User"])
                
                // Payment Dropdown with Images
                setupDropDown(textField: TxtPayment, data: ["Cash", "Credit Card", "Debit Card"], images: ["User", "User", "User"])
                
                // Currency Dropdown with Images
                setupDropDown(textField: TxtCurrency, data: ["USD", "INR", "EUR"], images: ["User", "User", "User"])
           
        }
    func setupDropDown(textField: DropDown?, data: [String], images: [String]) {
        guard let textField = textField else {
            print("⚠️ Error: Dropdown text field is nil!")
            return
        }
        
        print("✅ Dropdown initialized correctly: \(textField)")
        
        DispatchQueue.main.async { [weak textField] in
            guard let strongTextField = textField else {
                print("⚠️ DropDown deallocated before usage")
                return
            }
            
            strongTextField.optionArray = data  // Set options safely
            
            if data.count == images.count {
                strongTextField.optionImageArray = images
            } else {
                print("⚠️ Warning: Data and Image arrays do not match")
            }
            
            strongTextField.rowHeight = 40
            strongTextField.listHeight = 150
            strongTextField.didSelect { selectedText, index, id in
                strongTextField.text = selectedText
                print("✅ Selected: \(selectedText) at index: \(index)")
            }
        }
    }
}
//MARK: Click Events
extension ExpenseVC{
    @IBAction func btnCloseClick(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func btnIncomeClick(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnGrocerySelection(_ sender: Any) {
        print("buton clicked")
        TxtGrocery.showList()
    }
    
    @IBAction func btnAmountSelection(_ sender: Any) {
        TxtAmount.showList()
    }
    
    @IBAction func btnCurrencySelection(_ sender: Any) {
        TxtCurrency.showList()
    }
    
    @IBAction func btnPaymentSelection(_ sender: Any) {
        TxtPayment.showList()
    }
    
    @IBAction func btnInsertTemplateClick(_ sender: Any) {
        guard let title = TxtGrocery.text, !title.isEmpty else { return }
        guard let amountText = TxtAmount.text, !amountText.isEmpty else { return }
        let date = Date()
        let selectedImageName = groceryImages[title] ??  "defaultImage"

        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        let newExpense = Expense(context: context)
        newExpense.title = title
        newExpense.date = date
        newExpense.amount = amountText // Negative for expense
        newExpense.image = selectedImageName

        do {
            try context.save()
            navigationController?.popToRootViewController(animated: true)
            //NotificationCenter.default.post(name: NSNotification.Name("refreshHomeTableView"), object: nil) // Notify HomeTableView
            self.dismiss(animated: true) // Close this view
        } catch {
            print("Failed to save expense: \(error)")
        }
    }
}

