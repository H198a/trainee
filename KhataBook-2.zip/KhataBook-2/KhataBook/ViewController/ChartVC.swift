//
//  ChartVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 18/03/25.
//

import UIKit
import BetterSegmentedControl
import Charts
import CoreData

class ChartVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var BtnDaily: UIButton!
    @IBOutlet weak var BtnMonthly: UIButton!
    @IBOutlet weak var BtnYearly: UIButton!
    @IBOutlet weak var LblAvailableBalance: UILabel!
    @IBOutlet weak var BtnIncome: UIButton!
    @IBOutlet weak var BtnExpense: UIButton!
    @IBOutlet weak var BtnAmount: UIButton!
    @IBOutlet weak var ViewIncome: UIView!
    @IBOutlet weak var ViewExpense: UIView!
    @IBOutlet weak var Linechart: LineChartView!
    
    private var chartDataEntries: [ChartDataEntry] = []
    let newSegemnt = BetterSegmentedControl()
    var transactions: [(date: Date?, amount: Double, type: Int32)] = []
    var selectedIndex: Int?
    var selectedMonthIndex: Int?
    var selectedYearIndex: Int?
    var dataPoints: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        //Linechart.delegate = self
        fetchTransaction()
        updateChart(type: "Daily")
        LblAvailableBalance.text = "\(calculateBalanceForIncome())"
//        setChart(dataPoints: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
    }
    

}
//MARK: SetUP UI
extension ChartVC{
    func setUP(){
        BtnDaily.layer.cornerRadius = 15
        BtnMonthly.layer.cornerRadius = 15
        BtnYearly.layer.cornerRadius = 15
        //display shadow by default on incomeview
        ViewIncome.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: -1, height: 3)
        ViewIncome.layer.shadowRadius = 3
        ViewIncome.layer.shadowOpacity = 1
//        Linechart.xAxis.setLabelCount(12, force: true)
       
    }
    func btnExpenseSetUp(){
        ViewExpense.backgroundColor = UIColor.view
        ViewIncome.backgroundColor = UIColor.lightGray
        BtnIncome.titleLabel?.textColor = UIColor.white
        BtnExpense.titleLabel?.textColor = UIColor.view
        //display shadow when expense button clicked
        ViewExpense.layer.shadowColor = UIColor.view.cgColor
        ViewExpense.layer.masksToBounds = false
        ViewExpense.layer.shadowOffset = CGSize(width: 0, height: 3)
        ViewExpense.layer.shadowRadius = 3
        ViewExpense.layer.shadowOpacity = 0.5
        //remove shadow when expense button clicked
        ViewExpense.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: 0, height: 0)
        ViewIncome.layer.shadowRadius = 0
        ViewIncome.layer.shadowOpacity = 0
        LblAvailableBalance.text = "\(calculateBalanceForExpense())"
    }
    func btnIncomeSetUp(){
        ViewIncome.backgroundColor = UIColor.view
        ViewExpense.backgroundColor = UIColor.lightGray
        BtnIncome.titleLabel?.textColor = UIColor.view
        BtnExpense.titleLabel?.textColor = UIColor.white
        //display shadow when income button clicked
        ViewExpense.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: 0, height: 3)
        ViewIncome.layer.shadowRadius = 3
        ViewIncome.layer.shadowOpacity = 0.5
        //remove shadow when income button clicked
        ViewExpense.layer.shadowColor = UIColor.view.cgColor
        ViewExpense.layer.masksToBounds = false
        ViewExpense.layer.shadowOffset = CGSize(width: 0, height: 0)
        ViewExpense.layer.shadowRadius = 0
        ViewExpense.layer.shadowOpacity = 0
        LblAvailableBalance.text = "\(calculateBalanceForIncome())"
    }
    func calculateBalanceForIncome() -> Double/* -> Double*/ {
        var incomeTotal = 0.0

        for transaction in transactions {
            if transaction.type == 1 {
                incomeTotal += transaction.amount
                //expenseTotal += transaction.amount
                return incomeTotal
            } else{
                LblAvailableBalance.text = "0.0"
            }
        }

        print("Income Total: \(incomeTotal)")
        
        return incomeTotal
    }
    func calculateBalanceForExpense() -> Double/* -> Double*/ {
        var expenseTotal = 0.0

        for transaction in transactions {
            if transaction.type == 0 {
                expenseTotal += transaction.amount
                //expenseTotal += transaction.amount
                return expenseTotal
            } else{
                LblAvailableBalance.text = "0.0"
            }
        }

        print("Income Total: \(expenseTotal)")
        
        return expenseTotal
    }
}
//MARK: Chart Custom Function
extension ChartVC{
    func setChart(dataPoints: [String],values: [Double]) {
        Linechart.noDataText = "No data available!"
        for i in 0..<values.count {
            print("chart point : \(values[i])")
            let dataEntry = ChartDataEntry(x: Double(i),y: values[i],data: dataPoints)
            chartDataEntries.append(dataEntry)
        }
        let line1 = LineChartDataSet(entries: chartDataEntries, label: "")
        line1.colors = [NSUIColor.white]
        line1.mode = .horizontalBezier
        line1.valueTextColor = .clear
        line1.valueFont = UIFont.systemFont(ofSize: 20)
//        line1.cubicIntensity = 60.0
        line1.drawCirclesEnabled = false
        line1.drawVerticalHighlightIndicatorEnabled = false
        line1.drawHorizontalHighlightIndicatorEnabled = false
        // Highlight today's point
        let todayIndex = Calendar.current.component(.weekday, from: Date()) - 2 // Adjust to 0-6 index
        if todayIndex >= 0 && todayIndex < chartDataEntries.count {
            line1.highlightColor = .yellow
            line1.highlightLineWidth = 3.0
            line1.highlightLineDashLengths = nil
            line1.highlightLineDashPhase = 0.0
            line1.highlightEnabled = true
            line1.setCircleColor(ChartColorTemplates.colorFromString("#ffcc1a29"))
//            if !isSingelValue {
//                line1.setColor(ChartColorTemplates.colorFromString("#ffcc1a29"))
//             }else {
//                 line1.setColor(UIColor.clear)
//             }
//            line1.highlightValues([ChartHighlight(x: Double(todayIndex), y: values[todayIndex], dataSetIndex: 0)])
            
        } else {
            line1.highlightEnabled = false
        }
        
        let gradient = getGradientFilling()
        line1.fill = LinearGradientFill(gradient: gradient, angle: 90.0)
        line1.drawFilledEnabled = true
        
        let data = LineChartData(dataSet: line1)
        Linechart.data = data
       // let indexData = data[1] as? LineChartDataSet
        
        Linechart.setScaleEnabled(true)
        //Linechart.animate(xAxisDuration: 1.5)
        Linechart.drawGridBackgroundEnabled = false
        Linechart.xAxis.drawAxisLineEnabled = false
        Linechart.xAxis.drawGridLinesEnabled = true//display vertical lines in charts
        Linechart.leftAxis.drawAxisLineEnabled = true
        Linechart.leftAxis.drawGridLinesEnabled = false
        Linechart.rightAxis.drawAxisLineEnabled = true
        Linechart.rightAxis.drawGridLinesEnabled = true
        Linechart.legend.enabled = true
        Linechart.xAxis.enabled = true
        Linechart.leftAxis.enabled = false
//        Linechart.leftAxis.labelPosition = .outsideChart
        Linechart.scaleXEnabled = true
        Linechart.scaleYEnabled = true
        
       
        Linechart.xAxis.labelPosition = .bottom

        //Linechart.drawValueAboveBarEnabled = false
        
//        Linechart.extraLeftOffset = 25.0
//        Linechart.extraRightOffset = 25.0
//        Linechart.leftAxis.axisMinimum = 10
        Linechart.xAxis.spaceMax = 0.3
        Linechart.xAxis.spaceMin = 0.3
        Linechart.rightAxis.enabled = false//remove upper text line
        Linechart.xAxis.drawLabelsEnabled = true//display bottom labes
        Linechart.xAxis.labelTextColor = .white
        Linechart.doubleTapToZoomEnabled = false
        Linechart.xAxis.avoidFirstLastClippingEnabled = false
        //Linechart.rightAxis.axisMinimum = 100
        Linechart.rightAxis.axisMaximum = 100.0

//        Linechart.xAxis.granularity = 1.0
        Linechart.xAxis.labelFont = UIFont.systemFont(ofSize: 15)
        //Linechart.xAxis.setLabelCount(1, force: true)//labelpoisstion wordwraping
        Linechart.xAxis.labelPosition = .bottom
        Linechart.xAxis.wordWrapEnabled = true
        //Linechart.legend.font = UIFont.systemFont(ofSize: 15)

        
        let marker = BalloonMarker(color: UIColor.orange,
                                   font: UIFont.systemFont(ofSize: 15),
                                   textColor: UIColor.white,
                                   insets: UIEdgeInsets(top: 8, left: 8, bottom: 20, right: 8))
        marker.chartView = Linechart
        marker.minimumSize = CGSize(width: 90, height: 50)
        Linechart.marker = marker

        Linechart.legend.form = .line
        
//        let legendEntries = chartDataEntries.enumerated().map { (index, data) -> LegendEntry in
//            let legendEntry = LegendEntry()
//            legendEntry.label = dataPoints[index] // Example: "car = 1.0"
//            legendEntry.labelColor = .white
//            legendEntry.formSize = 1
//            //legendEntry.formLineWidth = 40
//            //legendEntry.formColor = chartColors[index]// Set the color for the dot
////            legendEntry.form = .circle // Set the form to a circle
//            return legendEntry
//        }
        
        // Set legend customization
        //Linechart.legend.setCustom(entries: legendEntries)
    }
    private func getGradientFilling() -> CGGradient {
       
        let coloTop = UIColor(red: 227/255, green: 181/255, blue: 60/255, alpha: 1).cgColor
        let colorBottom = UIColor(red: 227/255, green: 130/255, blue: 60/255, alpha: 0).cgColor
        let gradientColors = [coloTop, colorBottom] as CFArray
        let colorLocations: [CGFloat] = [0.7, 0.0]
        return CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColors, locations: colorLocations)!
    }
    func updateChart(type: String) {
        // Holds the days of the week
        var values: [Double] = []      // Holds the daily amounts (income - expense)
        chartDataEntries.removeAll()
        var labels: [String] = []

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E" // Day of the week (Mon, Tue, etc.)
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let weekDay = calendar.component(.weekday, from: today)
        let currentWeekDay = weekDay == 1 ? 7 : weekDay - 1

        switch type {
        case "Daily":
            // clear previous chart data
            dataPoints.removeAll()
            values.removeAll()
            
            labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            
            // loop through the weekday
            for i in 1...7 {
                let day = calendar.date(byAdding: .day, value: i - currentWeekDay, to: today)!
                let dayName = dateFormatter.string(from: day) // "Mon", "Tue", "Wed", etc.
                dataPoints.append(dayName)  // Add the day name to dataPoints

                // Get the start and end date for each day
                let dayStart = calendar.startOfDay(for: day)
                let dayEnd = calendar.date(byAdding: .day, value: 1, to: dayStart)!

                // Calculate the daily amount for this day (Income - Expense)
                let dailyAmount = calculateDailyAmount(from: dayStart, to: dayEnd)
                //values = [100, 10, 20, 0, 0, 50, 60]
                values.append(dailyAmount)  // Add the calculated daily amount to values
            }

            // Optional: Update the amount label for the Daily chart
            if let selectedIndex = selectedIndex {
                let selectedDate = calendar.date(byAdding: .day, value: selectedIndex - currentWeekDay, to: today)!
                let selectedEndDate = calendar.date(byAdding: .day, value: 1, to: selectedDate)!
                let amount: Double

                if ViewIncome.backgroundColor == UIColor.view {
                    amount = calculateDailyIncome(from: selectedDate, to: selectedEndDate)
                } else {
                    amount = calculateDailyExpense(from: selectedDate, to: selectedEndDate)
                }
               // BtnAmount.setTitle("$\(amount)", for: .normal)
            } else{
                print("something went wrong")
            }
            print(BtnAmount ?? "nothing")
//            dataPoints = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
//            values = [5.0, 8.0, 3.0, 12.0, 7.0, 10.0, 6.0]
            break
        case "Monthly":
            labels = ["Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"]
                   values = []
//            create single tuole of each dataset
            let monthsInYear = 7
                  for month in 1...monthsInYear {
                      let monthStart = calendar.date(from: DateComponents(year: calendar.component(.year, from: Date()), month: month, day: 1))!
                      let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)!

                      // Calculate the monthly amount (Income - Expense) for the given month
                      let monthlyAmount = calculateMonthlyAmount(from: monthStart, to: monthEnd)
                      labels.append(dateFormatter.string(from: monthStart))  // Use the month name (e.g., "Jan", "Feb", etc.)
                      values.append(monthlyAmount)  // Add the calculated monthly amount to values
                  }
            
            if let selectedMonthIndex = selectedIndex {
                       let selectedMonthStart = calendar.date(from: DateComponents(year: calendar.component(.year, from: Date()), month: selectedMonthIndex + 1, day: 1))!
                       let selectedMonthEnd = calendar.date(byAdding: .month, value: 1, to: selectedMonthStart)!

                       let amount: Double
                       if ViewIncome.backgroundColor == UIColor.view {
                           amount = calculateDailyIncome(from: selectedMonthStart, to: selectedMonthEnd)
                       } else {
                           amount = calculateDailyExpense(from: selectedMonthStart, to: selectedMonthEnd)
                       }
                      // BtnAmount.setTitle("$\(amount)", for: .normal)
                   }
            break
            case "Yearly":
            
            labels = ["2019","2020", "2021", "2022", "2023", "2024", "2025"]
                values = []
            let years = 7  // For example, show data from 2019 to 2025
                    for year in 2019...(2019+years-1) {
                        let yearStart = calendar.date(from: DateComponents(year: year, month: 1, day: 1))!
                        let yearEnd = calendar.date(from: DateComponents(year: year, month: 12, day: 31))!

                        // Calculate the yearly amount (Income - Expense) for the given year
                        let yearlyAmount = calculateYearlyAmount(from: yearStart, to: yearEnd)
                        labels.append("\(year)")  // Use the year
                        values.append(yearlyAmount)  // Add the calculated yearly amount to values
                    }

                    // Update the amount for the Yearly chart
                    if let selectedYearIndex = selectedIndex {
                        let selectedYear = labels[selectedYearIndex]
                        let selectedYearStart = calendar.date(from: DateComponents(year: Int(selectedYear), month: 1, day: 1))!
                        let selectedYearEnd = calendar.date(from: DateComponents(year: Int(selectedYear), month: 12, day: 31))!

                        let amount: Double
                        if ViewIncome.backgroundColor == UIColor.view {
                            amount = calculateDailyIncome(from: selectedYearStart, to: selectedYearEnd)
                        } else {
                            amount = calculateDailyExpense(from: selectedYearStart, to: selectedYearEnd)
                        }
                        BtnAmount.setTitle("$\(amount)", for: .normal)
                    }
            break
            default:
                return
            }
        let description = Description()
            description.text = ""
        Linechart.chartDescription = description
        Linechart.xAxis.valueFormatter = IndexAxisValueFormatter(values: labels)
//        Linechart.xAxis.granularity = 0.0
//        Linechart.xAxis.granularityEnabled = true
            setChart(dataPoints: dataPoints, values: values)
        }

}
//MARK: Custom Function
extension ChartVC{
    func fetchTransaction(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        transactions.removeAll()
        
        let incomeFetch: NSFetchRequest<Income> = Income.fetchRequest()
        let expenseFetch: NSFetchRequest<Expense> = Expense.fetchRequest()
        
        do{
            let incomeResults = try context.fetch(incomeFetch)
            let expenseResults = try context.fetch(expenseFetch)
            
            for income in incomeResults {
                let date = income.date
                let amount = Double(income.amount ?? "") ?? 0.0
                let type = income.type
                
                transactions.append((date: date, amount: amount, type: type))
            }
            for expense in expenseResults{
                let date = expense.date
                let amount = Double(expense.amount ?? "") ?? 0.0
                let type = expense.type
                
                transactions.append((date: date, amount: amount, type: type))
            }
        } catch{
            print("eror in fetching data",error)
        }
    }
    
    func calculateDailyAmount(from startDate: Date, to endDate: Date) -> Double {
        var totalAmount: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate {
                if transaction.type == 1 { // Income
                    totalAmount += transaction.amount
                } else { // Expense
                    totalAmount -= transaction.amount
                }
            }
        }
        return totalAmount
    }
    
    func calculateMonthlyAmount(from startDate: Date, to endDate: Date) -> Double {
        var totalAmount: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate {
                if transaction.type == 1 { // Income
                    totalAmount += transaction.amount
                } else { // Expense
                    totalAmount -= transaction.amount
                }
            }
        }
        return totalAmount
    }
    
    func calculateYearlyAmount(from startDate: Date, to endDate: Date) -> Double {
        var totalAmount: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate {
                if transaction.type == 1 { // Income
                    totalAmount += transaction.amount
                } else { // Expense
                    totalAmount -= transaction.amount
                }
            }
        }
        return totalAmount
    }
    
    func calculateDailyIncome(from startDate: Date, to endDate: Date) -> Double {
        var totalIncome: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 1 {
                totalIncome += transaction.amount
            }
        }
        return totalIncome
    }
    
    func calculateDailyExpense(from startDate: Date, to endDate: Date) -> Double {
        var totalExpense: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 0 {
                totalExpense += transaction.amount
            }
        }
        return totalExpense
    }
}
//MARK: Click Events
extension ChartVC{
    @IBAction func BtnDailyClick(_ sender: Any) {
        LblAvailableBalance.text = ("\(calculateBalanceForIncome())")
        BtnDaily.backgroundColor = UIColor.chartBtnColors
        BtnYearly.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.clear
        //setChart(dataPoints: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        updateChart(type: "Daily")
    }
    
    @IBAction func BtnMonthlyClick(_ sender: Any) {
        LblAvailableBalance.text = ("\(calculateBalanceForIncome())")
        BtnDaily.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.chartBtnColors
        BtnYearly.backgroundColor = UIColor.clear
        //setChart(dataPoints: ["Mar","Apr","May","Jun","Jul","Aug","Sep"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        updateChart(type: "Monthly")
    }
    
    @IBAction func BtnYearlyClick(_ sender: Any) {
        LblAvailableBalance.text = ("\(calculateBalanceForIncome())")
        BtnDaily.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.clear
        BtnYearly.backgroundColor = UIColor.chartBtnColors
        //setChart(dataPoints: ["2019","2020","2021","2022","2023","2024","2025"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        updateChart(type: "Yearly")
    }
    
    @IBAction func BtnIncomeClick(_ sender: Any) {
        btnIncomeSetUp()
    }
    
    @IBAction func BtnExpenseClick(_ sender: Any) {
        btnExpenseSetUp()
    }
}
//extension ChartVC: ChartViewDelegate {
//    // called when a user taps on a chart entry
//    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
//        
//        //index of the selected day in the chart
//         selectedIndex = Int(highlight.x)
//        
//        //  selected index
//        if selectedIndex ?? 1 >= 0 && selectedIndex ?? 1 < chartDataEntries.count {
//            // get the selected day  "Mon", "Tue"..
//            let selectedDay = dataPoints[selectedIndex ?? 1]
//            highlightSelectedDay(selectedIndex ?? 1)
//            
//            // Get the start and end date for that selected day
//            let calendar = Calendar.current
//            let today = calendar.startOfDay(for: Date())
//            let weekDay = calendar.component(.weekday, from: today)
//            let currentWeekDay = weekDay == 1 ? 7 : weekDay - 1
//            
//            // Calculate the date for the selected day
//            let selectedDate = calendar.date(byAdding: .day, value: selectedIndex ?? 1 - currentWeekDay, to: today)!
//            let selectedEndDate = calendar.date(byAdding: .day, value: 1, to: selectedDate)!
//            //calculate income and expense based on selected type
//            let amount: Double
//            if ViewIncome.backgroundColor == UIColor.view {
//                amount = calculateDailyIncome(from: selectedDate, to: selectedEndDate)
//            } else {
//                amount = calculateDailyExpense(from: selectedDate, to: selectedEndDate)
//            }
//            
//            //BtnAmount.setTitle("$\(amount)", for: .normal)
//            //moveAmountLabelToSelectedDay(selectedIndex ?? 1)
//        }
//    }
//    
//    private func highlightSelectedDay(_ selectedIndex: Int) {
//        // set the text hightlighted
//        if let dataSet = Linechart.data?.dataSets.first as? LineChartDataSet {
//            let highlight = Highlight(x: Double(selectedIndex), y: dataSet.entryForIndex(selectedIndex)?.y ?? 0, dataSetIndex: 0)
//            Linechart.highlightValue(highlight)
//        }
//    }
//    
//    private func moveAmountLabelToSelectedDay(_ selectedIndex: Int) {
//        // move the label amount to selected day
//        let xPosition = Linechart.frame.origin.x + CGFloat(selectedIndex) * Linechart.frame.width / CGFloat(dataPoints.count)
//        let yPosition = Linechart.frame.origin.y - 320  // vertical position of amount label
//
//        //poaition of amount label
//        BtnAmount.frame.origin = CGPoint(x: xPosition, y: yPosition)
//    }


    // if ntg is selected then by default shows 0.0
//    func chartValueNothingSelected(_ chartView: ChartViewBase) {
//        BtnAmount.setTitle("0.0", for: .normal)
//    }
//}

/*---x
 |y*/
