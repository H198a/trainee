//
//  File.swift
//  KhataBook
//
//  Created by Hemaxi S on 10/03/25.
//

import Foundation
/*
 extension Date {

     /// Create a date from specified parameters
     ///
     /// - Parameters:
     ///   - year: The desired year
     ///   - month: The desired month
     ///   - day: The desired day
     /// - Returns: A `Date` object
     static func from(year: Int, month: Int, day: Int) -> Date? {
         let calendar = Calendar(identifier: .gregorian)
         var dateComponents = DateComponents()
         dateComponents.year = year
         dateComponents.month = month
         dateComponents.day = day
         return calendar.date(from: dateComponents) ?? nil
     }
 }
 Use:

 //tab bar commented code
 extension HomeVC: UITabBarControllerDelegate{
     func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
         guard let selectedIndex = tabBar.items?.firstIndex(of: item) else { return }
         applyShadowToSelectedTab(selectedIndex: selectedIndex)
     }
 }
 
 func applyShadowToSelectedTab(selectedIndex: Int) {
     guard let tabBar = self.tabBarController?.tabBar else { return }
     
     // Remove shadow from all items
     for (index, item) in tabBar.items?.enumerated() ?? [].enumerated() {
         if let tabButton = tabBar.subviews.first(where: { $0 is UIControl && $0.frame.origin.x == CGFloat(index) }) {
             tabButton.layer.shadowOpacity = 0 // Remove shadow
         }
     }
     
     // Apply shadow to selected tab
     if let selectedTabButton = tabBar.subviews.first(where: { $0 is UIControl && $0.frame.origin.x == CGFloat(selectedIndex) }) {
         selectedTabButton.layer.shadowColor = UIColor.white.cgColor  // Set shadow color
         selectedTabButton.layer.shadowOpacity = 2.5 // Set shadow opacity
         selectedTabButton.layer.shadowOffset = CGSize(width: 0, height: -4)  // Set shadow offset
         selectedTabButton.layer.shadowRadius = 5  // Set shadow blur radius
     }
 }
 
 //calculate functioon commented code
 func calculateBalance() -> Double/* -> Double*/ {
     var incomeTotal = 0.0
     var expenseTotal = 0.0

     for transaction in transactions {
         if transaction.type == 1 {
             incomeTotal += transaction.amount
             //expenseTotal += transaction.amount
             //return incomeTotal
         } else if transaction.type == 0 {
             expenseTotal += transaction.amount
           
         }
     }

     print("Income Total: \(incomeTotal)")
     print("Expense Total: \(expenseTotal)")
     print(incomeTotal - expenseTotal)
     return incomeTotal - expenseTotal
 }


*/
