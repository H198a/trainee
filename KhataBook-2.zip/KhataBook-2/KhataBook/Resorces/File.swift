//
//  File.swift
//  KhataBook
//
//  Created by Hemaxi S on 10/03/25.
//

import Foundation
/*

 import UIKit
 import Charts

 class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, ChartViewDelegate {

     @IBOutlet weak var chartViewContainer: UIView!
     var lineChartView: LineChartView!
     var transactions: [(title: String, date: Date, amount: Double, imageName: String)] =
     var currentChartType: ChartType = .daily

     enum ChartType {
         case daily, monthly, yearly
     }

     override func viewDidLoad() {
         super.viewDidLoad()

         lineChartView = LineChartView(frame: chartViewContainer.bounds)
         chartViewContainer.addSubview(lineChartView)
         lineChartView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
         lineChartView.delegate = self

         fetchTransactions()
         setupChartData()
     }

     // Fetch data from Core Data
     func fetchTransactions() {
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
         let context = appDelegate.persistentContainer.viewContext

         transactions.removeAll()

         let incomeFetch: NSFetchRequest<Income> = Income.fetchRequest()
         let expenseFetch: NSFetchRequest<Expense> = Expense.fetchRequest()

         do {
             let incomeResults = try context.fetch(incomeFetch)
             let expenseResults = try context.fetch(expenseFetch)

             for income in incomeResults {
                 let amount = Double(income.amount ?? "0") ?? 0.0
                 transactions.append((title: income.title ?? "", date: income.date ?? Date(), amount: amount, imageName: income.image ?? "defaultImage"))
             }

             for expense in expenseResults {
                 let amount = Double(expense.amount ?? "0") ?? 0.0
                 transactions.append((title: expense.title ?? "", date: expense.date ?? Date(), amount: -abs(amount), imageName: expense.image ?? "defaultImage"))
             }

             transactions.sort { $0.date > $1.date }
         } catch {
             print("Failed to fetch transactions: \(error)")
         }
     }

     // Prepare chart data
     func setupChartData() {
         let incomeEntries = createChartDataEntries(from: transactions.filter { $0.amount > 0 }, chartType: currentChartType)
         let expenseEntries = createChartDataEntries(from: transactions.filter { $0.amount < 0 }, chartType: currentChartType)

         let incomeDataSet = LineChartDataSet(entries: incomeEntries, label: "Income")
         incomeDataSet.colors = [NSUIColor.green]
         incomeDataSet.fillColor = NSUIColor.green.withAlphaComponent(0.3)
         incomeDataSet.fillAlpha = 1
         incomeDataSet.drawFilledEnabled = true

         let expenseDataSet = LineChartDataSet(entries: expenseEntries, label: "Expense")
         expenseDataSet.colors = [NSUIColor.red]
         expenseDataSet.fillColor = NSUIColor.red.withAlphaComponent(0.3)
         expenseDataSet.fillAlpha = 1
         expenseDataSet.drawFilledEnabled = true

         let chartData = LineChartData(dataSets: [incomeDataSet, expenseDataSet])
         lineChartView.data = chartData

         lineChartView.xAxis.labelPosition = .bottom
         lineChartView.xAxis.valueFormatter = self
         lineChartView.xAxis.granularity = 1
         lineChartView.rightAxis.enabled = false
         lineChartView.chartDescription?.enabled = false
     }

     // Create chart data entries
     func createChartDataEntries(from transactions: [(title: String, date: Date, amount: Double, imageName: String)], chartType: ChartType) -> [ChartDataEntry] {
         var chartEntries: [ChartDataEntry] =
         var index = 0

         switch chartType {
         case .daily:
             for transaction in transactions {
                 chartEntries.append(ChartDataEntry(x: Double(index), y: transaction.amount))
                 index += 1
             }
         case .monthly:
             let groupedTransactions = Dictionary(grouping: transactions) { transaction in
                 Calendar.current.dateComponents([.year, .month], from: transaction.date)
             }
             for (monthComponents, monthTransactions) in groupedTransactions {
                 let totalAmount = monthTransactions.reduce(0) { $0 + $1.amount }
                 chartEntries.append(ChartDataEntry(x: Double(index), y: totalAmount))
                 index += 1
             }
         case .yearly:
             let groupedTransactions = Dictionary(grouping: transactions) { transaction in
                 Calendar.current.component(.year, from: transaction.date)
             }
             for (year, yearTransactions) in groupedTransactions {
                 let totalAmount = yearTransactions.reduce(0) { $0 + $1.amount }
                 chartEntries.append(ChartDataEntry(x: Double(year), y: totalAmount))
             }
         }

         return chartEntries
     }

     // Format x-axis labels
     extension ViewController: IAxisValueFormatter {
         func stringForValue(_ value: Double, axis: AxisBase?) -> String {
             switch currentChartType {
             case .daily:
                 let index = Int(value)
                 guard index >= 0 && index < transactions.count else { return "" }
                 let date = transactions[index].date
                 let dateFormatter = DateFormatter()
                 dateFormatter.dateFormat = "dd MMM"
                 return dateFormatter.string(from: date)
             case .monthly:
                 let index = Int(value)
                 guard index >= 0 && index < groupedTransactions.count else { return "" }
                 let monthComponents = Array(groupedTransactions.keys)[index]
                 let date = Calendar.current.date(from: monthComponents)!
                 let dateFormatter = DateFormatter()
                 dateFormatter.dateFormat = "MMM yyyy"
                 return dateFormatter.string(from: date)
             case .yearly:
                 let year = Int(value)
                 return "\(year)"
             }
         }
     }

     // Handle chart type selection
     @IBAction func dailyChartButtonClicked(_ sender: Any) {
         currentChartType = .daily
         setupChartData()
     }

     @IBAction func monthlyChartButtonClicked(_ sender: Any) {
         currentChartType = .monthly
         setupChartData()
     }

     @IBAction func yearlyChartButtonClicked(_ sender: Any) {
         currentChartType = .yearly
         setupChartData()
     }

     // MARK: - UITableViewDataSource
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return transactions.count
     }

     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
         cell.textLabel?.text = transactions[indexPath.row].title
         return cell
     }

     // MARK: - UITableViewDelegate
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         tableView.deselectRow(at: indexPath, animated: true)
         // Handle cell selection if needed
     }
 }
 import UIKit
 import Charts
 import CoreData

 class InsightViewController: UIViewController, ChartViewDelegate {

     @IBOutlet weak var chartViewContainer: UIView!
     @IBOutlet weak var totalExpenseLabel: UILabel!
     @IBOutlet weak var segmentedControl: UISegmentedControl!

     var lineChartView: LineChartView!
     var transactions: [(title: String, date: Date, amount: Double, imageName: String)] =
     var currentChartType: ChartType = .daily

     enum ChartType {
         case daily, monthly, yearly
     }

     override func viewDidLoad() {
         super.viewDidLoad()

         lineChartView = LineChartView(frame: chartViewContainer.bounds)
         chartViewContainer.addSubview(lineChartView)
         lineChartView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
         lineChartView.delegate = self

         fetchTransactions()
         setupChartData()
         updateTotalExpenseLabel()
     }

     // Fetch data from Core Data
     func fetchTransactions() {
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
         let context = appDelegate.persistentContainer.viewContext

         transactions.removeAll()

         let incomeFetch: NSFetchRequest<Income> = Income.fetchRequest()
         let expenseFetch: NSFetchRequest<Expense> = Expense.fetchRequest()

         do {
             let incomeResults = try context.fetch(incomeFetch)
             let expenseResults = try context.fetch(expenseFetch)

             for income in incomeResults {
                 let amount = Double(income.amount ?? "0") ?? 0.0
                 transactions.append((title: income.title ?? "", date: income.date ?? Date(), amount: amount, imageName: income.image ?? "defaultImage"))
             }

             for expense in expenseResults {
                 let amount = Double(expense.amount ?? "0") ?? 0.0
                 transactions.append((title: expense.title ?? "", date: expense.date ?? Date(), amount: -abs(amount), imageName: expense.image ?? "defaultImage"))
             }

             transactions.sort { $0.date > $1.date }
         } catch {
             print("Failed to fetch transactions: \(error)")
         }
     }

     // Prepare chart data
     func setupChartData() {
         let incomeEntries = createChartDataEntries(from: transactions.filter { $0.amount > 0 }, chartType: currentChartType)
         let expenseEntries = createChartDataEntries(from: transactions.filter { $0.amount < 0 }, chartType: currentChartType)

         let incomeDataSet = LineChartDataSet(entries: incomeEntries, label: "Income")
         incomeDataSet.colors = [UIColor(red: 128/255, green: 222/255, blue: 234/255, alpha: 1.0)] // Light blue color
         incomeDataSet.fillColor = incomeDataSet.colors.first!
         incomeDataSet.fillAlpha = 0.3
         incomeDataSet.drawFilledEnabled = true
         incomeDataSet.drawCirclesEnabled = false // Hide circle markers on the line
         incomeDataSet.mode = .cubicBezier // Make the line curved
         incomeDataSet.lineWidth = 2.0

         let expenseDataSet = LineChartDataSet(entries: expenseEntries, label: "Expense")
         expenseDataSet.colors = [UIColor(red: 255/255, green: 171/255, blue: 145/255, alpha: 1.0)] // Light orange color
         expenseDataSet.fillColor = expenseDataSet.colors.first!
         expenseDataSet.fillAlpha = 0.3
         expenseDataSet.drawFilledEnabled = true
         expenseDataSet.drawCirclesEnabled = false // Hide circle markers on the line
         expenseDataSet.mode = .cubicBezier // Make the line curved
         expenseDataSet.lineWidth = 2.0

         let chartData = LineChartData(dataSets: [incomeDataSet, expenseDataSet])
         lineChartView.data = chartData

         lineChartView.xAxis.labelPosition = .bottom
         lineChartView.xAxis.valueFormatter = self
         lineChartView.xAxis.granularity = 1
         lineChartView.rightAxis.enabled = false
         lineChartView.chartDescription?.enabled = false
         lineChartView.legend.enabled = false // Hide the legend

         // Customize x-axis labels
         lineChartView.xAxis.labelFont = UIFont.systemFont(ofSize: 12)
         lineChartView.xAxis.labelTextColor = .gray

         // Customize y-axis labels
         lineChartView.leftAxis.labelFont = UIFont.systemFont(ofSize: 12)
         lineChartView.leftAxis.labelTextColor = .gray
         lineChartView.leftAxis.gridColor = .lightGray

         // Add a gradient fill to the chart area
         if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [UIColor.yellow.cgColor, UIColor.clear.cgColor] as CFArray, locations:) {
             incomeDataSet.fill = LinearGradientFill(gradient: gradient, angle: 90.0)
         }
     }

     // Create chart data entries
     func createChartDataEntries(from transactions: [(title: String, date: Date, amount: Double, imageName: String)], chartType: ChartType) -> [ChartDataEntry] {
         // ... (same as before) ...
     }

     // Format x-axis labels
     extension InsightViewController: IAxisValueFormatter {
         func stringForValue(_ value: Double, axis: AxisBase?) -> String {
             switch currentChartType {
             case .daily:
                 let index = Int(value)
                 guard index >= 0 && index < transactions.count else { return "" }
                 let date = transactions[index].date
                 let dateFormatter = DateFormatter()
                 dateFormatter.dateFormat = "EEE" // Short day names (Mon, Tue, etc.)
                 return dateFormatter.string(from: date)
             case .monthly:
                 // ... (same as before) ...
             case .yearly:
                 // ... (same as before) ...
             }
         }
     }

     // Update total expense label
     func updateTotalExpenseLabel() {
         let totalExpense = transactions.filter { $0.amount < 0 }.reduce(0) { $0 + $1.amount }
         totalExpenseLabel.text = "₹\(abs(totalExpense))" // Display as positive value
     }

     // Handle chart type selection
     @IBAction func segmentedControlValueChanged(_ sender: UISegmentedControl) {
         switch sender.selectedSegmentIndex {
         case 0: currentChartType = .daily
         case 1: currentChartType = .monthly
         case 2: currentChartType = .yearly
         default: break
         }
         setupChartData()
     }

     // Add a callout view (example)
     func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
         let calloutView = UIView(frame: CGRect(x: highlight.xPx, y: highlight.yPx, width: 80, height: 40))
         calloutView.backgroundColor = .white
         calloutView.layer.cornerRadius = 5
         let label = UILabel(frame: calloutView.bounds)
         label.text = "-₹\(entry.y)"
         calloutView.addSubview(label)
         lineChartView.addSubview(calloutView)
     }
 }
 
 */
