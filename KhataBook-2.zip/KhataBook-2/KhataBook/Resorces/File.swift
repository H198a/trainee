//
//  File.swift
//  KhataBook
//
//  Created by Hemaxi S on 10/03/25.
//

import Foundation
/*
 extension Date {

     /// Create a date from specified parameters
     ///
     /// - Parameters:
     ///   - year: The desired year
     ///   - month: The desired month
     ///   - day: The desired day
     /// - Returns: A `Date` object
     static func from(year: Int, month: Int, day: Int) -> Date? {
         let calendar = Calendar(identifier: .gregorian)
         var dateComponents = DateComponents()
         dateComponents.year = year
         dateComponents.month = month
         dateComponents.day = day
         return calendar.date(from: dateComponents) ?? nil
     }
 }
 Use:



 let marsOpportunityLaunchDate = Date.from(year: 2003, month: 07, day: 07)
 Date.from(year: 2003, month: 07, day: 07)

 
 */
//
