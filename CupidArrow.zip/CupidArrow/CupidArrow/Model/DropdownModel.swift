//
//  DropdownModel.swift
//  CupidArrow
//
//  Created by Hemaxi S on 03/04/25.
//


import Foundation
import UIKit

struct Category {
    let name: String
    let icon: String
}
