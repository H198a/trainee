//
//  File.swift
//  CupidArrow
//
//  Created by admin on 04/04/25.
//

import Foundation
/*
 import UIKit
 import CountryPickerView  // Import the library

 class LoginVC: UIViewController, CountryPickerViewDelegate {

     @IBOutlet weak var txtPhone: UITextField!
     @IBOutlet weak var imgDropdown: UIImageView!
     @IBOutlet weak var btnPhoneDropdown: UIButton!

     let countryPicker = CountryPickerView()

     override func viewDidLoad() {
         super.viewDidLoad()
         
         setupCountryPicker()
     }

     func setupCountryPicker() {
         countryPicker.delegate = self
         countryPicker.showPhoneCodeInView = true  // Show phone code
         countryPicker.showCountryNameInView = false // Hide country name
         countryPicker.showFlagInView = false // Hide flag inside textField
         countryPicker.setCountryByPhoneCode("+91") // Default to India 🇮🇳

         // Set initial values
         txtPhone.text = countryPicker.selectedCountry.phoneCode
         imgDropdown.image = countryPicker.selectedCountry.flag
     }

     // MARK: CountryPickerViewDelegate
     func countryPickerView(_ countryPickerView: CountryPickerView, didSelectCountry country: Country) {
         txtPhone.text = country.phoneCode  // Set phone code
         imgDropdown.image = country.flag   // Set country flag
     }
     
     @IBAction func onClickPhoneDropdown(_ sender: UIButton) {
         countryPicker.showCountriesList(from: self) // Open country picker popup
     }
 }
 
 
 import UIKit

 class FirstViewController: UIViewController {
     @IBOutlet weak var progressView: UIProgressView!
     var currentStep = 1

     override func viewDidLoad() {
         super.viewDidLoad()
         updateProgress(currentStep: currentStep, totalSteps: 5)
     }

     func updateProgress(currentStep: Int, totalSteps: Int) {
         let progressValue = Float(currentStep) / Float(totalSteps)
         progressView.setProgress(progressValue, animated: true)
     }

     @IBAction func nextScreen(_ sender: UIButton) {
         let nextVC = SecondViewController()
         nextVC.currentStep = self.currentStep + 1
         self.navigationController?.pushViewController(nextVC, animated: true)
     }
 }

 
 import UIKit

 class SecondViewController: UIViewController {
     @IBOutlet weak var progressView: UIProgressView!
     var currentStep = 2

     override func viewDidLoad() {
         super.viewDidLoad()
         updateProgress(currentStep: currentStep, totalSteps: 5)
     }

     func updateProgress(currentStep: Int, totalSteps: Int) {
         let progressValue = Float(currentStep) / Float(totalSteps)
         progressView.setProgress(progressValue, animated: true)
     }

     @IBAction func nextScreen(_ sender: UIButton) {
         let nextVC = ThirdViewController()
         nextVC.currentStep = self.currentStep + 1
         self.navigationController?.pushViewController(nextVC, animated: true)
     }
 }


 */
