//
//  File.swift
//  CupidArrow
//
//  Created by Hemaxi S on 04/04/25.
//

import Foundation
/*
 import Foundation

 class UserRegistrationData {
     static let shared = UserRegistrationData()

     var name: String?
     var email: String?
     var gender: String?
     var age: String?
     var hobbies: [String] = [] // Your hobbies array

     private init() {}

     func reset() {
         name = nil
         email = nil
         gender = nil
         age = nil
         hobbies = []
     }

     func toDictionary() -> [String: Any] {
         return [
             "name": name ?? "",
             "email": email ?? "",
             "gender": gender ?? "",
             "age": age ?? "",
             "hobbies": hobbies
         ]
     }
 }

 UserRegistrationData.shared.name = nameTextField.text
 UserRegistrationData.shared.email = emailTextField.text
 UserRegistrationData.shared.gender = selectedGender
 UserRegistrationData.shared.age = ageTextField.text
 UserRegistrationData.shared.hobbies = selectedIndexes.map { arrLabel[$0] }
 
 
 import UIKit
 import Firebase

 class SubmitVC: UIViewController {

     override func viewDidLoad() {
         super.viewDidLoad()
     }

     @IBAction func onClickSubmit(_ sender: UIButton) {
         let data = UserRegistrationData.shared.toDictionary()

         let dbRef = Database.database().reference()
         let usersRef = dbRef.child("users").childByAutoId()

         usersRef.setValue(data) { error, _ in
             if let error = error {
                 print("🔥 Error: \(error.localizedDescription)")
                 self.showAlert(title: "Error", message: "Failed to save data.")
             } else {
                 print("✅ Data saved successfully")
                 UserRegistrationData.shared.reset()
                 self.showAlert(title: "Success", message: "Data saved to Firebase.")
             }
         }
     }

     func showAlert(title: String, message: String) {
         let alert = UIAlertController(title: title,
                                       message: message,
                                       preferredStyle: .alert)
         alert.addAction(UIAlertAction(title: "OK",
                                       style: .default))
         self.present(alert, animated: true)
     }
 }



 let rowHeight = pickerView.frame.height * 0.1  // Row height is 10% of picker view height
 (i == 0 ? -rowHeight / 2 : rowHeight / 2):

 This is a conditional (ternary) operator. It checks if i == 0 (i.e., if the index i is 0).

 If i == 0 is true, then it subtracts rowHeight / 2 from the center (pickerView.frame.height / 2), meaning it moves the row upwards.

 If i != 0, it adds rowHeight / 2 to the center, meaning it moves the row downwards.

 This ensures that the first row is positioned above the center and subsequent rows are positioned below the center, adjusting for the height of the rows.

 In summary:
 The line calculates the y position (vertical position) for each row in the picker view.

 If i == 0, the row is positioned above the center, and for all other rows (i != 0), it is positioned below the center.
*/
