//
//  File.swift
//  CupidArrow
//
//  Created by Hemaxi S on 04/04/25.
//

import Foundation
/*
 import Foundation

 class UserRegistrationData {
     static let shared = UserRegistrationData()

     var name: String?
     var email: String?
     var gender: String?
     var age: String?
     var hobbies: [String] = [] // Your hobbies array

     private init() {}

     func reset() {
         name = nil
         email = nil
         gender = nil
         age = nil
         hobbies = []
     }

     func toDictionary() -> [String: Any] {
         return [
             "name": name ?? "",
             "email": email ?? "",
             "gender": gender ?? "",
             "age": age ?? "",
             "hobbies": hobbies
         ]
     }
 }

 UserRegistrationData.shared.name = nameTextField.text
 UserRegistrationData.shared.email = emailTextField.text
 UserRegistrationData.shared.gender = selectedGender
 UserRegistrationData.shared.age = ageTextField.text
 UserRegistrationData.shared.hobbies = selectedIndexes.map { arrLabel[$0] }
 
 
 import UIKit
 import Firebase

 class SubmitVC: UIViewController {

     override func viewDidLoad() {
         super.viewDidLoad()
     }

     @IBAction func onClickSubmit(_ sender: UIButton) {
         let data = UserRegistrationData.shared.toDictionary()

         let dbRef = Database.database().reference()
         let usersRef = dbRef.child("users").childByAutoId()

         usersRef.setValue(data) { error, _ in
             if let error = error {
                 print("🔥 Error: \(error.localizedDescription)")
                 self.showAlert(title: "Error", message: "Failed to save data.")
             } else {
                 print("✅ Data saved successfully")
                 UserRegistrationData.shared.reset()
                 self.showAlert(title: "Success", message: "Data saved to Firebase.")
             }
         }
     }

     func showAlert(title: String, message: String) {
         let alert = UIAlertController(title: title,
                                       message: message,
                                       preferredStyle: .alert)
         alert.addAction(UIAlertAction(title: "OK",
                                       style: .default))
         self.present(alert, animated: true)
     }
 }



 let rowHeight = pickerView.frame.height * 0.1  // Row height is 10% of picker view height
 (i == 0 ? -rowHeight / 2 : rowHeight / 2):

 This is a conditional (ternary) operator. It checks if i == 0 (i.e., if the index i is 0).

 If i == 0 is true, then it subtracts rowHeight / 2 from the center (pickerView.frame.height / 2), meaning it moves the row upwards.

 If i != 0, it adds rowHeight / 2 to the center, meaning it moves the row downwards.

 This ensures that the first row is positioned above the center and subsequent rows are positioned below the center, adjusting for the height of the rows.

 In summary:
 The line calculates the y position (vertical position) for each row in the picker view.

 If i == 0, the row is positioned above the center, and for all other rows (i != 0), it is positioned below the center.
 
 
 if storeDataToFirebase == nil {
      storeDataToFirebase = storeDataFire()
  }
 
 
 @IBAction func onClickSubmit(_ sender: UIButton) {
     guard var userData = storeDataToFirebase else {
         print("No user data to submit.")
         return
     }

     // Optional: Generate a new user ID or use current Firebase Auth UID
     userData.id = UUID().uuidString
     
     // If uploading image, do that first
     if let image = userData.userImage {
         uploadUserImage(image) { imageURL in
             self.saveUserToFirebase(userData: userData, imageUrl: imageURL)
         }
     } else {
         saveUserToFirebase(userData: userData, imageUrl: nil)
     }
 }
 func saveUserToFirebase(userData: storeDataFire, imageUrl: String?) {
     var data: [String: Any] = [
         "id": userData.id ?? "",
         "name": userData.name ?? "",
         "email": userData.email ?? "",
         "age": userData.age ?? "",
         "gender": userData.gender ?? "",
         "phone": userData.phone ?? "",
         "verificationCode": userData.verificationCode ?? "",
         "interests": userData.interests.compactMap { $0 },
         "lookingFor": userData.lookingFor ?? "",
         "location": userData.location.compactMap { $0 },
     ]

     if let imageUrl = imageUrl {
         data["userImage"] = imageUrl
     }

     let db = Firestore.firestore()
     db.collection("users").document(userData.id ?? UUID().uuidString).setData(data) { error in
         if let error = error {
             print("Error saving user: \(error.localizedDescription)")
         } else {
             print("User successfully saved to Firebase!")
             // Navigate or show success screen
         }
     }
 }

 
 func uploadUserImage(_ image: UIImage, completion: @escaping (_ url: String?) -> Void) {
     guard let imageData = image.jpegData(compressionQuality: 0.7) else {
         completion(nil)
         return
     }

     let storageRef = Storage.storage().reference().child("user_images/\(UUID().uuidString).jpg")
     storageRef.putData(imageData, metadata: nil) { metadata, error in
         if let error = error {
             print("Image upload error: \(error.localizedDescription)")
             completion(nil)
             return
         }

         storageRef.downloadURL { url, error in
             if let downloadURL = url?.absoluteString {
                 completion(downloadURL)
             } else {
                 completion(nil)
             }
         }
     }
 }

*/
