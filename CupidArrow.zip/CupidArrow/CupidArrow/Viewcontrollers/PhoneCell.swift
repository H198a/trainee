//
//  PhoneCell.swift
//  CupidArrow
//
//  Created by Hemaxi S on 03/04/25.
//

import UIKit
import DropDown

class PhoneCell: DropDownCell {
//    @IBOutlet weak var ImgDrop: UIImageView!
//     @IBOutlet weak var optionLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
