//
//  LocationVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 08/04/25.
//

import UIKit

class LocationVC: UIViewController {
    @IBOutlet weak var btnAllowManually: UIButton!
    @IBOutlet weak var btnlocationAccess: UIButton!

    var storeDataToFirebase: storeDataFire?
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        storeDataToFirebase = storeDataFire()
    }
    @IBAction func onClickAllowLocation(_ sender: Any) {
        LocationManager.shared.requestLocation { [weak self] status in
            DispatchQueue.main.async {
                if status == .authorizedWhenInUse || status == .authorizedAlways {
                    self!.storeDataToFirebase?.location = ["ind","ahm"]
                    print(self!.storeDataToFirebase?.location)
                    // Permission granted → Navigate to next screen
                    //here is storedaata to firebasedata functiona called
                    self?.navigationController?.popViewController(animated: false)
                } else {
                    //  Permission not granted → Stay on same screen or show alert
                    let alert = UIAlertController(title: "Permission Denied",
                                                  message: "Please allow location access to continue.",
                                                  preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self?.present(alert, animated: true)
                }
            }
        }
    }
}
//MARK: SetUp UI
extension LocationVC{
    func setUP(){
        let attributedString = NSAttributedString(
            string: "Enter Location Manually",
            attributes: [
                .foregroundColor: UIColor.btn,
                .font: UIFont.setFont(type: .Bold, size: 18)
            ]
        )
        let attributedStringBtn = NSAttributedString(
            string: "Allow Location Access",
            attributes: [
                .foregroundColor: UIColor.white,
                .font: UIFont.setFont(type: .Bold, size: 18)
            ]
        )
        btnAllowManually.setAttributedTitle(attributedString, for: .normal)
        btnlocationAccess.setAttributedTitle(attributedStringBtn, for: .normal)
    }
}
