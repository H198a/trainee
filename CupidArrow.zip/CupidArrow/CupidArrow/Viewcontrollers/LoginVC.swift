//
//  LoginVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 03/04/25.
//

import UIKit
import DropDown

class LoginVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var btnphonedropdown: UIButton!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var dropdownView: UIView!
    @IBOutlet weak var txtEnterPhone: UITextField!
    @IBOutlet weak var imgDropdown: UIImageView!
    
    let phoneDropdown = DropDown()
    var arrCategory: [Category] = []
    //var arrList: [Category] = []
   // var selectedCategoryImage: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        arrCategory = getCountryList()
        setUpDropDown()
        setUP()
    }
    
    @IBAction func onClickSignUp(_ sender: Any) {
        
    }
    
    @IBAction func onClickPhoneDropdown(_ sender: Any) {
        print("button clicked")
        phoneDropdown.show()
    }
}
//MARK: SetUp UI
extension LoginVC{
    func setUP(){
        txtEnterPhone.borderStyle = .none
        txtPhone.borderStyle = .none
    }
}
//MARK: Custom Functions
extension LoginVC{
    func setUpDropDown(){
        phoneDropdown.textFont = UIFont.systemFont(ofSize: 19)
        
        
        phoneDropdown.anchorView = dropdownView // UIView or UIBarButtonItem
        arrCategory = getCountryList()
        phoneDropdown.dataSource = arrCategory.map { $0.name }
        /*** IMPORTANT PART FOR CUSTOM CELLS ***/
        phoneDropdown.cellNib = UINib(nibName: "PhoneCell", bundle: nil)
        //phoneDropdown.cellIdentifier = "PhoneCell"
        
        phoneDropdown.customCellConfiguration = { (index: Int, item: String, cell: DropDownCell) in
            guard let cell = cell as? DropDownCell else { return }
            let country = self.arrCategory[index]

            cell.optionLabel.text = country.name
            
            // Use country code as image name (e.g., "us", "in", "gb")
            let imageName = country.icon.lowercased()
            cell.ImgDrop.image = UIImage(named: imageName) // Load from Assets
        }
        phoneDropdown.selectionAction = { (index: Int, item: String) in
            self.txtPhone.text = item
           
            let category = self.arrCategory[index]
            self.imgDropdown.image = UIImage(named: category.icon.lowercased())
           // self.selectedCategoryImage = category.name // Save image name
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        phoneDropdown.bottomOffset = CGPoint(x: 0, y:(phoneDropdown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        phoneDropdown.topOffset = CGPoint(x: 0, y:-(phoneDropdown.anchorView?.plainView.bounds.height)!)
        phoneDropdown.direction = .bottom
        phoneDropdown.textFont = UIFont.systemFont(ofSize: 19)
        phoneDropdown.cellHeight = 80
        phoneDropdown.backgroundColor = .black
        phoneDropdown.textColor = .white
        //phoneDropdown.cornerRadius = 10
    }
    func getCountryList() -> [Category] {
        var countries: [Category] = []
        
        for region in Locale.Region.isoRegions {
            if let countryName = Locale.current.localizedString(forRegionCode: region.identifier) {
                countries.append(Category(name: countryName, icon: region.identifier))
            }
        }
        
        return countries.sorted { $0.name < $1.name } // Sort alphabetically
    }
}
