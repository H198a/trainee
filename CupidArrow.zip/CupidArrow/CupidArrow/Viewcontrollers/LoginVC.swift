//
//  LoginVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 03/04/25.
//

import UIKit
import DropDown
import CountryPickerView

class LoginVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var btnphonedropdown: UIButton!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var dropdownView: UIView!
    @IBOutlet weak var txtEnterPhone: UITextField!
    @IBOutlet weak var dropdownImg: UIImageView!
    let countryPicker = CountryPickerView()
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        countryPicker.delegate = self
        setCountyPickerView()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func onClickContinue(_ sender: Any) {
        if validateFields(){
            
        }
    }
}
//MARK: SetUp UI
extension LoginVC{
    func setUP(){
        txtPhone.borderStyle = .none
        txtEnterPhone.borderStyle = .none
        txtEnterPhone.keyboardType = .numberPad
        //txtEnterPhone.font = .setFont(type: .Regular, size: 18)
        txtPhone.text = "+91"
        dropdownImg.image = UIImage(named: "India")
//        txtEnterPhone.attributedPlaceholder =  NSAttributedString(string: "Enter your Number", attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray.cgColor, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20)])
//        
    }
}
//MARK: Custom Functions
extension LoginVC{
    func setCountyPickerView(){
        countryPicker.showPhoneCodeInView = true
        countryPicker.showCountryNameInView = false
//        countryPicker.showFlagInView = false
        countryPicker.setCountryByPhoneCode("+91")
        
        txtPhone.text = countryPicker.selectedCountry.phoneCode
        txtEnterPhone.attributedPlaceholder = NSAttributedString(
            string: txtEnterPhone.placeholder ?? "Enter Phone",
            attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 17)]
        )
        dropdownImg.image = countryPicker.selectedCountry.flag
    }
    func validateFields() -> Bool {
        var isValid = true
            
        // Validate Name
        if let number = txtEnterPhone.text, number.isEmpty {
            showAlert(message: "Please enter your mobile number")
            isValid = false
        }
//        // Validate Email
//        if let email = emailTxtFld.text {
//            if email.isEmpty {
//                showAlert(message: "Please enter your email.")
//                return false
//            } else if !Helper.shared.validateEmailId(email) {
//                showAlert(message: "Please enter a valid email address.")
//                return false
//            }
//        }
//            // Validate Password
//        if let password = passTxtFld.text {
//            if password.isEmpty {
//                showAlert(message: "Please enter your password.")
//                return false
//            } else if !Helper.shared.validatePassword(password) {
//                showAlert(message: "Password must contain at least 8 characters, including 1 letter and 1 number.")
//                return false
//            }
//        }
//            // Validate Confirm Password
//        if let confirmPassword = rePassTxtFld.text {
//            if confirmPassword.isEmpty {
//                showAlert(message: "Please confirm your password.")
//                return false
//            } else if confirmPassword != passTxtFld.text {
//                showAlert(message: "Passwords do not match.")
//                return false
//            }
//        }
        return isValid
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
//MARK: CountryPickerViewDelegate
extension LoginVC: CountryPickerViewDelegate{
    func countryPickerView(_ countryPickerView: CountryPickerView, didSelectCountry country: Country) {
        txtPhone.text = country.phoneCode  // Set phone code
        dropdownImg.image = country.flag   // Set country flag
    }
}
//MARK: Click Events
extension LoginVC{
    @IBAction func onClickSignUp(_ sender: Any) {
            let signupVC = storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as? SignUpVC
            navigationController?.pushViewController(signupVC!, animated: false)
    }
    
    @IBAction func onClickPhoneDropdown(_ sender: Any) {
       // phoneDropdown.show()
        countryPicker.showCountriesList(from: self)
    }
}
//
