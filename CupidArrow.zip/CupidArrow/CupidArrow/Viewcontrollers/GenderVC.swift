//
//  GenderVC.swift
//  CupidArrow
//
//  Created by admin on 05/04/25.
//

import UIKit

class GenderVC: UIViewController {
//MARK: Outlet and variabble declaration
    @IBOutlet weak var progressBar: UIProgressView!
    var currentStep = 6
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        updateProgress(currentStep: currentStep, totalSteps: 9)
    }
    @IBAction func onClickContinue(_ sender: Any) {
        let nameandEmailVc = storyboard?.instantiateViewController(withIdentifier: "LookingForVC") as? LookingForVC
        nameandEmailVc?.currentStep = self.currentStep + 1
        navigationController?.pushViewController(nameandEmailVc!, animated: false)
    }
    
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
}
//MARK: Setup UI
extension GenderVC{
    func setUp() {
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Functions
extension GenderVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
}
