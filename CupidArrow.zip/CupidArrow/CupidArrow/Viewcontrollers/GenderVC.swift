//
//  GenderVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 07/04/25.
//

import UIKit


class GenderVC: UIViewController {
//MARK: Outlet and variable Declaration
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var maleImg: UIImageView!
    @IBOutlet weak var femaleImg: UIImageView!
    @IBOutlet weak var btnMale: UIButton!
    @IBOutlet weak var btnFemale: UIButton!
    @IBOutlet weak var lblMale: UILabel!
    @IBOutlet weak var lblFemale: UILabel!
    @IBOutlet weak var maleView: UIControl!
    @IBOutlet weak var femaleView: UIView!
    
    var currentStep = 6
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        updateProgress(currentStep: currentStep, totalSteps: 9)
    }

    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onClickContinue(_ sender: Any) {
        let genderVC = storyboard?.instantiateViewController(withIdentifier: "LookingForVC") as? LookingForVC
        genderVC?.currentStep = self.currentStep + 1
        navigationController?.pushViewController(genderVC!, animated: false)
    }
    
    @IBAction func viewOnClicale(_ sender: UIControl) {
      
        
    }
    @IBAction func onClickale(_ sender: Any) {
        print("uibutton")
    }
    
    @IBAction func onClicale(_ sender: Any) {
    
    }

    @IBAction func onClickMale(_ sender: UIControl) {
        print("uicontroll")
        maleView.backgroundColor = .btn
        lblMale.textColor = .white
        maleImg.image = maleImg.image!.withRenderingMode(.alwaysTemplate)
        maleImg.tintColor = .white
        
        femaleView.backgroundColor = .female
        lblFemale.textColor = .black
        femaleImg.image = femaleImg.image!.withRenderingMode(.alwaysTemplate)
        femaleImg.tintColor = .black
    }
    
    @IBAction func onClickFemale(_ sender: UIControl) {
        print("femlaebutton")
        femaleView.backgroundColor = .btn
        lblFemale.textColor = .white
        femaleImg.image = femaleImg.image!.withRenderingMode(.alwaysTemplate)
        femaleImg.tintColor = .white
        
        maleView.backgroundColor = .female
        lblMale.textColor = .black
        maleImg.image = maleImg.image!.withRenderingMode(.alwaysTemplate)
        maleImg.tintColor = .black
    }
    
    
}
//MARK: SetUp UI
extension GenderVC{
    func setUP(){
//        femaleImg.image = femaleImg.image!.withRenderingMode(.alwaysTemplate)
//        femaleImg.tintColor = UIColor.black
//        maleImg.image = maleImg.image!.withRenderingMode(.alwaysTemplate)
//        maleImg.tintColor = UIColor.white
        // Scaling the progress bar (optional, as per your code)
        maleView.layer.cornerRadius = maleView.frame.size.width / 2
        femaleView.layer.cornerRadius = femaleView.frame.size.width / 2
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Functions
extension GenderVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
}
