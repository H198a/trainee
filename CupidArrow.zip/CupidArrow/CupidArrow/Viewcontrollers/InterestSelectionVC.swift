//
//  InterestSelectionVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 07/04/25.
//

import UIKit

class InterestSelectionVC: UIViewController {
    //MARK: Outlet and Variable Declaration
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var cvInterest: UICollectionView!
    var currentStep = 8
    var selectedIndexes = [Int]()
    var arrImg = ["camera","Photography","Gaming","Music","Travel","Painting","Politics","Charity","Cooking","Pets","Sports","Fashion"]//9
    var arrLabel = ["Reading","Photography","Gaming","Music","Travel","Painting","Politics","Charity","Cooking","Pets","Sports","Fashion"]//12
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        updateProgress(currentStep: currentStep, totalSteps: 9)
        // Do any additional setup after loading the view.
    }
}
//MARK: SetUp UI
extension InterestSelectionVC{
    func setUP(){
        let nibName = UINib(nibName: "InterestCell", bundle: nil)
        cvInterest.register(nibName, forCellWithReuseIdentifier: "InterestCell")
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Functions
extension InterestSelectionVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
//MARK: Collectio
extension InterestSelectionVC: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrLabel.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "InterestCell", for: indexPath) as! InterestCell
        cell.interestImg.image = UIImage(named: arrImg[indexPath.row])
        cell.lblInterest.text = arrLabel[indexPath.row]
        cell.mainView.backgroundColor = .btn
        cell.mainView.layer.cornerRadius = 25
        cell.interestImg.image = cell.interestImg.image!.withRenderingMode(.alwaysTemplate)
        cell.interestImg.tintColor = .btn
        
        if selectedIndexes.contains(indexPath.row) {
            cell.mainView.backgroundColor = .btn
            cell.lblInterest.textColor = .white
            cell.interestImg.tintColor = .white
        } else {
            cell.mainView.backgroundColor = .white
            cell.lblInterest.textColor = .black
            cell.interestImg.tintColor = .btn
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let index = selectedIndexes.firstIndex(of: indexPath.row) {
            // Deselect the item
            selectedIndexes.remove(at: index)
        } else {
            // Only allow selection if there are fewer than 3 selected items
            if selectedIndexes.count < 3 {
                selectedIndexes.append(indexPath.row)
            } else{
                showAlert(message: "cant select more than 3 Interest")
            }
        }
        collectionView.reloadItems(at: [indexPath])
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (cvInterest.frame.width - 10) / 2, height: 60)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5//spacing between two rows
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1//spacing between two items
    }
}

//MARK: Click Events
extension InterestSelectionVC{
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onClickContinue(_ sender: Any) {
        let genderVC = storyboard?.instantiateViewController(withIdentifier: "ImageVC") as? ImageVC
        genderVC?.currentStep = self.currentStep + 1
        if selectedIndexes.count >= 1 {
            navigationController?.pushViewController(genderVC!, animated: false)
        } else{
            showAlert(message: "please select atleast 1 interests")
        }
    }
}
