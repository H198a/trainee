//
//  InterestSelectionVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 07/04/25.
//
import UIKit


class CenterAlignedFlowLayout: UICollectionViewFlowLayout {
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        guard let attributes = super.layoutAttributesForElements(in: rect) else { return nil }

        var currentRowY: CGFloat = -1
        var rowItems: [UICollectionViewLayoutAttributes] = []
        var centeredAttributes: [UICollectionViewLayoutAttributes] = []

        for attribute in attributes {
            guard attribute.representedElementCategory == .cell else {
                centeredAttributes.append(attribute)
                continue
            }

            if attribute.frame.origin.y > currentRowY {
                // Process the previous row
                if !rowItems.isEmpty {
                    centerRow(rowItems)
                    centeredAttributes.append(contentsOf: rowItems)
                }
                rowItems = [attribute]
                currentRowY = attribute.frame.origin.y
            } else {
                rowItems.append(attribute)
            }
        }

        // Center the last row
        if !rowItems.isEmpty {
            centerRow(rowItems)
            centeredAttributes.append(contentsOf: rowItems)
        }

        return centeredAttributes
    }

    private func centerRow(_ rowAttributes: [UICollectionViewLayoutAttributes]) {
        guard let collectionView = collectionView, !rowAttributes.isEmpty else { return }

        let totalCellWidth = rowAttributes.reduce(0) { $0 + $1.frame.width }
        let totalSpacingWidth = minimumInteritemSpacing * CGFloat(rowAttributes.count - 1)
        let totalRowWidth = totalCellWidth + totalSpacingWidth

        let availableWidth = collectionView.bounds.width - sectionInset.left - sectionInset.right
        let alignmentOffset = (availableWidth - totalRowWidth) / 2

        var currentXOffset = sectionInset.left + alignmentOffset

        for attribute in rowAttributes {
            attribute.frame.origin.x = currentXOffset
            currentXOffset += attribute.frame.width + minimumInteritemSpacing
        }
    }
}

import UIKit

class InterestSelectionVC: UIViewController {
    //MARK: Outlet and Variable Declaration
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var cvInterest: UICollectionView!
    var currentStep = 8
    var storeDataToFirebase: storeDataFire?
    var selectedIndexes = [Int]()
    var arrImg = ["camera","Photography","Gaming","Music","Travel","Painting","Politics","Charity","Cooking","Pets","Sports","Fashion"]//9
    var arrLabel = ["Reading","Photography","Gaming","Music","Travel","Painting","Politics","Charity","Cooking","Pets","Sports","Fashion"]//12
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        let layout = CenterAlignedFlowLayout()
          layout.minimumInteritemSpacing = 1
          layout.minimumLineSpacing = 1
          layout.sectionInset = .zero
//        let width = (view.frame.width - 10) / 3 // Example: 3 items per row
//          layout.itemSize = CGSize(width: width, height: 40)
        layout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        cvInterest.collectionViewLayout = layout
        updateProgress(currentStep: currentStep, totalSteps: 9)
        // Do any additional setup after loading the view.
    }
}
//MARK: SetUp UI
extension InterestSelectionVC{
    func setUP(){
        let nibName = UINib(nibName: "InterestCell", bundle: nil)
        cvInterest.register(nibName, forCellWithReuseIdentifier: "InterestCell")
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Functions
extension InterestSelectionVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
//MARK: Collectio
extension InterestSelectionVC: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrLabel.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "InterestCell", for: indexPath) as! InterestCell
        cell.interestImg.image = UIImage(named: arrImg[indexPath.row])
        cell.lblInterest.text = arrLabel[indexPath.row]
        cell.mainView.backgroundColor = .btn
        cell.mainView.layer.cornerRadius = 25
        cell.interestImg.image = cell.interestImg.image!.withRenderingMode(.alwaysTemplate)
        cell.interestImg.tintColor = .btn
        
        if selectedIndexes.contains(indexPath.row) {
            cell.mainView.backgroundColor = .btn
            cell.lblInterest.textColor = .white
            cell.interestImg.tintColor = .white
        } else {
            cell.mainView.backgroundColor = .white
            cell.lblInterest.textColor = .black
            cell.interestImg.tintColor = .btn
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let index = selectedIndexes.firstIndex(of: indexPath.row) {
            // Deselect the item
            selectedIndexes.remove(at: index)
        } else {
            // Only allow selection if there are fewer than 3 selected items
            if selectedIndexes.count < 3 {
                selectedIndexes.append(indexPath.row)
            } else{
                showAlert(message: "cant select more than 3 Interest")
            }
        }
        collectionView.reloadItems(at: [indexPath])
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.bounds.width - 40) / 3 // adjust as needed
        return CGSize(width: width, height: width + 20)
    }
    
}

//MARK: Click Events
extension InterestSelectionVC{
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onClickContinue(_ sender: Any) {
        storeDataToFirebase = storeDataFire()
        let genderVC = storyboard?.instantiateViewController(withIdentifier: "ImageVC") as? ImageVC
        if selectedIndexes.count >= 1 {
            // Map selectedIndexes to the actual interest names
            let selectedInterests = selectedIndexes.map { arrLabel[$0] }
            // Save to storeDataToFirebase
            storeDataToFirebase?.interests = selectedInterests
            print(selectedInterests)
            genderVC?.currentStep = self.currentStep + 1
            genderVC?.storeDataToFirebase = self.storeDataToFirebase
            navigationController?.pushViewController(genderVC!, animated: false)
        } else{
            showAlert(message: "please select atleast 1 interests")
        }
    }
}
