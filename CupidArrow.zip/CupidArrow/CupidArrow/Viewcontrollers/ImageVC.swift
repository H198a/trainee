//
//  ImageVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 07/04/25.
//

import UIKit
enum ImageSelection{
    case first
    case second
    case third
    case fourth
    case fifth
    case mainViewImg
}
class ImageVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var mainImg: UIButton!
    @IBOutlet weak var selectImg: UIImageView!
    @IBOutlet weak var firstImg: UIImageView!
    @IBOutlet weak var secondImg: UIImageView!
    @IBOutlet weak var thirdImg: UIImageView!
    @IBOutlet weak var fourthImg: UIImageView!
    @IBOutlet weak var fifthImg: UIImageView!
    var currentStep = 9
    var selectedImage: ImageSelection?
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        updateProgress(currentStep: currentStep, totalSteps: 9)
    }
    @IBAction func clickOnBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    @IBAction func onClickContinue(_ sender: Any) {
        let nameandEmailVc = storyboard?.instantiateViewController(withIdentifier: "LocationVC") as? LocationVC
        navigationController?.pushViewController(nameandEmailVc!, animated: false)
    }
    
    @IBAction func onClickImage(_ sender: Any) {
        selectedImage = .mainViewImg
        setImage()
    }
    
    @IBAction func onClickFirstImg(_ sender: Any) {
        selectedImage = .first
        setImage()
    }
    
    @IBAction func onClicksecondImg(_ sender: Any) {
        selectedImage = .second
        setImage()
    }
    
    @IBAction func onClickThirdImg(_ sender: Any) {
        selectedImage = .third
        setImage()
    }
    
    @IBAction func onClickFourthImg(_ sender: Any) {
        selectedImage = .fourth
        setImage()
    }
    
    @IBAction func onClickFifthImg(_ sender: Any) {
        selectedImage = .fifth
        setImage()
    }
}
//MARK: setUpUI
extension ImageVC{
    func setUP(){
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Functions
extension ImageVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
    func setImage(){
        let imagePickerVC = UIImagePickerController()
        imagePickerVC.sourceType = .photoLibrary
        imagePickerVC.delegate = self // new
        present(imagePickerVC, animated: true)
    }
}
//MARK: UIImagePickerControllerDelegate,UINavigationControllerDelegate
extension ImageVC: UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        if let image = info[.originalImage] as? UIImage {
            switch selectedImage{
            case .mainViewImg:
                selectImg.image = image
            case .first:
                firstImg.image = image
            case .second:
                secondImg.image = image
            case.third:
                thirdImg.image = image
            case .fourth:
                fourthImg.image = image
            case .fifth:
                fifthImg.image = image
            default:
                return
            }
        }
    }
}
