//
//  ViewController.swift
//  CupidArrow
//
//  Created by Hemaxi S on 03/04/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onClickloginWithPhone(_ sender: Any) {
        let loginVc = storyboard?.instantiateViewController(withIdentifier: "LoginVC") as? LoginVC
        navigationController?.pushViewController(loginVc!, animated: false)
    }
    
    @IBAction func onClickSignUp(_ sender: Any) {
        
    }
}

