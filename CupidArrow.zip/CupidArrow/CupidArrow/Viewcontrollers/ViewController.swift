//
//  ViewController.swift
//  CupidArrow
//
//  Created by Hemaxi S on 03/04/25.
//

import UIKit

class ViewController: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var txtSubText: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setUP()
    }
    
    @IBAction func onClickloginWithPhone(_ sender: Any) {
        let loginVc = storyboard?.instantiateViewController(withIdentifier: "LoginVC") as? LoginVC
        navigationController?.pushViewController(loginVc!, animated: true)
    }
    
    @IBAction func onClickSignUp(_ sender: Any) {
        let signupVC = storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as? SignUpVC
        navigationController?.pushViewController(signupVC!, animated: false)
    }
}
//MARK: SetUp UI
extension ViewController{
    func setUP(){
        txtSubText.font = .setFont(type: .Regular, size: 17)
        lblHeading.font = .setFont(type: .Bold, size: 29)
    }
}
