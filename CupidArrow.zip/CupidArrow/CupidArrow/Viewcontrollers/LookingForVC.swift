//
//  LookingForVC.swift
//  CupidArrow
//
//  Created by admin on 06/04/25.
//

import UIKit

class LookingForVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var progressView: UIProgressView!
    var currentStep = 7
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        updateProgress(currentStep: currentStep, totalSteps: 9)
        // Do any additional setup after loading the view.
    }
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onClickContinue(_ sender: Any) {
        
    }
    
}
//MARK: SetUP UI
extension LookingForVC{
    func setUp() {
        // Scaling the progress bar (optional, as per your code)
        progressView.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressView.layer.cornerRadius = 5
        progressView.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressView.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Functions
extension LookingForVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressView.setProgress(progressValue, animated: false)
    }
}
