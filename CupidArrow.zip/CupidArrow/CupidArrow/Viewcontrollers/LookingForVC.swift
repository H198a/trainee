//
//  LookingForVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 07/04/25.
//

import UIKit

class LookingForVC: UIViewController {
//MARK: Outlet and Variable Declaration
    
    @IBOutlet weak var subView: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var secondmainView: UIView!
    @IBOutlet weak var seconfSubView: UIView!
    @IBOutlet weak var thirdMainView: UIView!
    @IBOutlet weak var thirdSubView: UIView!
    @IBOutlet weak var fourthMainView: UIView!
    @IBOutlet weak var fourthSubView: UIView!
    @IBOutlet weak var progressBar: UIProgressView!
    var currentStep = 7
    var storeDataToFirebase: storeDataFire?
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        updateProgress(currentStep: currentStep, totalSteps: 9)
        storeDataToFirebase = storeDataFire()
    }
    
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onClickContinue(_ sender: Any) {
        let genderVC = storyboard?.instantiateViewController(withIdentifier: "InterestSelectionVC") as? InterestSelectionVC
        genderVC?.currentStep = self.currentStep + 1
        genderVC?.storeDataToFirebase = self.storeDataToFirebase
        navigationController?.pushViewController(genderVC!, animated: false)
    }
    
    @IBAction func onClickFirstOption(_ sender: Any) {
        subView.layer.borderWidth = 4
        subView.layer.borderColor = UIColor.btn.cgColor
        mainView.layer.cornerRadius = 25
        mainView.layer.borderWidth = 2
        mainView.layer.borderColor = UIColor.btn.cgColor
        
        self.secondView()
        self.thirdView()
        self.fourthView()
        storeDataToFirebase?.lookingFor = "1st"
    }
    
    @IBAction func onClickSecondOption(_ sender: Any) {
        seconfSubView.layer.borderWidth = 4
        seconfSubView.layer.borderColor = UIColor.btn.cgColor
        secondmainView.layer.cornerRadius = 25
        secondmainView.layer.borderWidth = 2
        secondmainView.layer.borderColor = UIColor.btn.cgColor
        
        self.firstView()
        self.thirdView()
        self.fourthView()
        storeDataToFirebase?.lookingFor = "2nd"
    }
    
    @IBAction func onClickTHirdOption(_ sender: Any) {
        thirdSubView.layer.borderWidth = 4
        thirdSubView.layer.borderColor = UIColor.btn.cgColor
        thirdMainView.layer.cornerRadius = 25
        thirdMainView.layer.borderWidth = 2
        thirdMainView.layer.borderColor = UIColor.btn.cgColor
        
        self.firstView()
        self.secondView()
        self.fourthView()
        storeDataToFirebase?.lookingFor = "3rd"
        print(storeDataToFirebase?.lookingFor)
    }
    
    @IBAction func onClickFourthOption(_ sender: Any) {
        fourthSubView.layer.borderWidth = 4
        fourthSubView.layer.borderColor = UIColor.btn.cgColor
        fourthMainView.layer.cornerRadius = 25
        fourthMainView.layer.borderWidth = 2
        fourthMainView.layer.borderColor = UIColor.btn.cgColor
        
        self.firstView()
        self.secondView()
        self.thirdView()
        storeDataToFirebase?.lookingFor = "4th"
        print(storeDataToFirebase?.lookingFor)
    }
}
//MARK: SetUp UI
extension LookingForVC{
    func setUP(){
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Function
extension LookingForVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
    func firstView(){
        subView.layer.borderWidth = 2
        subView.layer.borderColor = UIColor.lightGray.cgColor
        mainView.layer.cornerRadius = 25
        mainView.layer.borderColor = UIColor.clear.cgColor
    }
    func secondView(){
        seconfSubView.layer.borderWidth = 2
        seconfSubView.layer.borderColor = UIColor.lightGray.cgColor
        secondmainView.layer.cornerRadius = 25
//        secondmainView.layer.borderWidth = 0
        secondmainView.layer.borderColor = UIColor.clear.cgColor
    }
    func thirdView(){
        thirdSubView.layer.borderWidth = 2
        thirdSubView.layer.borderColor = UIColor.lightGray.cgColor
        thirdMainView.layer.cornerRadius = 25
        thirdMainView.layer.borderColor = UIColor.clear.cgColor
    }
    func fourthView(){
        fourthSubView.layer.borderWidth = 2
        fourthSubView.layer.borderColor = UIColor.lightGray.cgColor
        fourthMainView.layer.cornerRadius = 25
        fourthMainView.layer.borderColor = UIColor.clear.cgColor
    }
}
