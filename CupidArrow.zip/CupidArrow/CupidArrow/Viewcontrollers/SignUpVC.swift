//
//  SignUpVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 04/04/25.
//

import UIKit
import CountryPickerView

class SignUpVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtEnterPhone: UITextField!
    @IBOutlet weak var dropdownImg: UIImageView!
    let countryPicker = CountryPickerView()
    var currentStep = 1
    var storeDataToFirebase: storeDataFire?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        countryPicker.delegate = self
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    @IBAction func onClickBackButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onClickPhoneDropdown(_ sender: Any) {
        countryPicker.showCountriesList(from: self)
    }
    
    @IBAction func onClickContinueToOTP(_ sender: Any) {
        storeDataToFirebase = storeDataFire()
        storeDataToFirebase?.phone = txtEnterPhone.text
        let name = storeDataToFirebase?.phone
        print(name!)
        if validateFields(){
            let otpVC = storyboard?.instantiateViewController(withIdentifier: "OTPVC") as? OTPVC
            otpVC?.currentStep = self.currentStep + 1
            otpVC?.storeDatatoFIrebase = self.storeDataToFirebase
            navigationController?.pushViewController(otpVC!, animated: false)
        }
    }
}
//MARK: SetUP UI
extension SignUpVC{
    func setUP(){
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
        //progressBar.layer.cornerRadius = 10
        txtPhone.borderStyle = .none
        txtEnterPhone.borderStyle = .none
        txtEnterPhone.keyboardType = .numberPad
        //txtEnterPhone.font = .setFont(type: .Regular, size: 18)
        txtPhone.text = "+91"
        dropdownImg.image = UIImage(named: "India")
       
    }
}
//MARK: Custom Functions
extension SignUpVC{
    func setCountyPickerView(){
        countryPicker.showPhoneCodeInView = true
        countryPicker.showCountryNameInView = false
//        countryPicker.showFlagInView = false
        countryPicker.setCountryByPhoneCode("+91")
        
        txtPhone.text = countryPicker.selectedCountry.phoneCode
        dropdownImg.image = countryPicker.selectedCountry.flag
    }
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: true)
    }
    func validateFields() -> Bool {
        var isValid = true
            
        // Validate Name
        if let number = txtEnterPhone.text, number.isEmpty {
            showAlert(message: "Please enter your mobile number")
            isValid = false
        }
        return isValid
    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
//MARK: CountryPickerViewDelegate
extension SignUpVC: CountryPickerViewDelegate{
    func countryPickerView(_ countryPickerView: CountryPickerView, didSelectCountry country: Country) {
        txtPhone.text = country.phoneCode  // Set phone code
        dropdownImg.image = country.flag   // Set country flag
    }
}
