//
//  NameAndEmailVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 04/04/25.
//

import UIKit

class NameAndEmailVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var subTitle: UILabel!
    @IBOutlet weak var txtNameAndEmail: UITextField!
    @IBOutlet weak var btnContinue: UIButton!
    @IBOutlet weak var progressBar: UIProgressView!
    
    var currentStep = 3
    var newCurrentStep = 4
    var isName: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        isName = false
        updateProgress(currentStep: currentStep, totalSteps: 9)
    }
    
}
//MARK: SetUp UI
extension NameAndEmailVC{
    func setUp() {
        
        txtNameAndEmail.attributedPlaceholder = NSAttributedString(
            string: txtNameAndEmail.placeholder ?? "",
            attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 17)]
        )
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview .clipsToBounds = true
        }
    }
}
//MARK: Custom Function
extension NameAndEmailVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
    func setEmailScreen(){
        if isName == false{
            lblTitle.text = "afwe"
            subTitle.text = "gyequfghyeq"
        } else{
            lblTitle.text = "12453646"
            subTitle.text = "56"
        }
    }
    func validateFields() -> Bool {
        var isValid = true
        
        // Validate Name
        if let number = txtNameAndEmail.text, number.isEmpty {
            showAlert(message: "Please enter your mobile number")
            isValid = false
        }
        // Validate Email
        if let email = txtNameAndEmail.text {
            if email.isEmpty {
                showAlert(message: "Please enter your email.")
                return false
            } else if !Helper.shared.validateEmailId(email) {
                showAlert(message: "Please enter a valid email address.")
                return false
            }
        }
        return isValid
    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
//MARK: Click Events
extension NameAndEmailVC{
    @IBAction func onClickBack(_ sender: Any) {
        if isName == true{
            isName = false//name screen
            updateProgress(currentStep: currentStep , totalSteps: 9)
            lblTitle.text = "What’s Your Name?"
            subTitle.text = "Let's Get to Know Each Other"
            txtNameAndEmail.placeholder = "Enter your Name"
        } else{
            navigationController?.popViewController(animated: false)
        }
    }
    
    @IBAction func onClickContinue(_ sender: Any) {
        if isName == false{
            updateProgress(currentStep: newCurrentStep , totalSteps: 9)
            if let name = txtNameAndEmail.text, name.isEmpty {
                showAlert(message: "Please enter your name.")
                return
            }
            isName = true // switch to Email screen
            updateProgress(currentStep: newCurrentStep, totalSteps: 9)
            lblTitle.text = "Email Address"
            subTitle.text = "We'll need your email to stay in touch"
            txtNameAndEmail.placeholder = "Enter your Email"
            txtNameAndEmail.text = ""  // clear old name input
        } else{
            if validateFields(){
                let nameandEmailVc = storyboard?.instantiateViewController(withIdentifier: "AgeVC") as? AgeVC
                nameandEmailVc?.currentStep = self.newCurrentStep + 1
                navigationController?.pushViewController(nameandEmailVc!, animated: false)
            }
        }
    }
}
