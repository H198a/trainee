//
//  FireData.swift
//  CupidArrow
//
//  Created by admin on 10/04/25.
//

import Foundation
import UIKit

struct storeDataFire{
    var id: String?
    var name: String?
    var email: String?
    var age: String?
    var gender: String?
    var phone: String?
    var OTP: String?
    var interests:[String?] = []
    var lookingFor: String?
    var location: [String?] = []
    var image: UIImage?
}
