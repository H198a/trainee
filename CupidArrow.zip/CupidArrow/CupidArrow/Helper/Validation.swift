//
//  Validation.swift
//  CupidArrow
//
//  Created by Hemaxi S on 04/04/25.
//

import Foundation
import UIKit

class Helper {
    
    static var shared: Helper = Helper()
    
    // Function to set the root view controller for the home screen
    func setHomeRoot(from storyboard: UIStoryboard) {
        guard let vcRoot = storyboard.instantiateViewController(withIdentifier: "TabBarController") as? UITabBarController else {
            print("Failed to get home view controller")
            return
        }
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = scene.windows.first {
            window.rootViewController = vcRoot
            window.makeKeyAndVisible()
        }
    }
    
    // Function to set the root view controller for the login screen
    func setLoginRoot(from storyboard: UIStoryboard) {
        guard let vcLogin = storyboard.instantiateViewController(withIdentifier: "ViewController") as? UIViewController else {
            print("Failed to get login screen")
            return
        }
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = scene.windows.first {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let loginVC = storyboard.instantiateViewController(withIdentifier: "ViewController")
                let navController = UINavigationController(rootViewController: loginVC)
                window.rootViewController = navController
                window.makeKeyAndVisible()
        }
    }
    
    // number Validation
    func validateNumber(_ number: String) -> Bool {
        let numberRegEx = "^[0-9]+$"
        return applyPredicateOnRegex(regexStr: numberRegEx, text: number)
    }
    
    // Email Validation
    func validateEmailId(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        return applyPredicateOnRegex(regexStr: emailRegEx, text: email)
    }
        
    // Password Validation (Minimum 8 characters, at least 1 number and 1 letter)
    func validatePassword(_ password: String) -> Bool {
        let passRegEx = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$"
        return applyPredicateOnRegex(regexStr: passRegEx, text: password)
    }
    
    // Apply regex to validate string
    func applyPredicateOnRegex(regexStr: String, text: String) -> Bool {
        let trimmedString = text.trimmingCharacters(in: .whitespaces)
        let validateString = NSPredicate(format: "SELF MATCHES %@", regexStr)
        return validateString.evaluate(with: trimmedString)
    }
}

