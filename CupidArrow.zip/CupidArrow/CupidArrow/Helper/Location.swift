//
//  Location.swift
//  CupidArrow
//
//  Created by Hemaxi S on 08/04/25.
//

import Foundation
import CoreLocation

class LocationManager: NSObject, CLLocationManagerDelegate{
    static let shared = LocationManager()
    private var locationManager: CLLocationManager = CLLocationManager()
    private var requestLocationAuthorizationCallBack: ((CLAuthorizationStatus) -> Void)?
    
    public func requestLocation(callback: @escaping (CLAuthorizationStatus) -> Void){
        self.locationManager.delegate = self
        self.requestLocationAuthorizationCallBack = callback
        let currentStatus = CLLocationManager.authorizationStatus()
        guard currentStatus == .notDetermined else { return }
        
        if currentStatus == .notDetermined {
                   locationManager.requestWhenInUseAuthorization()
        } else {
            callback(currentStatus)
        }
    }
    
    // MARK: - CLLocationManagerDelegate
    public func locationManager(_ manager: CLLocationManager,
                                didChangeAuthorization status: CLAuthorizationStatus) {
        self.requestLocationAuthorizationCallBack?(status)
    }
}
