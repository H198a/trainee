//
//  TableViewCell.swift
//  KhataBook
//
//  Created by Hemaxi S on 07/03/25.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var TblLbl: UILabel!
    @IBOutlet weak var TblImg: UIImageView!
    @IBOutlet weak var tblView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
