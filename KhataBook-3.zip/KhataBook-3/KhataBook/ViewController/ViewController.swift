//
//  ViewController.swift
//  KhataBook
//
//  Created by Hemaxi S on 05/03/25.
//

import UIKit
//import AEOTPTextField
import IQKeyboardManager
import OTPFieldView
class ViewController: UIViewController{
    //MARK: IBOutlet and Variable Declaration
    // @IBOutlet weak var TxtPin: AEOTPTextField!
    @IBOutlet weak var OtpView: OTPFieldView!
    @IBOutlet weak var LblPin: UILabel!
    let pinKey = "userPin"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        implementOtpView()
//        LblPin.font = UIFont(name: "DMSans", size: 50)
//        LblPin.text = "Enter pin"
        //        OtpView.defaultBackgroundColor = UIColor.white
        //        // Do any additional setup after loading the view.
//                if let savedPin = UserDefaults.standard.string(forKey: pinKey) {
//                    // If pin exists, show 'Enter Pin'
//                    LblPin.text = "Enter Pin"
//                } else {
//                    // If pin is not set, show 'Set Pin'
//                    LblPin.text = "Set Pin"
//                }
        
    }
}

//MARK: Custom Functions
extension ViewController{
    func implementOtpView(){
        self.OtpView.fieldsCount = 4

        self.OtpView.defaultBorderColor = UIColor.appThemeRed
      
        self.OtpView.backgroundColor = .clear
        self.OtpView.defaultBorderColor = .clear
        self.OtpView.fieldFont = UIFont.systemFont(ofSize: 60)
        self.OtpView.requireCursor = false
        self.OtpView.fieldSize = 13
        self.OtpView.separatorSpace = 40
        self.OtpView.shouldAllowIntermediateEditing = false
        self.OtpView.delegate = self
        self.OtpView.secureEntry = true
        self.OtpView.filledBackgroundColor = .black
        self.OtpView.defaultBackgroundColor = .white
        self.OtpView.initializeUI()
    }
    
    func handlePinEntry(_ enteredPin: String) {
        let storedPin = UserDefaults.standard.string(forKey: pinKey)

        if storedPin == nil {
            // First-time PIN setup
            UserDefaults.standard.set(enteredPin, forKey: pinKey)
            UserDefaults.standard.synchronize()
            navigateToHomeScreen()
        } else {
            // Verify PIN
            if enteredPin == storedPin {
                navigateToHomeScreen()//1236-se, 1235-16
            } else {
                showAlert()
                implementOtpView()
            }
        }
    }

    
    func navigateToHomeScreen() {
        let defaults = UserDefaults.standard
        defaults.set(true, forKey: "IsLogged")
        defaults.synchronize()
        Helper.shared.setHomeRoot(from: self.storyboard!)
        print("navigating to Home Screen")
    }
    func showAlert() {
        let alertController = UIAlertController(title: "Incorrect Pin", message: "Please enter the correct pin.", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
}
//MARK: OTPFieldDelgate
extension ViewController: OTPFieldViewDelegate{
//    Show keyboard automatically.
    func shouldBecomeFirstResponderForOTP(otpTextFieldIndex index: Int) -> Bool {
        print("somethingh")
        return true
    }
    
    func enteredOTP(otp: String) {
        handlePinEntry(otp)
        print(otp)
    }
    
    func hasEnteredAllOTP(hasEnteredAll: Bool) -> Bool {
        print("entered OTP: \(hasEnteredAll)")
        return false
    }
    
    
}

