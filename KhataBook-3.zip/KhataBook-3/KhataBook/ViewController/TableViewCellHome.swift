//
//  TableViewCellHome.swift
//  KhataBook
//
//  Created by Hemaxi S on 07/03/25.
//

import UIKit

class TableViewCellHome: UITableViewCell {

    @IBOutlet weak var LblCurrency: UILabel!
    @IBOutlet weak var MainView: UIView!
    @IBOutlet weak var ColorView: UIView!
    @IBOutlet weak var LblAmonut: UILabel!
    @IBOutlet weak var amountView: UIView!
    @IBOutlet weak var LblDate: UILabel!
    @IBOutlet weak var LblHead: UILabel!
    @IBOutlet weak var colorImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setUP()
    }
    func setUP(){
        MainView.layer.cornerRadius = 20
        MainView.layer.borderWidth = 1
        
        ColorView.layer.cornerRadius = 10
        
        amountView.layer.cornerRadius = 10
        amountView.layer.borderWidth = 0.5
        amountView.layer.borderColor = UIColor.lightGray.cgColor
        
        colorImg.layer.masksToBounds = true
        colorImg.layer.cornerRadius = colorImg.frame.height / 2
    }
}

