//
//  ExpenseVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 07/03/25.
//

import UIKit
//import iOSDropDown
import DropDown


class ExpenseVC: UIViewController {
    //MARK: IBOutlet and Variable Declaration
    @IBOutlet weak var TxtDesc: UITextField!
    @IBOutlet weak var TxtPayment: UITextField!
    @IBOutlet weak var TxtCurrency: UITextField!
    @IBOutlet weak var TxtAmount: UITextField!
    @IBOutlet weak var TxtGrocery: UITextField!
    @IBOutlet weak var TxtDate: UITextField!
    
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var paymentView: UIView!
    @IBOutlet weak var currencyView: UIView!
    @IBOutlet weak var amountView: UIView!
    @IBOutlet weak var GroceryView: UIView!
    @IBOutlet weak var DateView: UIView!
    
    @IBOutlet weak var btnGrocery: UIButton!
    @IBOutlet weak var btnPayment: UIButton!
    @IBOutlet weak var btnCurrency: UIButton!
    @IBOutlet weak var btnAmount: UIButton!
    
    let groceryDropDown = DropDown()
    let paymentDropDown = DropDown()
    let currencyDropDown = DropDown()
    let amountDropDown = DropDown()
    
    let groceryImages: [String: String] = [
        "Groceryyy": "Grocery",
        "Electronics": "Electronics",
        "Apparels": "Apparels",
        "Investments": "Investments",
        "Life": "Life"
    ]
    let listArr = ["Grocery","Electronics","Apparels","Investemts","Life"]
    let paymentArr = ["Physical Cash", "Credit Card", "Debit Card"]
    let amountArr = ["100", "200", "300"]
    let currencyArr = ["$", "₹", "€"]
    
    let imgArr = ["Grocery","Electronics","Apparels","Investemts","Life"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        setupDropDowns()
 
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
}
//MARK: SetUp UI
extension ExpenseVC{
    func setUP(){
        //corner Radius
        descriptionView.layer.cornerRadius = 20
        paymentView.layer.cornerRadius = 20
        GroceryView.layer.cornerRadius = 20
        amountView.layer.cornerRadius = 20
        DateView.layer.cornerRadius = 20
        currencyView.layer.cornerRadius = 20
        //transperent color
        DateView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        descriptionView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        paymentView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        GroceryView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        amountView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        currencyView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        //Border Width
        descriptionView.layer.borderWidth = 1
        paymentView.layer.borderWidth = 1
        GroceryView.layer.borderWidth = 1
        amountView.layer.borderWidth = 1
        DateView.layer.borderWidth = 1
        currencyView.layer.borderWidth = 1
        
        groceryDropDown.backgroundColor = .white
        paymentDropDown.backgroundColor = .white
        amountDropDown.backgroundColor = .white
        currencyDropDown.backgroundColor = .white
    }
    func setupDropDowns(){
        paymentDropDown.anchorView = paymentView
        paymentDropDown.dataSource = paymentArr
        paymentDropDown.selectionAction = { (index: Int, item: String) in
          print("Selected item: \(item) at index: \(index)")
            self.TxtPayment.text = self.paymentArr[index]
            
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        paymentDropDown.bottomOffset = CGPoint(x: 0, y:(paymentDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        paymentDropDown.topOffset = CGPoint(x: 0, y:-(paymentDropDown.anchorView?.plainView.bounds.height)!)
        paymentDropDown.direction = .bottom
        
        
        amountDropDown.anchorView = amountView
        amountDropDown.dataSource = amountArr
        amountDropDown.selectionAction = { (index: Int, item: String) in
          print("Selected item: \(item) at index: \(index)")
            self.TxtAmount.text = self.amountArr[index]
            
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        amountDropDown.bottomOffset = CGPoint(x: 0, y:(amountDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        amountDropDown.topOffset = CGPoint(x: 0, y:-(amountDropDown.anchorView?.plainView.bounds.height)!)
        amountDropDown.direction = .bottom
        
        currencyDropDown.anchorView = currencyView
        currencyDropDown.dataSource = currencyArr
        currencyDropDown.selectionAction = { (index: Int, item: String) in
          print("Selected item: \(item) at index: \(index)")
            self.TxtCurrency.text = self.currencyArr[index]
            
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        currencyDropDown.bottomOffset = CGPoint(x: 0, y:(currencyDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        currencyDropDown.topOffset = CGPoint(x: 0, y:-(currencyDropDown.anchorView?.plainView.bounds.height)!)
        currencyDropDown.direction = .bottom
        
        groceryDropDown.anchorView = GroceryView // UIView or UIBarButtonItem

        // The list of items to display. Can be changed dynamically
        groceryDropDown.dataSource = listArr

        /*** IMPORTANT PART FOR CUSTOM CELLS ***/
        groceryDropDown.cellNib = UINib(nibName: "DropDownCelll", bundle: nil)
        //groceryDropDown.customCellType = DropDownCell.self

        groceryDropDown.customCellConfiguration = { (index: Int, item: String, cell: UITableViewCell) -> Void in
            if let dropdownCell = cell as? KhataBook.DropDownCelll {
                dropdownCell.ImgDropdown.image = UIImage(named: self.imgArr[index])
                dropdownCell.LblDropdown.text = self.listArr[index]
                dropdownCell.ImgBackView.backgroundColor = .red
            }
        }
        groceryDropDown.selectionAction = { (index: Int, item: String) in
            self.TxtGrocery.text = item
        }

    }
    
}


////MARK: Click Events
extension ExpenseVC{
    @IBAction func btnCloseClick(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func btnIncomeClick(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnGrocerySelection(_ sender: Any) {
        print("buton clicked")
        groceryDropDown.show()
    }
    
    @IBAction func btnAmountSelection(_ sender: Any) {
        amountDropDown.show()
    }
    
    @IBAction func btnCurrencySelection(_ sender: Any) {
        currencyDropDown.show()
    }
    
    @IBAction func btnPaymentSelection(_ sender: Any) {
        paymentDropDown.show()
    }
    
    @IBAction func btnInsertTemplateClick(_ sender: Any) {
        guard let title = TxtGrocery.text, !title.isEmpty else { return }
        guard let amountText = TxtAmount.text?.trimmingCharacters(in: .whitespacesAndNewlines),
              !amountText.isEmpty else { return }

        let selectedImageName = groceryImages[title] ??  "Ellipse 8"
        guard let dateText = TxtDate.text, !dateText.isEmpty else { return }

         // Convert dateText into Date format
         let dateFormatter = DateFormatter()
         dateFormatter.dateFormat = "dd/MM/yyyy " // Change format as per your requirement
        guard let date = dateFormatter.date(from: dateText) else {
            print("Invalid date format")
            return
        }

        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        let newExpense = Expense(context: context)
        newExpense.title = title
        newExpense.date = date
        if let amountValue = Double(amountText) {
            newExpense.amount = "-\(amountValue)" // Store as a negative string
        } else {
            print("Invalid amount entered",(amountText))
        }
        newExpense.image = selectedImageName

        do {
            try context.save()
            navigationController?.popToRootViewController(animated: true)
            self.dismiss(animated: true) // Close this view
        } catch {
            print("Failed to save expense: \(error)")
        }
    }
}

