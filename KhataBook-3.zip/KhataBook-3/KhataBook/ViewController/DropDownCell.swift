//
//  DropDownCell.swift
//  KhataBook
//
//  Created by admin on 12/03/25.
//

import UIKit

class DropDownCelll: UITableViewCell {
    //MARK: Outlet and Variable Declaration
    @IBOutlet weak var ImgDropdown: UIImageView!
    @IBOutlet weak var LblDropdown: UILabel!
    @IBOutlet weak var ImgBackView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        ImgBackView.layer.cornerRadius = ImgBackView.frame.height / 2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
