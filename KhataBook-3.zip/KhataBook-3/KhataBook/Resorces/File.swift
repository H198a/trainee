//
//  File.swift
//  KhataBook
//
//  Created by Hemaxi S on 10/03/25.
//

import Foundation
/*
 extension Date {

     /// Create a date from specified parameters
     ///
     /// - Parameters:
     ///   - year: The desired year
     ///   - month: The desired month
     ///   - day: The desired day
     /// - Returns: A `Date` object
     static func from(year: Int, month: Int, day: Int) -> Date? {
         let calendar = Calendar(identifier: .gregorian)
         var dateComponents = DateComponents()
         dateComponents.year = year
         dateComponents.month = month
         dateComponents.day = day
         return calendar.date(from: dateComponents) ?? nil
     }
 }
 Use:



 let marsOpportunityLaunchDate = Date.from(year: 2003, month: 07, day: 07)
 Date.from(year: 2003, month: 07, day: 07)
 
 
 func updateChart(type: String) {
     // Holds the days of the week
     var values: [Double] = []      // Holds the daily amounts (income - expense)
     chartDataEntries.removeAll()
     var labels: [String] = []
     
     let dateFormatter = DateFormatter()
     dateFormatter.dateFormat = "E" // Day of the week (Mon, Tue, etc.)
     let calendar = Calendar.current
     let today = calendar.startOfDay(for: Date())
     let weekDay = calendar.component(.weekday, from: today)
     let currentWeekDay = weekDay == 1 ? 7 : weekDay - 1
     
     // Check if we're showing only Income or Expense
     let isShowingIncome = BtnIncome.titleLabel?.textColor == UIColor.view // Assuming the color change indicates the selected state
     let isShowingExpense = BtnExpense.titleLabel?.textColor == UIColor.view
     
     switch type {
     case "Daily":
         // clear previous chart data
         dataPoints.removeAll()
         values.removeAll()
         labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
         
         // loop through the weekdays
         for i in 1...7 {
             let day = calendar.date(byAdding: .day, value: i - currentWeekDay, to: today)!
             let dayName = dateFormatter.string(from: day) // "Mon", "Tue", "Wed", etc.
             dataPoints.append(dayName)  // Add the day name to dataPoints
             
             // Get the start and end date for each day
             let dayStart = calendar.startOfDay(for: day)
             let dayEnd = calendar.date(byAdding: .day, value: 1, to: dayStart)!
             
             // Calculate the daily amount for this day (Income - Expense)
             let dailyAmount = calculateDailyAmount(from: dayStart, to: dayEnd, isIncome: isShowingIncome, isExpense: isShowingExpense)
             values.append(dailyAmount)  // Add the calculated daily amount to values
         }
         break
         
     case "Monthly":
         labels = ["Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"]
         values = []
         let monthsInYear = 7
         for month in 1...monthsInYear {
             let monthStart = calendar.date(from: DateComponents(year: calendar.component(.year, from: Date()), month: month, day: 1))!
             let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)!
             
             // Calculate the monthly amount (Income - Expense)
             let monthlyAmount = calculateMonthlyAmount(from: monthStart, to: monthEnd, isIncome: isShowingIncome, isExpense: isShowingExpense)
             labels.append(dateFormatter.string(from: monthStart))  // Use the month name (e.g., "Jan", "Feb", etc.)
             values.append(monthlyAmount)  // Add the calculated monthly amount to values
         }
         break
         
     case "Yearly":
         values = []
         let years = 7  // For example, show data from 2019 to 2025
         for year in 2019...(2019 + years - 1) {
             let yearStart = calendar.date(from: DateComponents(year: year, month: 1, day: 1))!
             let yearEnd = calendar.date(from: DateComponents(year: year, month: 12, day: 31))!
             
             // Calculate the yearly amount (Income - Expense)
             let yearlyAmount = calculateYearlyAmount(from: yearStart, to: yearEnd, isIncome: isShowingIncome, isExpense: isShowingExpense)
             labels.append("\(year)")  // Use the year
             values.append(yearlyAmount)  // Add the calculated yearly amount to values
         }
         break
         
     default:
         return
     }
     
     // Set chart description and labels
     let description = Description()
     description.text = ""
     Linechart.chartDescription = description
     Linechart.xAxis.valueFormatter = IndexAxisValueFormatter(values: labels)
     Linechart.xAxis.labelPosition = .bottom
     
     setChart(dataPoints: dataPoints, values: values)
 }

 // Update existing helper functions to accept isIncome and isExpense flags to filter transactions
 func calculateDailyAmount(from startDate: Date, to endDate: Date, isIncome: Bool, isExpense: Bool) -> Double {
     var totalAmount: Double = 0.0
     
     for transaction in transactions {
         if let date = transaction.date, date >= startDate, date < endDate {
             if isIncome && transaction.type == 1 {
                 totalAmount += transaction.amount
             }
             if isExpense && transaction.type == 0 {
                 totalAmount += transaction.amount
             }
         }
     }
     return totalAmount
 }

 func calculateMonthlyAmount(from startDate: Date, to endDate: Date, isIncome: Bool, isExpense: Bool) -> Double {
     var totalAmount: Double = 0.0
     
     for transaction in transactions {
         if let date = transaction.date, date >= startDate, date < endDate {
             if isIncome && transaction.type == 1 {
                 totalAmount += transaction.amount
             }
             if isExpense && transaction.type == 0 {
                 totalAmount += transaction.amount
             }
         }
     }
     return totalAmount
 }

 func calculateYearlyAmount(from startDate: Date, to endDate: Date, isIncome: Bool, isExpense: Bool) -> Double {
     var totalAmount: Double = 0.0
     
     for transaction in transactions {
         if let date = transaction.date, date >= startDate, date < endDate {
             if isIncome && transaction.type == 1 {
                 totalAmount += transaction.amount
             }
             if isExpense && transaction.type == 0 {
                 totalAmount += transaction.amount
             }
         }
     }
     return totalAmount
 }

 func updateChart(type: String) {
     // Holds the days of the week
     var values: [Double] = []      // Holds the daily amounts (income - expense)
     chartDataEntries.removeAll()
     var labels: [String] = []
     
     let dateFormatter = DateFormatter()
     dateFormatter.dateFormat = "E" // Day of the week (Mon, Tue, etc.)
     let calendar = Calendar.current
     let today = calendar.startOfDay(for: Date())
     let weekDay = calendar.component(.weekday, from: today)
     let currentWeekDay = weekDay == 1 ? 7 : weekDay - 1
     
     // Check if we're showing only Income or Expense
     let isShowingIncome = BtnIncome.titleLabel?.textColor == UIColor.view
     let isShowingExpense = BtnExpense.titleLabel?.textColor == UIColor.view
     
     switch type {
     case "Daily":
         // clear previous chart data
         dataPoints.removeAll()
         values.removeAll()
         labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
         
         // loop through the weekdays
         for i in 1...7 {
             let day = calendar.date(byAdding: .day, value: i - currentWeekDay, to: today)!
             let dayName = dateFormatter.string(from: day) // "Mon", "Tue", "Wed", etc.
             dataPoints.append(dayName)  // Add the day name to dataPoints
             
             // Get the start and end date for each day
             let dayStart = calendar.startOfDay(for: day)
             let dayEnd = calendar.date(byAdding: .day, value: 1, to: dayStart)!
             
             // Calculate the daily amount for this day (Income - Expense)
             let dailyAmount = calculateDailyAmount(from: dayStart, to: dayEnd, isIncome: isShowingIncome, isExpense: isShowingExpense)
             values.append(dailyAmount)  // Add the calculated daily amount to values
         }
         break
         
     case "Monthly":
         labels = ["Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"]
         values = []
         let monthsInYear = 7
         for month in 1...monthsInYear {
             let monthStart = calendar.date(from: DateComponents(year: calendar.component(.year, from: Date()), month: month, day: 1))!
             let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)!
             
             // Calculate the monthly amount (Income - Expense)
             let monthlyAmount = calculateMonthlyAmount(from: monthStart, to: monthEnd, isIncome: isShowingIncome, isExpense: isShowingExpense)
             labels.append(dateFormatter.string(from: monthStart))  // Use the month name (e.g., "Jan", "Feb", etc.)
             values.append(monthlyAmount)  // Add the calculated monthly amount to values
         }
         break
         
     case "Yearly":
         values = []
         let years = 7  // For example, show data from 2019 to 2025
         for year in 2019...(2019 + years - 1) {
             let yearStart = calendar.date(from: DateComponents(year: year, month: 1, day: 1))!
             let yearEnd = calendar.date(from: DateComponents(year: year, month: 12, day: 31))!
             
             // Calculate the yearly amount (Income - Expense)
             let yearlyAmount = calculateYearlyAmount(from: yearStart, to: yearEnd, isIncome: isShowingIncome, isExpense: isShowingExpense)
             labels.append("\(year)")  // Use the year
             values.append(yearlyAmount)  // Add the calculated yearly amount to values
         }
         break
         
     default:
         return
     }
     
     // Set chart description and labels
     let description = Description()
     description.text = ""
     Linechart.chartDescription = description
     Linechart.xAxis.valueFormatter = IndexAxisValueFormatter(values: labels)
     Linechart.xAxis.labelPosition = .bottom
     
     setChart(dataPoints: dataPoints, values: values)
 }

 
 
 
 
 //    func calculateBalance() -> Double/* -> Double*/ {
 //        var incomeTotal = 0.0
 //        var expenseTotal = 0.0
 //
 //        for transaction in transactions {
 //            if transaction.type == 1 {
 //                incomeTotal += transaction.amount
 //                //expenseTotal += transaction.amount
 //                //return incomeTotal
 //            } else if transaction.type == 0 {
 //                expenseTotal += transaction.amount
 //
 //            }
 //        }
 //
 //        print("Income Total: \(incomeTotal)")
 //        print("Expense Total: \(expenseTotal)")
 //        print(incomeTotal - expenseTotal)
 //        return incomeTotal - expenseTotal
 //    }

 var editIncome: Income?
 var editExpense: Expense?
 
 if transactionToDelete.type == 0 { // Expense
     guard let event = self.editExpense else {
         print("error in expense")
         return
     }
     event.isDeletedData = true
 } else { // Income
     guard let event = self.editIncome else {
         print("error in income")
         return
     }
     event.isDeletedData = true
 }
 
 
 
 // Only fetch non-deleted transactions
//        incomeFetch.predicate = NSPredicate(format: "isDeletedData == %@", NSNumber(value: false))
//        //NSNumber is used to cinvert true false (premitive) into NSNumber object because NSPredicate uses NSNumber  object to filter data from coredata
//        expenseFetch.predicate = NSPredicate(format: "isDeletedData == %@", NSNumber(value: false))

 func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
         let transactionToDelete = transactions[indexPath.row]

         let alert = UIAlertController(title: transactionToDelete.title, message: "Are you sure you want to delete?", preferredStyle: .alert)
         alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
             
             // update Core Data mark the record as deleted
             guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
             let context = appDelegate.persistentContainer.viewContext

             if transactionToDelete.type == 0 { // Expense
                 let fetchRequest: NSFetchRequest<Expense> = Expense.fetchRequest()
                 fetchRequest.predicate = NSPredicate(format: "title == %@ AND date == %@", transactionToDelete.title, transactionToDelete.date as CVarArg)//from coreData fetch only that data which are same date and title to delete tablviewdata
                 do {
                     let results = try context.fetch(fetchRequest)
                     if let expenseToUpdate = results.first {
                         expenseToUpdate.isDeletedData = true // mark as deleted
                         try context.save()
                     }
                 } catch {
                     print("Failed to update expense: \(error)")
                 }
             } else { // Income
                 let fetchRequest: NSFetchRequest<Income> = Income.fetchRequest()
                 fetchRequest.predicate = NSPredicate(format: "title == %@ AND date == %@", transactionToDelete.title, transactionToDelete.date as CVarArg)

                 do {
                     let results = try context.fetch(fetchRequest)
                     if let incomeToUpdate = results.first {
                         incomeToUpdate.isDeletedData = true // mark as deleted
                         try context.save()
                     }
                 } catch {
                     print("Failed to update income: \(error)")
                 }
             }

             // remove the transaction from the array (only the deleted one)
             self.transactions.remove(at: indexPath.row)

             // update the tableview by deleting the row
             tableView.deleteRows(at: [indexPath], with: .fade)

             // update the balance label
             //self.LblAvilbleBalance.text = "\(String(format: "%.2f", self.totalAmount))"
         }))
         alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
         present(alert, animated: true)
     }
 }
 
 */
