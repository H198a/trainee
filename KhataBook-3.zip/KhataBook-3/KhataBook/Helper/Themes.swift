//
//  Themes.swift
//  KhataBook
//
//  Created by Hemaxi S on 05/03/25.
//

import Foundation
import UIKit

class CustomtabBarVC: UITabBarController, UITabBarControllerDelegate{
    override func viewDidLoad(){
        super.viewDidLoad()
        self.delegate = self
        setUP()
    }
}
extension CustomtabBarVC{
    func setUP(){
        self.tabBar.layer.shadowColor = UIColor.yellow.cgColor
        self.tabBar.layer.shadowOpacity = 0.1
        self.tabBar.layer.shadowOffset = CGSize(width: 4, height: 4)
    }
}
