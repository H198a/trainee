//
//  DropDownModel.swift
//  KhataBook
//
//  Created by Hemaxi S on 12/03/25.
//

import Foundation
import UIKit

struct Category {
    let name: String
    let color: String
    let icon: UIImage?
}
