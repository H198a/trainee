//
//  SetRoot.swift
//  KhataBook
//
//  Created by Hemaxi S on 06/03/25.
//

import Foundation
import UIKit
class Helper {
    
    static var shared: Helper = Helper()
    
    // Function to set the root view controller for the home screen
    func setHomeRoot(from storyboard: UIStoryboard) {
        guard let vcRoot = storyboard.instantiateViewController(withIdentifier: "TabBarController") as? UITabBarController else {
            print("Failed to get home view controller")
            return
        }
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = scene.windows.first {
            window.rootViewController = vcRoot
            window.makeKeyAndVisible()
        }
    }
    
    // Function to set the root view controller for the login screen
    func setLoginRoot(from storyboard: UIStoryboard) {
        guard let vcLogin = storyboard.instantiateViewController(withIdentifier: "ViewController") as? UIViewController else {
            print("Failed to get login screen")
            return
        }
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = scene.windows.first {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let loginVC = storyboard.instantiateViewController(withIdentifier: "ViewController")
            let navController = UINavigationController(rootViewController: loginVC)
            window.rootViewController = navController
            window.makeKeyAndVisible()
        }
    }
}
