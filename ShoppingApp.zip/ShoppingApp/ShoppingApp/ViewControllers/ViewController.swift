//
//  ViewController.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 26/03/25.
//

import UIKit
import Kingfisher
import Alamofire

class ViewController: UIViewController {
    //MARK: Outlet and Variable Declaration
    @IBOutlet weak var searchBar: UITextField!
    @IBOutlet weak var categorySelectionCollView: UICollectionView!
    @IBOutlet weak var categoryCollview: UICollectionView!

    var selectedCategoryIndex: Int? = nil
    var dataArray: [newData] = []
    var categoryList: [ListData] = []
    var filteredDataArray: [newData] = []
    var countDict: [Int: Int] = [:]
    var isSearching = false // Flag to track search state
    override func viewDidLoad() {
        super.viewDidLoad()
 
        getCategoryData()
        searchBar.delegate = self
        //searchBar.keyboardType = .webSearch
        filteredDataArray = dataArray
            
        let nibName = UINib(nibName: "CategoerySelectionCell", bundle: nil)
        categorySelectionCollView.register(nibName, forCellWithReuseIdentifier: "CategoerySelectionCell")
        
        let neNibName = UINib(nibName: "CategoryListCell", bundle: nil)
        categoryCollview.register(neNibName, forCellWithReuseIdentifier: "CategoryListCell")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadCounts()
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
}
//MARK: UITextField Delegate
extension ViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        searchBar.resignFirstResponder()
        let searchText = textField.text?.lowercased() ?? ""
        
        if searchText.isEmpty {
            isSearching = false
            filteredDataArray = dataArray
        } else {
            isSearching = true
            filteredDataArray = dataArray.filter { $0.name.lowercased().contains(searchText) }
        }
        
        categoryCollview.reloadData() // Reload collection view with filtered data
        
        
        return true
    }
}
//MARK: CollectionViewdelegate, dataSource
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView.tag == 0{
            //print(dataArray.count)
//            return dataArray.count
            return isSearching ? filteredDataArray.count : dataArray.count
        } else if collectionView.tag == 1{
            //print(categoryList.count)
            return categoryList.count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.categorySelectionCollView{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoerySelectionCell", for: indexPath) as! CategoerySelectionCell
            let category = dataArray[indexPath.item]
            cell.Lblcategory.text = category.name
            //cell.categoryImg.image = UIImage(named: imgArr[indexPath.row])
            cell.categoryImg.kf.setImage(with: URL(string: category.image))
            cell.categoryView.borderColor = .clear
            
            if indexPath.row == selectedCategoryIndex {
                          cell.Lblcategory.textColor = .orange
                          cell.categoryView.borderColor = .orange
            } else {
                cell.Lblcategory.textColor = .black // Default color
                cell.categoryView.borderColor = .clear // Default border
            }
            return cell
        } else if collectionView == self.categoryCollview{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryListCell", for: indexPath) as! CategoryListCell
            let categoryListData = categoryList[indexPath.item]
//            let categoryid = categoryListData.categoryID
//            self.getCategoryList(catId: categoryid)
            cell.BtnMinus.setTitle("-", for: .normal)
            cell.BtnPlus.setTitle("+", for: .normal)
            
            let categoryID = categoryListData.categoryID
            let currentCount = countDict[categoryID] ?? 1
            cell.onCountChange = { [weak self] newCount in
                self?.countDict[categoryID] = newCount
                self?.saveCounts()
            }
            
            cell.mainImg.kf.setImage(with: URL(string: categoryListData.image))
            cell.LblHead.text = categoryListData.name
            cell.LblCount.text = "\(currentCount)"
            cell.LblPrice.text = "$\(categoryListData.price)"
            return cell
        }
        return UICollectionViewCell()
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView.tag == 0 {
            selectedCategoryIndex = indexPath.row // Track selected category index
                   let selectedCategory = dataArray[indexPath.row] // Get selected category
                   let categoryId = selectedCategory.id

                   // Fetch category list based on selected categoryId
                   getCategoryList(catId: categoryId)

                   // Reload categorySelectionCollView to update the UI for selection state
                   collectionView.reloadData()
        } else {
            print("dsfkhk bwfd")
        }
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let collectionWidth = collectionView.frame.width
            let spacing: CGFloat = 10 // Space between cells
            let itemsPerRow: CGFloat = 2 // Change as needed
            let totalSpacing = (itemsPerRow + 1) * spacing
            let itemWidth = (collectionWidth - totalSpacing) / itemsPerRow
            
            return CGSize(width: itemWidth, height: itemWidth * 1.2) // Adjust height as needed
        }}
//MARK: Custom Functions
extension ViewController{
    func getCategoryData(){
        AF.request("https://beta2.moontechnolabs.com/practical_api/public/api/category-list").response {
            response in
            if let data = response.data{
                do{
                    let userResponse = try JSONDecoder().decode(Category.self, from: data)
//                    print(userResponse)
                    self.dataArray = userResponse.data
                    
                    // Check if categories exist, then set the first one as selected
                    if !self.dataArray.isEmpty {
                        self.selectedCategoryIndex = 0
                        let firstCategoryId = self.dataArray[0].id
                        self.getCategoryList(catId: firstCategoryId) // Fetch first category data
                    }
                    
                    DispatchQueue.main.async{
                        self.categorySelectionCollView.reloadData()
                    }
                  
                } catch let err{
                    print(err.localizedDescription)
                }
            }
        }
    }
    
    func getCategoryList(catId: Int){
        AF.request("https://beta2.moontechnolabs.com/practical_api/public/api/category-product-list?categoryid=\(catId)").response {
            response in
            if let data = response.data{
                do{
                    let userResponse = try JSONDecoder().decode(CategoryList.self, from: data)
                    print(userResponse)
                    self.categoryList = userResponse.data
                    DispatchQueue.main.async{
                        self.categoryCollview.reloadData()
                    }
                  
                } catch let err{
                    print(err.localizedDescription)
                }
            }
        }
    }
    func saveCounts() {
            UserDefaults.standard.setValue(countDict, forKey: "CountDict")
        }
    func loadCounts() {
           if let savedCounts = UserDefaults.standard.dictionary(forKey: "CountDict") as? [Int: Int] {
               countDict = savedCounts
           }
       }
}
