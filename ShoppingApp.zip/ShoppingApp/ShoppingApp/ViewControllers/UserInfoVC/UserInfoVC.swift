//
//  UserInfoVC.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 02/04/25.
//

import UIKit

class UserInfoVC: UIViewController {
//MARK: Outlet and Varible Declaration
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var mainView: UIView!
    var arrOrder: OrderEntityy?
    override func viewDidLoad() {
        super.viewDidLoad()
        lblName.text = arrOrder?.title ?? "gkgfjw"
        mainView.layer.cornerRadius = 10  // Rounded corners
        mainView.layer.shadowColor = UIColor.black.cgColor
        mainView.layer.shadowOpacity = 0.4
        mainView.layer.shadowOffset = CGSize(width: 0, height: 0)
        mainView.layer.shadowRadius = 6
        mainView.layer.masksToBounds = false  // Ensures shadow is visible
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
}
