//
//  OrderDetailVC.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 01/04/25.
//

import UIKit
import CoreData
import Kingfisher

class OrderDetailVC: UIViewController {
    //MARK: Outlet and variable declaration
    @IBOutlet weak var tblView: UITableView!
    var transactions: [OrderEntityy] = [] /*[(name: String?, imageName: String?, count: Int32, price: Double, size: String?, orderID: String?, date: Date)] = []*/
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDatafromCoreData()
        let nibName = UINib(nibName: "DetailCell", bundle: nil)
        tblView.register(nibName, forCellReuseIdentifier: "DetailCell")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }

}
//MARK: Custom Functions
extension OrderDetailVC{
    func fetchDatafromCoreData(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        let incomeFetch: NSFetchRequest<OrderEntityy> = OrderEntityy.fetchRequest()
        do {
            //            let incomeResults = try context.fetch(incomeFetch)
            //            
            //            for income in incomeResults {
            //                let name = income.title ?? ""
            //                let orderDate = income.orderDate ?? Date()
            //                let price = income.price
            //                let imageName = income.img ?? "defaultImage"
            //                let size = income.size ?? ""
            //                let orderID = income.orderId
            //                let newCount = income.count
            //                transactions.append((name: name, imageName: imageName, count: newCount, price: price, size: size, orderID: orderID, date: orderDate))
            //                transactions.sort { $0.date > $1.date }
            transactions = try context.fetch(incomeFetch) // directly store Core Data objects
            transactions.sort { ($0.orderDate ?? Date()) > ($1.orderDate ?? Date()) }// sort by date
            
        } catch {
            print("Failed to fetch transactions: \(error)")
        }
    }
}
//MARK: UITableViewDataSource, UITableViewDelegate
extension OrderDetailVC: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return transactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailCell", for: indexPath) as! DetailCell
        let transaction = transactions[indexPath.row]
        cell.Lblid.text = transaction.orderId
        let dateFormatter = DateFormatter()
        dateFormatter.amSymbol = "a.m"
        dateFormatter.pmSymbol = "p.m"
        dateFormatter.dateFormat = "a"
        dateFormatter.dateFormat = "dd MMM, yyyy hh:mm a" // Change format as per your requirement
        cell.Lblid.text = "OrderID: \(transaction.orderId!)"
        cell.lblDate.text = dateFormatter.string(from: transaction.orderDate!) //" //dd MMM, yyyy ' | ' hh:mm a
        cell.lblSize.text = transaction.size
        cell.lblCount.text = "Qty: \(transaction.count)"
        cell.lblPrice.text = "$\(transaction.price)"
        cell.lblTitle.text = transaction.title
        cell.imgOrder.kf.setImage(with: URL(string: transaction.img ?? "Frame 16564"))
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedVC = transactions[indexPath.row]
        if let userInfoVc = storyboard?.instantiateViewController(withIdentifier: "UserInfoVC") as? UserInfoVC{
            userInfoVc.arrOrder = selectedVC
            navigationController?.pushViewController(userInfoVc, animated: true)
        }
    }
    
}
