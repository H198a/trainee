//
//  DetailCell.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 02/04/25.
//

import UIKit

class DetailCell: UITableViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSize: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var imgOrder: UIImageView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblCount: UILabel!
    @IBOutlet weak var Lblid: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        Lblid.font = .setFont(type: .Regular, size: 14)
        lblDate.font = .setFont(type: .Regular, size: 14)
        lblSize.font = .setFont(type: .Regular, size: 14)
        lblCount.font = .setFont(type: .Regular, size: 14)
        lblPrice.font = .setFont(type: .Bold, size: 14)
        lblTitle.font = .setFont(type: .Regular, size: 14)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
/*
 func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     if indexPath.row == 0 {
         // Navigate to HomeVC
         let topViewcontroller = self.topViewController()
         //if let currentVC = self.navigationController?.topViewController {
             if topViewcontroller is ViewController {
                 // Already on the HomeVC, no need to navigate anywhere
                 print("Already at HomeVC")
             } else {
                 // Dismiss the side menu first
                 self.sideMenu?.dismiss(animated: true, completion: {
                     // After dismissing the side menu, pop to root
                     self.navigationController?.popToRootViewController(animated: true)
                 })
             }
         //}

     } else if indexPath.row == 1 {
         // Navigate to OrderDetailVC
         if let currentVC = self.navigationController?.topViewController {
             if currentVC is OrderDetailVC {
                 
                 print("already at OrderDetailVC")
             } else {
                 if let detailVC = storyboard?.instantiateViewController(withIdentifier: "OrderDetailVC") as? OrderDetailVC {
                     print("navigating to OrderDetailVC")
                     navigationController?.pushViewController(detailVC, animated: true)
                 } else {
                     print("error in OrderDetailVC ")
                 }
             }
         }
     }
 }
 
}
 */
