//
//  SideMenuVC.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 01/04/25.
//

import UIKit
import SideMenu

class SideMenuVC: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var arrLbl = ["Home","MyOrder"]
    var arrImg = ["Home","Order"]
    var sideMenu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()
        let nibName = UINib(nibName: "SideMenuCell", bundle: nil)
        tblView.register(nibName, forCellReuseIdentifier: "SideMenuCell")
    }

  
    @IBAction func btnClick(_ sender: Any) {
        print("netwbtnclick")
        navigationController?.popToRootViewController(animated: true)
    }
    
//    func topViewController(cotroller: UIViewController? = UIApplication.shared.windows.first(where: { $0.isKeyWindow})?.rootViewController) -> UIViewController? {
//        if let navigationController = cotroller as? UINavigationController {
//            return topViewController(cotroller: navigationController.visibleViewController)
//        }
//        if let tabBarController = cotroller as? UITabBarController {
//            if let tabBar = tabBarController.selectedViewController {
//                return topViewController(cotroller: tabBar)
//            }
//        }
//        if let presentedController = cotroller?.presentedViewController {
//            return topViewController(cotroller: presentedController)
//        }
//        return cotroller
//    }
}
//MARK: TablviewDataSource, Delegate
extension SideMenuVC: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrLbl.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath) as! SideMenuCell
        cell.lblTitle.text = arrLbl[indexPath.row]
        cell.img.image = UIImage(named: arrImg[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        if indexPath.row == 0 {
            appDelegate.setTopViewControllerToHomeVC()
            // Navigate to HomeVC
//            if let currentVC = self.navigationController?.topViewController {
//                if currentVC is ViewController {
//                    // Already on the HomeVC, no need to navigate anywhere
//                    print("Already at HomeVC")
//                } else {
//                    // Dismiss the side menu first
//                    self.sideMenu?.dismiss(animated: true, completion: {
//                        // After dismissing the side menu, pop to root
//                        self.navigationController?.popToRootViewController(animated: true)
//                    })
//                }
//            }

        } else if indexPath.row == 1 {
            appDelegate.setTopViewControllerToOrderDetailVC()
            // Navigate to OrderDetailVC
//            if let currentVC = self.navigationController?.topViewController {
//                if currentVC is OrderDetailVC {
//                    
//                    print("already at OrderDetailVC")
//                } else {
//                    if let detailVC = storyboard?.instantiateViewController(withIdentifier: "OrderDetailVC") as? OrderDetailVC {
//                        print("navigating to OrderDetailVC")
//                        navigationController?.pushViewController(detailVC, animated: true)
//                    } else {
//                        print("error in OrderDetailVC ")
//                    }
//                }
//            }
        }
    }
    
}

