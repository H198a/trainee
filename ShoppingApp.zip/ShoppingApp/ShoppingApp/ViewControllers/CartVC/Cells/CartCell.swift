//
//  CartCell.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 27/03/25.
//

import UIKit

class CartCell: UITableViewCell {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var LblName: UILabel!
    @IBOutlet weak var LblSize: UILabel!
    @IBOutlet weak var LblPrice: UILabel!
    @IBOutlet weak var LblCount: UILabel!
    @IBOutlet weak var Img: UIImageView!
    @IBOutlet weak var BtnPlus: UIButton!
    @IBOutlet weak var BtnMinus: UIButton!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var shadowView: UIView!
    
    var count: Int = 1 {
        didSet {
            LblCount.text = "\(count)"
        }
    }
    
    var onCountChange: ((Int, CartCell) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        LblName.font = UIFont.setFont(type: .Regular, size: 15)
        LblSize.font = UIFont.setFont(type: .Regular, size: 15)
        LblCount.font = UIFont.setFont(type: .Regular, size: 15)
        LblPrice.font = UIFont.setFont(type: .Bold, size: 16)
        BtnPlus.titleLabel?.textAlignment = .center
        BtnMinus.titleLabel?.textAlignment = .center
        //backgroundColor = UIColor.clear.cgColor

        //self.shadowView.layer.borderWidth = 1
       // self.shadowView.layer.cornerRadius = 3
       // self.shadowView.layer.borderColor = UIColor.black.cgColor
//       // self.shadowView.layer.masksToBounds = true
//
//        shadowView.layer.shadowOpacity = 0.18
//        shadowView.layer.shadowOffset = CGSize(width: 5, height: 5)
//        shadowView.layer.shadowRadius = 2
//        shadowView.layer.shadowColor = UIColor.black.cgColor
//        shadowView.layer.masksToBounds = false
         //Initialization code
        BtnMinus.addTarget(self, action: #selector(decreaseCount), for: .touchUpInside)
        BtnPlus.addTarget(self, action: #selector(increaseCount), for: .touchUpInside)
    }
    @objc func decreaseCount() {
        if count > 0 {
            count -= 1
            onCountChange?(count, self)
            BtnPlus.backgroundColor = .white
            BtnPlus.titleLabel?.textColor = .app
            BtnPlus.borderColor = .app
            BtnPlus.borderWidth = 1
           
        }
    }
    
    @objc func increaseCount() {
        count += 1
        onCountChange?(count, self)
        BtnPlus.backgroundColor = .app
        BtnPlus.titleLabel?.textColor = .app
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}

//    var newAmount =  newPrice * Double(newCount)
//newAmount += totalAmount
