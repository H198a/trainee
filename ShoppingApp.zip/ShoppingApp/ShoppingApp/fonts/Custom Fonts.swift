//
//  Custom Fonts.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 01/04/25.
//

import Foundation
import UIKit

extension UIFont {

    /// Font Work Sans Light
    ///
    /// - Parameter size: Font size you need
    /// - Returns: your custom font for custom size
    enum FontType: String {
        case Bold = "Inter-SemiBold"
        case Regular = "InterDisplay-Regular"
        case ExtraBold = "Inter-Black"
//        case BoldItalic = "OpenSans-BoldItalic"
//        case ExtraBoldItalic = "OpenSans-ExtraboldItalic"
//        case Italic = "OpenSans-Italic"
//        case Light = "OpenSans-Light"
//        case LightItalic = "OpenSansLight-Italic"
//        case SemiBold = "SemiBold"
//        case SemiBoldItalic = "SemiBoldItalic"
    }
    static func setFont(type: FontType, size: CGFloat) -> UIFont{
        return UIFont(name: type.rawValue, size: size)! /*?? systemFont(ofSize: 50)*/
    }
}
