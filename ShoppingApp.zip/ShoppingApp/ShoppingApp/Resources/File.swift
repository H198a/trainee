//
//  File.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 02/04/25.
//

import Foundation
/*
 func storeOrderDataToCoreData() {
     guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
     let context = appDelegate.persistentContainer.viewContext

     // Create a single OrderEntity for the main order details
     let order = OrderEntity(context: context)
     order.address = txtAddress.text
     order.phone = Int32(txtPhone.text ?? "0") ?? 0 // Default to 0 if conversion fails
     order.mail = txtEmail.text
     order.name = txtName.text
     order.orderedID = "12nj2324"
     order.size = "M"
     order.total = Int32(LblNewTotalAmount.text?.replacingOccurrences(of: "$", with: "") ?? "0") ?? 0 // Remove '$' and default to 0

     // Store transaction items as a comma-separated string within the same OrderEntity
     var transactionString = ""
     for item in transactions {
         let itemString = "\(item.name ?? ""),\(item.price),\(item.imageName ?? ""),\(item.count),\(item.addedItem),\(item.categoryID);"
         transactionString += itemString
     }
     order.transactionItemsString = transactionString // Add a new property to OrderEntity

     do {
         try context.save()
         print("Data saved successfully")
     } catch {
         print("Something went wrong: \(error)")
     }
 }
 
 func retrieveOrderData(from order: OrderEntity) -> [String: Any]? {
     guard let transactionString = order.transactionItemsString else { return nil }

     let transactionItems = transactionString.components(separatedBy: ";")
     var transactions: [[String: Any]] = []

     for itemString in transactionItems {
         if !itemString.isEmpty {
             let itemComponents = itemString.components(separatedBy: ",")
             if itemComponents.count == 6 {
                 let transaction: [String: Any] = [
                     "name": itemComponents[0],
                     "price": Double(itemComponents[1]) ?? 0.0,
                     "imageName": itemComponents[2],
                     "count": Int32(itemComponents[3]) ?? 0,
                     "addedItem": Int32(itemComponents[4]) ?? 0,
                     "categoryID": Int32(itemComponents[5]) ?? 0
                 ]
                 transactions.append(transaction)
             }
         }
     }

     // Retrieve other order data
     let orderData: [String: Any] = [
         "name": order.name ?? "",
         "mail": order.mail ?? "",
         "phone": order.phone,
         "address": order.address ?? "",
         "orderedID": order.orderedID ?? "",
         "size": order.size ?? "",
         "total": order.total,
         "transactions": transactions
     ]

     return orderData
 }
 
 
 
 
 
 import UIKit
 import CoreData
 import Kingfisher

 // Custom UITableViewCell for displaying order items
 class OrderItemCell: UITableViewCell {
     @IBOutlet weak var nameLabel: UILabel!
     @IBOutlet weak var priceLabel: UILabel!
     @IBOutlet weak var countLabel: UILabel!
     // Add other labels as needed

     override func awakeFromNib() {
         super.awakeFromNib()
         // Initialization code
     }

     override func setSelected(_ selected: Bool, animated: Bool) {
         super.setSelected(selected, animated: animated)
         // Configure the view for the selected state
     }
 }

 // CartVC (Where you store the order data)
 class CartVC: UIViewController {
     @IBOutlet weak var TblView: UITableView!
     // ... other outlets ...
     var transactions: [(name: String?, price: Double, imageName: String?, count: Int32, addedItem: Int32, categoryID: Int32)] = []

     // ... your existing CartVC code ...

     @IBAction func btnProceedToCheckoutClick(_ sender: Any) {
         if validateFields() {
             let orderVC = self.storyboard?.instantiateViewController(withIdentifier: "OrderVC") as! OrderVC
             orderVC.orderData = storeScreenDataToOrderEntity()
             self.navigationController?.pushViewController(orderVC, animated: true)
         }
     }

     func storeScreenDataToOrderEntity() -> [String: Any]? {
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
         let context = appDelegate.persistentContainer.viewContext

         let newOrder = OrderEntity(context: context)
         newOrder.address = txtAddress.text
         newOrder.phone = Int32(txtPhone.text ?? "0") ?? 0
         newOrder.mail = txtEmail.text
         newOrder.name = txtName.text
         newOrder.orderedID = "12nj2324"
         newOrder.size = "M"
         newOrder.total = Int32(LblNewTotalAmount.text?.replacingOccurrences(of: "$", with: "") ?? "0") ?? 0

         var transactionString = ""
         for item in transactions {
             let itemString = "\(item.name ?? ""),\(item.price),\(item.imageName ?? ""),\(item.count),\(item.addedItem),\(item.categoryID);"
             transactionString += itemString
         }
         newOrder.transactionItemsString = transactionString

         do {
             try context.save()
             print("Screen data saved to OrderEntity successfully")
             return retrieveOrderData(from: newOrder)
         } catch {
             print("Failed to save screen data: \(error)")
             return nil
         }
     }

     func retrieveOrderData(from order: OrderEntity) -> [String: Any]? {
         guard let transactionString = order.transactionItemsString else { return nil }

         let transactionItems = transactionString.components(separatedBy: ";")
         var transactions: [[String: Any]] = []

         for itemString in transactionItems {
             if !itemString.isEmpty {
                 let itemComponents = itemString.components(separatedBy: ",")
                 if itemComponents.count == 6 {
                     let transaction: [String: Any] = [
                         "name": itemComponents[0],
                         "price": Double(itemComponents[1]) ?? 0.0,
                         "imageName": itemComponents[2],
                         "count": Int32(itemComponents[3]) ?? 0,
                         "addedItem": Int32(itemComponents[4]) ?? 0,
                         "categoryID": Int32(itemComponents[5]) ?? 0
                     ]
                     transactions.append(transaction)
                 }
             }
         }

         let orderData: [String: Any] = [
             "name": order.name ?? "",
             "mail": order.mail ?? "",
             "phone": order.phone,
             "address": order.address ?? "",
             "orderedID": order.orderedID ?? "",
             "size": order.size ?? "",
             "total": order.total,
             "transactions": transactions
         ]

         return orderData
     }
 }

 // OrderVC (Where you display the order data)
 class OrderVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
     @IBOutlet weak var orderTableView: UITableView!

     var orderData: [String: Any]?
     var transactions: [[String: Any]] = []

     override func viewDidLoad() {
         super.viewDidLoad()
         orderTableView.dataSource = self
         orderTableView.delegate = self
         orderTableView.register(UINib(nibName: "OrderItemCell", bundle: nil), forCellReuseIdentifier: "OrderItemCell")

         if let order = orderData {
             transactions = order["transactions"] as? [[String: Any]] ?? []
             orderTableView.reloadData()
         }
     }

     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return transactions.count
     }

     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "OrderItemCell", for: indexPath) as! OrderItemCell
         let transaction = transactions[indexPath.row]

         cell.nameLabel.text = transaction["name"] as? String
         cell.priceLabel.text = "\(transaction["price"] as? Double ?? 0.0)"
         cell.countLabel.text = "\(transaction["count"] as? Int32 ?? 0)"

         return cell
     }
 }
 
 
 
 extension SideMenuVC: UITableViewDataSource, UITableViewDelegate{
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return arrLbl.count
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath) as! SideMenuCell
         cell.lblTitle.text = arrLbl[indexPath.row]
         cell.img.image = UIImage(named: arrImg[indexPath.row])
         return cell
     }
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         if indexPath.row == 0 {
             // Navigate to HomeVC
             let topViewcontroller = self.topViewController()
             //if let currentVC = self.navigationController?.topViewController {
                 if topViewcontroller is ViewController {
                     // Already on the HomeVC, no need to navigate anywhere
                     print("Already at HomeVC")
                 } else {
                     // Dismiss the side menu first
                     self.sideMenu?.dismiss(animated: true, completion: {
                         // After dismissing the side menu, pop to root
                         self.navigationController?.popToRootViewController(animated: true)
                     })
                 }
             //}

         } else if indexPath.row == 1 {
             // Navigate to OrderDetailVC
             if let currentVC = self.navigationController?.topViewController {
                 if currentVC is OrderDetailVC {
                     
                     print("already at OrderDetailVC")
                 } else {
                     if let detailVC = storyboard?.instantiateViewController(withIdentifier: "OrderDetailVC") as? OrderDetailVC {
                         print("navigating to OrderDetailVC")
                         navigationController?.pushViewController(detailVC, animated: true)
                     } else {
                         print("error in OrderDetailVC ")
                     }
                 }
             }
         }
     }
     
 }

 
 import UIKit
 import SideMenu

 class SideMenuVC: UIViewController {
     @IBOutlet weak var tblView: UITableView!
     var arrLbl = ["Home","MyOrder"]
     var arrImg = ["Home","Order"]
     var sideMenu: SideMenuNavigationController?
     override func viewDidLoad() {
         super.viewDidLoad()
         let nibName = UINib(nibName: "SideMenuCell", bundle: nil)
         tblView.register(nibName, forCellReuseIdentifier: "SideMenuCell")
     }

   
     @IBAction func btnClick(_ sender: Any) {
         print("netwbtnclick")
         navigationController?.popToRootViewController(animated: true)
     }
     
     func topViewController(cotroller: UIViewController? = UIApplication.shared.windows.first(where: { $0.isKeyWindow})?.rootViewController) -> UIViewController? {
         if let navigationController = cotroller as? UINavigationController {
             return topViewController(cotroller: navigationController.visibleViewController)
         }
         if let tabBarController = cotroller as? UITabBarController {
             if let tabBar = tabBarController.selectedViewController{
                 return topViewController(cotroller: tabBar)
             }
         }
         if let showController = cotroller?.presentedViewController {
             return topViewController(cotroller: showController)
         }
         return cotroller
     }
 }
 //MARK: TablviewDataSource, Delegate
 extension SideMenuVC: UITableViewDataSource, UITableViewDelegate{
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return arrLbl.count
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath) as! SideMenuCell
         cell.lblTitle.text = arrLbl[indexPath.row]
         cell.img.image = UIImage(named: arrImg[indexPath.row])
         return cell
     }
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         if indexPath.row == 0 {
             // Navigate to HomeVC
             let topViewcontroller = self.topViewController()
             //if let currentVC = self.navigationController?.topViewController {
                 if topViewcontroller is ViewController {
                     // Already on the HomeVC, no need to navigate anywhere
                     print("Already at HomeVC")
                 } else {
                     // Dismiss the side menu first
                     self.sideMenu?.dismiss(animated: true, completion: {
                         // After dismissing the side menu, pop to root
                         self.navigationController?.popToRootViewController(animated: true)
                     })
                 }
             //}
             

         } else if indexPath.row == 1 {
             // Navigate to OrderDetailVC
             if let currentVC = self.navigationController?.topViewController {
                 if currentVC is OrderDetailVC {
                     
                     print("already at OrderDetailVC")
                 } else {
                     if let detailVC = storyboard?.instantiateViewController(withIdentifier: "OrderDetailVC") as? OrderDetailVC {
                         print("navigating to OrderDetailVC")
                         navigationController?.pushViewController(detailVC, animated: true)
                     } else {
                         print("error in OrderDetailVC ")
                     }
                 }
             }
         }
     }
     
 }


 import UIKit
 import IQKeyboardManager
 import CoreData

 @main
 class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
         IQKeyboardManager.shared().isEnabled = true
         guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = windowScene.windows.first,
               let rootViewController = window.rootViewController as? UITabBarController,
               let selectedViewController = rootViewController.selectedViewController as? UINavigationController else {
             print("Error getting navigation controller")
             return true
         }
         let navController = selectedViewController;
         navController.popToRootViewController(animated: false)
         // Override point for customization after application launch.
         return true
     }

     // MARK: UISceneSession Lifecycle

     func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
      
         return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
     }

     func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        
     }
     lazy var persistentContainer: NSPersistentContainer = {
          
             let container = NSPersistentContainer(name: "CartModel")
             container.loadPersistentStores(completionHandler: { (storeDescription, error) in
                 if let error = error as NSError? {
                  
                     fatalError("Unresolved error \(error), \(error.userInfo)")
                 }
             })
             return container
         }()
     
     func saveContext() {
             let context = persistentContainer.viewContext
             if context.hasChanges {
                 do {
                     try context.save()
                 } catch {
                     let nserror = error as NSError
                     // Replace this with error handling appropriate for your app.
                     fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
                 }
             }
         }
 }

 import UIKit
 import IQKeyboardManager

 @main
 class AppDelegate: UIResponder, UIApplicationDelegate {

     var window: UIWindow?

     func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
         
         // Enable IQKeyboardManager
         IQKeyboardManager.shared().isEnabled = true
         
         // Access the window and root view controller
         guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = windowScene.windows.first else {
             print("Error accessing window")
             return true
         }
         self.window = window

         // Set the root view controller (if it's not set already in Storyboard)
         if let rootViewController = window.rootViewController as? UITabBarController,
            let selectedViewController = rootViewController.selectedViewController as? UINavigationController {
             
             // You can call the function to check/set the top view controller here
             setTopViewControllerToHomeVC()
         }

         return true
     }

     // MARK: - Helper Functions

     // Function to set the top view controller to HomeVC
     func setTopViewControllerToHomeVC() {
         guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = windowScene.windows.first else {
             print("Error accessing window")
             return
         }

         // Assuming root view controller is a UITabBarController and the selected view controller is a UINavigationController
         if let rootViewController = window.rootViewController as? UITabBarController,
            let selectedViewController = rootViewController.selectedViewController as? UINavigationController {
             
             // Instantiate HomeVC from the storyboard and set it as the root view controller
             if let homeVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as? HomeVC {
                 selectedViewController.setViewControllers([homeVC], animated: true)
             }
         }
     }

     // Function to set the top view controller to OrderDetailVC
     func setTopViewControllerToOrderDetailVC() {
         guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = windowScene.windows.first else {
             print("Error accessing window")
             return
         }

         if let rootViewController = window.rootViewController as? UITabBarController,
            let selectedViewController = rootViewController.selectedViewController as? UINavigationController {
             
             // Instantiate OrderDetailVC from the storyboard and push it onto the navigation stack
             if let orderDetailVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "OrderDetailVC") as? OrderDetailVC {
                 selectedViewController.pushViewController(orderDetailVC, animated: true)
             }
         }
     }
     
     // MARK: UISceneSession Lifecycle (if you are using UISceneDelegate in your app)
     func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
         return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
     }

     func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {}

 }

 
 
 import UIKit
 import IQKeyboardManager
 import SideMenu

 @main
 class AppDelegate: UIResponder, UIApplicationDelegate {
     
     var window: UIWindow?

     func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
         
         // Enable IQKeyboardManager
         IQKeyboardManager.shared().isEnabled = true
         
         // Setup the window and the root view controller
         guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = windowScene.windows.first else {
             print("Error accessing window")
             return true
         }
         
         self.window = window
         
         // Setup TabBarController as root view controller
         let tabBarController = UITabBarController()

         // Create and add the necessary view controllers for the TabBarController
         let homeVC = UINavigationController(rootViewController: ViewController()) // HomeVC
         let orderDetailVC = UINavigationController(rootViewController: OrderDetailVC()) // OrderDetailVC
         
         // You can add more view controllers as needed
         tabBarController.viewControllers = [homeVC, orderDetailVC]
         
         // Set the initial root view controller of the window
         window.rootViewController = tabBarController
         
         // Initialize the side menu configuration
         configureSideMenu(for: window)
         
         return true
     }
     
     // MARK: - SideMenu Setup

     func configureSideMenu(for window: UIWindow) {
         // Initialize the SideMenu Navigation Controller
         let sideMenuVC = SideMenuVC()  // Assuming you have a SideMenuVC
         let sideMenuNavigationController = SideMenuNavigationController(rootViewController: sideMenuVC)
         
         // Configure the left side menu
         SideMenuManager.default.leftMenuNavigationController = sideMenuNavigationController
         
         // Enable the swipe gesture for showing the side menu
         SideMenuManager.default.addPanGestureToPresent(toView: window.rootViewController!.view)
     }

     // MARK: UISceneSession Lifecycle (for apps supporting multi-scene)
     
     func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
         return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
     }

     func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
         // Handle discarded scenes
     }

 }

 
 import UIKit
 import SideMenu

 class SideMenuVC: UIViewController {
     
     @IBOutlet weak var tblView: UITableView!
     
     var arrLbl = ["Home", "MyOrder"]
     var arrImg = ["Home", "Order"]
     var sideMenu: SideMenuNavigationController?
     
     override func viewDidLoad() {
         super.viewDidLoad()
         let nibName = UINib(nibName: "SideMenuCell", bundle: nil)
         tblView.register(nibName, forCellReuseIdentifier: "SideMenuCell")
     }
     
     // Function to get the top view controller
     func topViewController(cotroller: UIViewController? = UIApplication.shared.windows.first(where: { $0.isKeyWindow})?.rootViewController) -> UIViewController? {
         if let navigationController = cotroller as? UINavigationController {
             return topViewController(cotroller: navigationController.visibleViewController)
         }
         if let tabBarController = cotroller as? UITabBarController {
             if let tabBar = tabBarController.selectedViewController {
                 return topViewController(cotroller: tabBar)
             }
         }
         if let presentedController = cotroller?.presentedViewController {
             return topViewController(cotroller: presentedController)
         }
         return cotroller
     }
     
     // TableView Delegate to handle row selection
     extension SideMenuVC: UITableViewDataSource, UITableViewDelegate {
         func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
             return arrLbl.count
         }
         
         func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
             let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath) as! SideMenuCell
             cell.lblTitle.text = arrLbl[indexPath.row]
             cell.img.image = UIImage(named: arrImg[indexPath.row])
             return cell
         }
         
         func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
             if indexPath.row == 0 {  // Home row selected
                 navigateToHomeVC()
             } else if indexPath.row == 1 {  // Order row selected
                 navigateToOrderVC()
             }
         }
         
         // Navigate to HomeVC
         func navigateToHomeVC() {
             let topViewController = self.topViewController()
             
             if topViewController is ViewController {
                 // Already on HomeVC
                 print("Already at HomeVC")
             } else {
                 // Dismiss the side menu and pop to root view controller
                 self.sideMenu?.dismiss(animated: true, completion: {
                     self.navigationController?.popToRootViewController(animated: true)
                 })
             }
         }
         
         // Navigate to OrderDetailVC
         func navigateToOrderVC() {
             let topViewController = self.topViewController()
             
             if topViewController is OrderDetailVC {
                 // Already on OrderDetailVC
                 print("Already at OrderDetailVC")
             } else {
                 // Dismiss the side menu and push OrderDetailVC
                 self.sideMenu?.dismiss(animated: true, completion: {
                     if let orderDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "OrderDetailVC") as? OrderDetailVC {
                         self.navigationController?.pushViewController(orderDetailVC, animated: true)
                     }
                 })
             }
         }
     }

 
 
 

 */
