//
//  File.swift
//  ShoppingApp
//
//  Created by admin on 26/03/25.
//

import Foundation

//tag = 0(self.categorySelectionCollView) ,return isSearching ? filteredDataArray.count : dataArray.count
/*
 func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
     if collectionView == self.categorySelectionCollView {
         let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoerySelectionCell", for: indexPath) as! CategoerySelectionCell
         let category = isSearching ? filteredDataArray[indexPath.item] : dataArray[indexPath.item]
         
         cell.Lblcategory.text = category.name
         cell.categoryImg.kf.setImage(with: URL(string: category.image))
         
         return cell
     } else {
         let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryListCell", for: indexPath) as! CategoryListCell
         let categoryListData = categoryList[indexPath.item]
         
         cell.mainImg.kf.setImage(with: URL(string: categoryListData.image))
         cell.LblHead.text = categoryListData.name
         cell.LblPrice.text = "$\(categoryListData.price)"
         
         return cell
     }
 }

 */
