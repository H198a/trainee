//
//  CategoryViewModel.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 26/03/25.
//

import Foundation
import UIKit
import Alamofire

class CategoryViewModel{
    weak var vc: ViewController?
    var arrUser:[newData] = []
    
    func getcategoryData(){
        AF.request("https://beta2.moontechnolabs.com/practical_api/public/api/category-list").response {
            response in
            if let data = response.data{
                do{
                    let userResponse = try JSONDecoder().decode(Category.self, from: data)
                    self.arrUser = userResponse.data
                    DispatchQueue.main.async{
                        self.vc?.categorySelectionCollView.reloadData()
                    }
                  
                } catch let err{
                    print(err.localizedDescription)
                }
            }
        }
    }
}

