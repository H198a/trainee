//
//  CategoerySelectionCell.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 26/03/25.
//

import UIKit

class CategoerySelectionCell: UICollectionViewCell {
//MARK: IBOutlet
    @IBOutlet weak var categoryView: UIView!
    @IBOutlet weak var Lblcategory: UILabel!
    @IBOutlet weak var categoryImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        Lblcategory.font = UIFont.setFont(type: .Regular, size: 14)
        // Initialization code
    
    }
  
}
