//
//  SideMenuVC.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 01/04/25.
//

import UIKit

class SideMenuVC: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var arrLbl = ["Home","MyOrder"]
    var arrImg = ["Home","Order"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nibName = UINib(nibName: "SideMenuCell", bundle: nil)
        tblView.register(nibName, forCellReuseIdentifier: "SideMenuCell")
    }


}
//MARK: TablviewDataSource, Delegate
extension SideMenuVC: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrLbl.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath) as! SideMenuCell
        cell.lblTitle.text = arrLbl[indexPath.row]
        cell.img.image = UIImage(named: arrImg[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            //navigate to Home
            print("navigating to HomeVC")
            navigationController?.popToRootViewController(animated: true)
            
        } else if indexPath.row == 1 {
            // navigate to OrderDetailVC
            if let detailVC = storyboard?.instantiateViewController(withIdentifier: "OrderDetailVC") as? OrderDetailVC {
                print("nvigating to OrderDetailVC")
                navigationController?.pushViewController(detailVC, animated: true)
            } else {
                print("error in OrderDetailVC")
            }
        }
    }
}
