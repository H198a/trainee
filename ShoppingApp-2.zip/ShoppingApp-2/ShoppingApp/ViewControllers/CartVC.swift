//
//  CartVC.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 27/03/25.
//

import UIKit
import CoreData
import Kingfisher

class CartVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var TblView: UITableView!
    @IBOutlet weak var tblViewHwight: NSLayoutConstraint!
    var transactions: [(name: String?,  price: String?, imageName: String?, count: Int32, categoryID: Int32)] = []
    var categoryList: [ListData] = []
    var arrSize = ["S","M","S"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchTransactions()
        let nibName = UINib(nibName: "CartCell", bundle: nil)
        TblView.register(nibName, forCellReuseIdentifier: "CartCell")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    @IBAction func BtnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension CartVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return transactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CartCell", for: indexPath) as! CartCell
        let categoryData = transactions[indexPath.row]
        cell.LblName.text = categoryData.name
        cell.LblSize.text = "M"
        cell.LblPrice.text = categoryData.price
        cell.cateforyImg.kf.setImage(with: URL(string: categoryData.imageName ?? "Frame 16564"))
        let existingCategory = fetchCategoryFromCoreData(categoryID: Int(categoryData.categoryID))
        cell.count = Int(existingCategory?.count ?? 0)
            cell.LblCount.text = "\(cell.count)"
        
        if cell.count <= 0 {
               cell.BtnPlus.setTitleColor(.orange, for: .normal)
               cell.BtnPlus.backgroundColor = .white
               cell.BtnPlus.layer.borderColor = UIColor.orange.cgColor
               cell.BtnPlus.layer.borderWidth = 1
           } else {
               cell.BtnPlus.setTitleColor(.white, for: .normal)
               cell.BtnPlus.backgroundColor = .orange
               cell.BtnPlus.layer.borderColor = UIColor.clear.cgColor // Clear border when count > 0
               cell.BtnPlus.layer.borderWidth = 0 // Clear border width when count > 0
           }

            // Update Core Data when count changes
        cell.onCountChange = { [weak self] newCount, updatedCell in
            guard let self = self, let indexPath = self.TblView.indexPath(for: updatedCell) else { return }
            
            if newCount == 0 {
                updatedCell.BtnPlus.setTitleColor(.orange, for: .normal)
                updatedCell.BtnPlus.backgroundColor = .white
                updatedCell.BtnPlus.layer.borderColor = UIColor.orange.cgColor
                updatedCell.BtnPlus.layer.borderWidth = 1
                
                // 1. Remove from core data
                let category = self.transactions[indexPath.row]
                self.deleteCategoryFromCoreData(categoryID: Int(category.categoryID))

                // 2. Remove from array
                self.transactions.remove(at: indexPath.row)
                
                // 3. Remove from table view
                self.TblView.deleteRows(at: [indexPath], with: .automatic)
            } else {
                updatedCell.BtnPlus.setTitleColor(.white, for: .normal)
                updatedCell.BtnPlus.backgroundColor = .orange
                updatedCell.BtnPlus.layer.borderColor = UIColor.clear.cgColor
                updatedCell.BtnPlus.layer.borderWidth = 0
                
                // Update count in Core Data
                let category = self.transactions[indexPath.row]
                self.updateCategoryCountInCoreData(categoryID: Int(category.categoryID), newCount: newCount)
            }
        }

        return cell
    }
}
extension CartVC{
    func fetchTransactions() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        let incomeFetch: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        incomeFetch.predicate = NSPredicate(format: "count > 0")
        do {
            let expenseResults = try context.fetch(incomeFetch)
            for expense in expenseResults {
                let newName = expense.name ?? ""
                let newPrice = expense.price
                let newImageName = expense.image
                let newCount = expense.count
                let newCategoryID = expense.categoryID
                
                transactions.append((name: newName, price: newPrice, imageName: newImageName, count: newCount, categoryID: newCategoryID))
            }
        }catch {
            print("Failed to fetch transactions: \(error)")
        }
    }
    func fetchCategoryFromCoreData(categoryID: Int) -> CartEntity? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
        let context = appDelegate.persistentContainer.viewContext

        let fetchRequest: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "categoryID == %d", categoryID)

        do {
            let results = try context.fetch(fetchRequest)
            return results.first
        } catch {
            print("Failed to fetch category: \(error.localizedDescription)")
            return nil
        }
    }
    func updateCategoryCountInCoreData(categoryID: Int, newCount: Int) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        if let category = fetchCategoryFromCoreData(categoryID: categoryID) {
            category.count = Int32(newCount)
        } else {
            // If category doesn't exist, create new entry
            let newCategory = CartEntity(context: context)
            newCategory.categoryID = Int32(categoryID)
            newCategory.name = categoryList.first { $0.id == categoryID }?.name
            newCategory.image = categoryList.first { $0.id == categoryID }?.image
            newCategory.price = "\(categoryList.first { $0.id == categoryID }?.price ?? 0)"
            newCategory.count = Int32(newCount)
        }

        do {
            try context.save()
        } catch {
            print("Failed to update count: \(error.localizedDescription)")
        }
    }
    func deleteCategoryFromCoreData(categoryID: Int) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        let fetchRequest: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "categoryID == %d", categoryID)
        
        do {
            if let category = try context.fetch(fetchRequest).first {
                context.delete(category)
                try context.save()
            }
        } catch {
            print("Failed to delete category: \(error)")
        }
    }
}
