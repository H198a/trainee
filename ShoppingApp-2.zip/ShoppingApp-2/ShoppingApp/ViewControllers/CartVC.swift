//
//  CartVC.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 27/03/25.
//

import UIKit
import CoreData
import Kingfisher

class CartVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var TblView: UITableView!
    @IBOutlet weak var tblViewHwight: NSLayoutConstraint!
    var transactions: [(name: String?,  price: String?, imageName: String?, count: Int32)] = []
    var arrSize = ["S","M","S"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchTransactions()
        let nibName = UINib(nibName: "CartCell", bundle: nil)
        TblView.register(nibName, forCellReuseIdentifier: "CartCell")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    @IBAction func BtnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension CartVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return transactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CartCell", for: indexPath) as! CartCell
        let categoryData = transactions[indexPath.row]
        cell.LblName.text = categoryData.name
        cell.LblSize.text = ""
        cell.LblCount.text = "\(categoryData.count)"
        cell.LblPrice.text = categoryData.price
        cell.cateforyImg.kf.setImage(with: URL(string: categoryData.imageName ?? "Frame 16564"))
//        if let imageUrl = categoryData.imageName, let url = URL(string: imageUrl) {
//            DispatchQueue.global().async {
//                if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
//                    DispatchQueue.main.async {
//                        cell.cateforyImg.image = image
//                    }
//                }
//            }
//        } else {
//            cell.cateforyImg.image = UIImage(named: "Frame 16564") // Default image
//        }
        return cell
    }
}
extension CartVC{
    func fetchTransactions() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        let incomeFetch: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        incomeFetch.predicate = NSPredicate(format: "count > 1")
        do {
            let expenseResults = try context.fetch(incomeFetch)
            for expense in expenseResults {
                let newName = expense.name ?? ""
                let newPrice = expense.price
                let newImageName = expense.image
                let newCount = expense.count
                
                transactions.append((name: newName, price: newPrice, imageName: newImageName, count: newCount))
            }
        }catch {
            print("Failed to fetch transactions: \(error)")
        }
    }
}
