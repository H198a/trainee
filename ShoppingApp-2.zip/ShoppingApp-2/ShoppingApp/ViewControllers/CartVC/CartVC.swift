//
//  CartVC.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 27/03/25.
//

import UIKit
import CoreData
import Kingfisher
//import MultiplelineTextField
class CartVC: UIViewController {
//MARK: Outlet and Variable  Declaration
    @IBOutlet weak var TblView: UITableView!
    @IBOutlet weak var tblViewHeight: NSLayoutConstraint!
    @IBOutlet weak var LblAmount: UILabel!
    @IBOutlet weak var LblNewTotalAmount: UILabel!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtAddress: UITextView!
    @IBOutlet weak var detailView: UIView!
    @IBOutlet weak var totalView: UIView!
    @IBOutlet weak var lblNoItems: UILabel!
    @IBOutlet weak var btnCheckout: UIButton!
    @IBOutlet weak var lblSubtotal: UILabel!
    @IBOutlet weak var lblDelivery: UILabel!
    @IBOutlet weak var lbldeliveryAmount: UILabel!
    @IBOutlet weak var lblTtl: UILabel!
    @IBOutlet weak var lblDeliveryInfo: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    
    var categoryList: [ListData] = []
    var totalAmount = 0.0
    var transactions: [(name: String?,  price: Double , imageName: String?, count: Int32, addedItem: Int32, categoryID: Int32)] = []
    var arrSize = ["S","M","S"]
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchTransactions()
        setUP()

        let nibName = UINib(nibName: "CartCell", bundle: nil)
        TblView.register(nibName, forCellReuseIdentifier: "CartCell")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    @IBAction func BtnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnProceedToCheckoutClick(_ sender: Any) {
        if validateFields(){
            storeOrderDataToCoreData()
            print(storeOrderDataToCoreData())
            let orderVC = self.storyboard?.instantiateViewController(withIdentifier: "OrderVC") as! OrderVC
            self.navigationController?.pushViewController(orderVC , animated: true)
        }
    }
}
//MARK: Setup UI
extension CartVC{
    func setUP(){
        totalView.isHidden = true
        detailView.isHidden = true
        btnCheckout.isHidden = true
        lblNoItems.isHidden = false
        LblAmount.font = .setFont(type: .Regular, size: 19)
        LblNewTotalAmount.font = .setFont(type: .Bold, size: 19)
        lblTtl.font = .setFont(type: .Bold, size: 19)
        lblDelivery.font = .setFont(type: .Regular, size: 19)
        lblSubtotal.font = .setFont(type: .Regular, size: 19)
        lblDelivery.font = .setFont(type: .Regular, size: 19)
        lblNoItems.font = .setFont(type: .Bold, size: 21)
        lblDeliveryInfo.font = .setFont(type: .Bold, size: 16)
        lblName.font = .setFont(type: .Regular, size: 15)
        lblEmail.font = .setFont(type: .Regular, size: 15)
        lblPhone.font = .setFont(type: .Regular, size: 15)
        lblAddress.font = .setFont(type: .Regular, size: 15)
    }
}
//MARK: Tablview DataSource, Delegate
extension CartVC: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
         return transactions.count
    }
  
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CartCell", for: indexPath) as! CartCell
        let categoryData = transactions[indexPath.row]
        cell.addShadow(backgroundColor: .white, cornerRadius: 8, shadowRadius: 3, shadowOpacity: 0.1, shadowPathInset: (dx: 5, dy: 8), shadowPathOffset: (dx: 5, dy: 5))
        cell.LblName.text = categoryData.name
        cell.LblSize.text = "M"
        cell.LblPrice.text = "$\(categoryData.price)"
        cell.Img.kf.setImage(with: URL(string: categoryData.imageName ?? "Frame 16564"))
        let existingCategory = fetchCategoryFromCoreData(categoryID: Int(categoryData.categoryID))
        cell.count = Int(existingCategory?.count ?? 0)
        cell.LblCount.text = "\(cell.count)"
        if cell.count == 0 {
            cell.BtnPlus.backgroundColor = .clear
            cell.BtnPlus.titleLabel?.textColor = .app
            totalView.isHidden = true
            detailView.isHidden = true
            lblNoItems.isHidden = false
            btnCheckout.isHidden = true
        } else{
            cell.BtnPlus.backgroundColor = .app
            cell.BtnPlus.titleLabel?.textColor = .white
            totalView.isHidden = false
            detailView.isHidden = false
            lblNoItems.isHidden = true
            btnCheckout.isHidden = false
        }
        
        // Update Core Data when count changes
        cell.onCountChange = { [weak self] newCount, updatedCell in
            guard let self = self, let indexPath = self.TblView.indexPath(for: updatedCell) else { return }
            let category = self.transactions[indexPath.row]
               let price = category.price
            if newCount == 0 {
               
                updatedCell.BtnPlus.setTitleColor(.app, for: .normal)
                updatedCell.BtnPlus.backgroundColor = .white
                updatedCell.BtnPlus.layer.borderColor = UIColor.app.cgColor
                updatedCell.BtnPlus.layer.borderWidth = 1
                
                // remove from core data
                let category = self.transactions[indexPath.row]
                self.deleteCategoryFromCoreData(categoryID: Int(category.categoryID))
                
                // remove from array
                self.transactions.remove(at: indexPath.row)
                
                // remove from table view
                self.TblView.deleteRows(at: [indexPath], with: .automatic)
                updateTableViewHeight()
                totalView.isHidden = true
                detailView.isHidden = true
                lblNoItems.isHidden = false
                btnCheckout.isHidden = true
            } else {
                
                updatedCell.BtnPlus.setTitleColor(.white, for: .normal)
                updatedCell.BtnPlus.backgroundColor = .app
                updatedCell.BtnPlus.layer.borderColor = UIColor.clear.cgColor
                updatedCell.BtnPlus.layer.borderWidth = 0
                
                // Update count in Core Data
                let category = self.transactions[indexPath.row]
                self.updateCategoryCountInCoreData(categoryID: Int(category.categoryID), newCount: newCount)
                updateTableViewHeight()
                totalView.isHidden = false
                detailView.isHidden = false
                btnCheckout.isHidden = false
                lblNoItems.isHidden = true
            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100 // Adjust row height as needed
    }
    
}
//MARK: Custom Functions
extension CartVC{
    func fetchTransactions() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        let incomeFetch: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        incomeFetch.predicate = NSPredicate(format: "count > 0")
        do {
            let expenseResults = try context.fetch(incomeFetch)
            for expense in expenseResults {
                let newName = expense.name ?? ""
                let newPrice = Double(expense.price ?? "") ?? 0.0
                let newImageName = expense.image
                let newCount = expense.count
                let newItem = expense.addedItem
                let newcategoryID = expense.categoryID
                if newCount == 0{
                    totalView.isHidden = true
                    detailView.isHidden = true
                    lblNoItems.isHidden = false
                    print("no data available")
                } else{
                    totalView.isHidden = false
                    detailView.isHidden = false
                    lblNoItems.isHidden = true
                    totalAmount += (newPrice * Double(newCount))
                    transactions.append((name: newName, price: newPrice, imageName: newImageName, count: newCount, addedItem: newItem, categoryID: newcategoryID))
                    
                }
                updateTableViewHeight()
               
                LblAmount.text = "$\(totalAmount)"
                let newTotalAmount = totalAmount + 5
                TblView.reloadData()
                LblNewTotalAmount.text = "$\(newTotalAmount)"
               
            }
        }catch {
            print("Failed to fetch transactions: \(error)")
        }
    }
    func updateTableViewHeight() {
        let rowHeight: CGFloat = 100 // This should be the height of a single row in the table
        let totalHeight = CGFloat(transactions.count) * rowHeight
        tblViewHeight.constant = totalHeight
        
        // Trigger layout update
        TblView.reloadData()
        //TblView.layoutIfNeeded()
    }
    func validateFields() -> Bool {
        var isValid = true
        
        if let name = txtName.text, name.isEmpty{
            showAlert(message: "Please enter your name")
            isValid = false
        }
        // Validate Email
        if let email = txtEmail.text {
            if email.isEmpty {
                showAlert(message: "Please enter your email.")
                return false
            } else if !Helper.shared.validateEmailId(email) {
                showAlert(message: "Please enter a valid email address.")
                return false
            }
        }
        
        // Validate Name
        if let number = txtPhone.text, number.isEmpty {
            showAlert(message: "Please enter your mobile number")
            isValid = false
        }
        
     //VAlidate Address
        if let address = txtAddress.text, address.isEmpty{
            showAlert(message: "Please enter your address")
            isValid = false
        }
        return isValid
    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    func fetchCategoryFromCoreData(categoryID: Int) -> CartEntity? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
        let context = appDelegate.persistentContainer.viewContext

        let fetchRequest: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "categoryID == %d", categoryID)

        do {
            let results = try context.fetch(fetchRequest)
            return results.first
        } catch {
            print("Failed to fetch category: \(error.localizedDescription)")
            return nil
        }
    }
    func updateCategoryCountInCoreData(categoryID: Int, newCount: Int) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        if let category = fetchCategoryFromCoreData(categoryID: categoryID) {
            let oldCount = Int(category.count)
                 let price = Double(category.price ?? "0") ?? 0.0
            
            totalAmount += price * Double(newCount - oldCount)
            LblAmount.text = "$\(totalAmount)"
            let newTotalAmount = totalAmount + 5
            LblNewTotalAmount.text = "$\(newTotalAmount)"
            category.count = Int32(newCount)//update data in coredata
        } else {
            // If category doesn't exist, create new entry
            if let categoryData = categoryList.first(where: { $0.id == categoryID }) {
                let newCategory = CartEntity(context: context)
                newCategory.categoryID = Int32(categoryID)
                newCategory.name = categoryData.name
                newCategory.image = categoryData.image
                newCategory.price = "\(categoryData.price)"
                newCategory.count = Int32(newCount)
                
                // Update totalAmount
                totalAmount += Double(categoryData.price) * Double(newCount)
                LblAmount.text = "$\(totalAmount)"
                let newTotalAmount = totalAmount + 5
                LblNewTotalAmount.text = "$\(newTotalAmount)"
            }
        }

        do {
            try context.save()
        } catch {
            print("Failed to update count: \(error.localizedDescription)")
        }
    }
    func deleteCategoryFromCoreData(categoryID: Int) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        let fetchRequest: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "categoryID == %d", categoryID)
        
        do {
            if let category = try context.fetch(fetchRequest).first {
                let price = Double(category.price ?? "0") ?? 0.0
                let count = Int(category.count)
                // Deduct the total amount before deleting
                totalAmount -= price * Double(count)
                if totalAmount < 0 { totalAmount = 0 } // Prevent negative values
                LblAmount.text = "$\(totalAmount)"
                let newTotalAmount = totalAmount + 5
                LblNewTotalAmount.text = "$\(newTotalAmount)"
                
                context.delete(category)
                try context.save()
            
            }
        } catch {
            print("Failed to delete category: \(error)")
        }
    }
    
    func storeOrderDataToCoreData(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        let newOrder = OrderEntity(context: context)
        newOrder.address = txtAddress.text
        newOrder.phone = Int32(txtPhone.text ?? "")!
        newOrder.mail = txtEmail.text
        newOrder.name = txtName.text
        newOrder.orderedID = "12nj2324"
        newOrder.size = "M"
        newOrder.total = Int32(LblNewTotalAmount.text ?? "") ?? 0
        for item in transactions{
            let newOrder = OrderEntity(context: context)
            newOrder.title = item.name
            newOrder.img = item.imageName
            newOrder.count = item.count
            newOrder.price = "\(item.price)"
        }
        do {
            print(newOrder)
            try context.save()
            print("data saved successfully")
        } catch{
            print("somethig went wrong")
        }
        
    }
}
extension UITableViewCell {
    func addShadow(backgroundColor: UIColor = .white, cornerRadius: CGFloat = 10, shadowRadius: CGFloat = 5, shadowOpacity: Float = 0.1, shadowPathInset: (dx: CGFloat, dy: CGFloat), shadowPathOffset: (dx: CGFloat, dy: CGFloat)) {
        layer.cornerRadius = cornerRadius
        layer.masksToBounds = true
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        layer.shadowRadius = shadowRadius
        layer.shadowOpacity = shadowOpacity
        layer.shadowPath = UIBezierPath(roundedRect: bounds.insetBy(dx: shadowPathInset.dx, dy: shadowPathInset.dy).offsetBy(dx: shadowPathOffset.dx, dy: shadowPathOffset.dy), byRoundingCorners: .allCorners, cornerRadii: CGSize(width: cornerRadius, height: cornerRadius)).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        
        let whiteBackgroundView = UIView()
        whiteBackgroundView.backgroundColor = backgroundColor
        whiteBackgroundView.layer.cornerRadius = cornerRadius
        whiteBackgroundView.layer.masksToBounds = true
        whiteBackgroundView.clipsToBounds = false
        
        whiteBackgroundView.frame = bounds.insetBy(dx: shadowPathInset.dx, dy: shadowPathInset.dy)
        insertSubview(whiteBackgroundView, at: 0)
    }
    
}
/*
 
 Search
 No data in cart
 Total amount
 font
 */
