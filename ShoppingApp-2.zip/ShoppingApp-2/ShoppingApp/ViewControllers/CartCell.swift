//
//  CartCell.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 27/03/25.
//

import UIKit

class CartCell: UITableViewCell {
//MARK: Outlet and Varible Declaration
    @IBOutlet weak var LblName: UILabel!
    @IBOutlet weak var LblSize: UILabel!
    @IBOutlet weak var LblPrice: UILabel!
    @IBOutlet weak var cateforyImg: UIImageView!
    @IBOutlet weak var LblCount: UILabel!
    @IBOutlet weak var mainView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    //https://www.figma.com/design/AsTjFRkx9WVgYShiX2mMtk/Order-and-cart?node-id=1-303&t=t0ToKDzCb15lqhqG-0
}
