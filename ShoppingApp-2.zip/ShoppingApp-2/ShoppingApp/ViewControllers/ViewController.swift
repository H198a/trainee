//
//  ViewController.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 26/03/25.
//

import UIKit
import Kingfisher
import Alamofire
import SwiftLoader
import IQKeyboardManager
import CoreData

class ViewController: UIViewController {
    //MARK: Outlet and Variable Declaration
    @IBOutlet weak var searchBar: UITextField!
    @IBOutlet weak var categorySelectionCollView: UICollectionView!
    @IBOutlet weak var categoryCollview: UICollectionView!
    @IBOutlet weak var LblCategory: UILabel!
    @IBOutlet weak var LblSearch: UILabel!
    @IBOutlet weak var viewheight: NSLayoutConstraint!
    @IBOutlet weak var LblHeight: NSLayoutConstraint!
    @IBOutlet weak var LblBadge: UILabel!
    
    var selectedCategoryIndex: Int? = nil
    var dataArray: [newData] = []
    var categoryList: [ListData] = []
    //var dataArray = CategoryViewModel()
    var filteredArray: [newData] = []
    var imgArr = ["Frame 16563","Frame 16563","Frame 16563","Frame 16563","Frame 16563","Frame 16563","Frame 16563"]

    override func viewDidLoad() {
        
       
        super.viewDidLoad()
        LblSearch.isHidden = true
        // Do any additional setup after loading the view
        //dataArray.getcategoryData()
        SwiftLoader.show(title: "Loading...", animated: true)
        getCategoryData()
        searchBar.delegate = self
        //searchBar.keyboardType = .webSearch
        filteredArray = dataArray
            
        let nibName = UINib(nibName: "CategoerySelectionCell", bundle: nil)
        categorySelectionCollView.register(nibName, forCellWithReuseIdentifier: "CategoerySelectionCell")
        
        let neNibName = UINib(nibName: "CategoryListCell", bundle: nil)
        categoryCollview.register(neNibName, forCellWithReuseIdentifier: "CategoryListCell")
        categorySelectionCollView.isHidden = false
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateCartBadge()
        getCategoryData()
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    @objc func didPressOnDontBtn(){
        searchBar.resignFirstResponder()
        categorySelectionCollView.isHidden = false
        viewheight.constant = 100
        LblHeight.constant = 23
        UIView.animate(withDuration: 0){
            self.view.layoutIfNeeded()
        }
        LblCategory.isHidden = false
    }
    
    @IBAction func btnCartClick(_ sender: Any) {
        let signupVC = storyboard?.instantiateViewController(withIdentifier: "CartVC") as! CartVC
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    
}
//MARK: UITextField Delegate
extension ViewController: UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Select all categories when search bar is clicked
        selectedCategoryIndex = nil
        filteredArray = dataArray // Show all categories
        //categorySelectionCollView.isHidden = false // Show category selection
  
            self.getCategoryData()
            //self.selectedCategoryIndex = 0
            let firstCategoryId = self.dataArray[0].id
            self.getCategoryList(catId: firstCategoryId) // Fetch first category data
        categorySelectionCollView.isHidden = true
        viewheight.constant = 0
        LblHeight.constant = 0
        UIView.animate(withDuration: 0){
            self.view.layoutIfNeeded()
        }
        LblCategory.isHidden = true
        
        
        textField.addDoneOnKeyboard(withTarget: self, action: #selector(didPressOnDontBtn))
        
        categoryCollview.reloadData()
    }

//    func textFieldDidEndEditing(_ textField: UITextField) {
//        let searchText = textField.text?.lowercased() ?? ""
//
//        if searchText.isEmpty {
//            if !self.dataArray.isEmpty {
//                self.selectedCategoryIndex = 0
//                let firstCategoryId = self.dataArray[0].id
//                self.getCategoryList(catId: firstCategoryId) // Fetch first category data
//            }
//            // Show all categories when search is empty
//            categorySelectionCollView.isHidden = false
//            filteredArray = dataArray
//        } else {
//            // Hide category selection and filter results
//            categorySelectionCollView.isHidden = true
//            categoryList = categoryList.filter { $0.name.lowercased().contains(searchText) }
//        }
//
//        categoryCollview.reloadData()
//    }
    func textFieldDidChangeSelection(_ textField: UITextField) {
        let searchText = textField.text?.lowercased() ?? ""

        if searchText.isEmpty {
            self.getCategoryData()
            // If search is cleared, show category selection again
            categorySelectionCollView.isHidden = false
            viewheight.constant = 100
            LblHeight.constant = 23
            UIView.animate(withDuration: 0){
                self.view.layoutIfNeeded()
            }
            LblCategory.isHidden = false
            filteredArray = dataArray
          
            categorySelectionCollView.reloadData()
        } else {
            // Hide category selection only when user starts typing
            categorySelectionCollView.isHidden = true
            viewheight.constant = 0
            LblHeight.constant = 0
            UIView.animate(withDuration: 0){
                self.view.layoutIfNeeded()
            }
            LblCategory.isHidden = true
            categoryList = categoryList.filter { $0.name.lowercased().contains(searchText) }
            LblSearch.isHidden = !filteredArray.isEmpty
        }
        categoryCollview.reloadData()
    }
}
//MARK: CollectionViewdelegate, dataSource
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == categorySelectionCollView {
            return dataArray.count
           // return selectedCategoryIndex == nil ? dataArray.count : 0
        } else if collectionView == categoryCollview {
            return categoryList.count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.categorySelectionCollView{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoerySelectionCell", for: indexPath) as! CategoerySelectionCell
            let category = dataArray[indexPath.item]
            cell.Lblcategory.text = category.name
            //cell.categoryImg.image = UIImage(named: imgArr[indexPath.row])
            cell.categoryImg.kf.setImage(with: URL(string: category.image))
            cell.categoryView.borderColor = .clear
            if indexPath.row == selectedCategoryIndex {
                cell.Lblcategory.textColor = .orange
                cell.categoryView.borderColor = .orange
                cell.categoryView.backgroundColor = .clear
            } else {
                cell.Lblcategory.textColor = .black // Default color
                cell.categoryView.borderColor = .clear // Default border
                cell.categoryView.backgroundColor = .view
            }
            return cell
        } else if collectionView == self.categoryCollview{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryListCell", for: indexPath) as! CategoryListCell
            let categoryListData = categoryList[indexPath.item]
            cell.addShadow()
            cell.BtnMinus.setTitle("-", for: .normal)
            cell.BtnPlus.setTitle("+", for: .normal)
            cell.mainImg.kf.setImage(with: URL(string: categoryListData.image))
            cell.LblHead.text = categoryListData.name
            cell.LblPrice.text = "$\(categoryListData.price)"
            let existingCategory = fetchCategoryFromCoreData(categoryID: categoryListData.id)
            cell.count = Int(existingCategory?.count ?? 0)
                cell.LblCount.text = "\(cell.count)"

            if cell.count <= 0 {
                   cell.BtnPlus.setTitleColor(.orange, for: .normal)
                   cell.BtnPlus.backgroundColor = .white
                   cell.BtnPlus.layer.borderColor = UIColor.orange.cgColor
                   cell.BtnPlus.layer.borderWidth = 1
               } else {
                   cell.BtnPlus.setTitleColor(.white, for: .normal)
                   cell.BtnPlus.backgroundColor = .orange
                   cell.BtnPlus.layer.borderColor = UIColor.clear.cgColor // Clear border when count > 0
                   cell.BtnPlus.layer.borderWidth = 0 // Clear border width when count > 0
               }

          
                // Update Core Data when count changes
            cell.onCountChange = { [weak self] newCount, updatedCell in
                guard let indexPath = self?.categoryCollview.indexPath(for: updatedCell) else { return }
                let category = self?.categoryList[indexPath.item]
                self?.updateCategoryCountInCoreData(categoryID: category?.id ?? 0, newCount: newCount)
                self?.updateCartBadge()

                if newCount <= 0 {
                           updatedCell.BtnPlus.setTitleColor(.orange, for: .normal)
                           updatedCell.BtnPlus.backgroundColor = .white
                           updatedCell.BtnPlus.layer.borderColor = UIColor.orange.cgColor
                           updatedCell.BtnPlus.layer.borderWidth = 1
                       } else {
                           updatedCell.BtnPlus.setTitleColor(.white, for: .normal)
                           updatedCell.BtnPlus.backgroundColor = .orange
                           updatedCell.BtnPlus.layer.borderColor = UIColor.clear.cgColor
                           updatedCell.BtnPlus.layer.borderWidth = 0
                       }
            }


            return cell
        }
        return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView.tag == 0 {
            selectedCategoryIndex = indexPath.row // Track selected category index
            let selectedCategory = dataArray[indexPath.row] // Get selected category
            let categoryId = selectedCategory.id
            
            // Fetch category list based on selected categoryId
            getCategoryList(catId: categoryId)
            
            // Reload categorySelectionCollView to update the UI for selection state
            collectionView.reloadData()
        } else {
            print("dsfkhk bwfd")
        }
        for category in categoryList{
            saveCategoryToCoreData(category: category)
            print(category)
            
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == self.categorySelectionCollView{
            
            return CGSize(width: (self.categorySelectionCollView.frame.width), height: self.categorySelectionCollView.frame.height)
        }else{
           
            return CGSize(width: (self.categoryCollview.frame.width - 20) / 2, height: 245.0)
        }
    }//217h,156w

    
}
//MARK: Custom Functions
extension ViewController{
    func getCategoryData(){
        SwiftLoader.show(title: "Loading...",animated: true)
        AF.request("https://beta2.moontechnolabs.com/practical_api/public/api/category-list").response {
            response in
            if let data = response.data{
                do{
                    let userResponse = try JSONDecoder().decode(Category.self, from: data)
                   //print(userResponse)
                    self.dataArray = userResponse.data
                    
                    // Check if categories exist, then set the first one as selected
                    if !self.dataArray.isEmpty {
                        self.selectedCategoryIndex = 0
                        let firstCategoryId = self.dataArray[0].id
                        self.getCategoryList(catId: firstCategoryId) // Fetch first category data
                    }
                    
                    DispatchQueue.main.async{
                        SwiftLoader.hide()
                        self.categorySelectionCollView.reloadData()
                    }
                  
                } catch let err{
                    print(err.localizedDescription)
                }
            }
        }
    }
    
    func getCategoryList(catId: Int){
        SwiftLoader.hide()
        AF.request("https://beta2.moontechnolabs.com/practical_api/public/api/category-product-list?categoryid=\(catId)").response {
            response in
            if let data = response.data{
                do{
                    let userResponse = try JSONDecoder().decode(CategoryList.self, from: data)
                    //print(userResponse)
                    self.categoryList = userResponse.data
                    
                    for category in self.categoryList {
                        self.saveCategoryToCoreData(category: category)
                        print(category)
                    }
                    DispatchQueue.main.async{
                        self.categoryCollview.reloadData()
                    }
                  
                } catch let err{
                    print(err.localizedDescription)
                }
            }
        }
    }
    func saveCategoryToCoreData(category: ListData) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        let newCategory = CartEntity(context: context)
        newCategory.name = category.name
        newCategory.image = category.image
        newCategory.price = "\(category.price)"
        newCategory.count = 0 // Default value

        do {
            try context.save()
            print("Saved category: \(category.name)")
        } catch {
            print("Failed to save category: \(error.localizedDescription)")
        }
    }
    func fetchCategoryFromCoreData(categoryID: Int) -> CartEntity? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
        let context = appDelegate.persistentContainer.viewContext

        let fetchRequest: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "categoryID == %d", categoryID)

        do {
            let results = try context.fetch(fetchRequest)
            return results.first
        } catch {
            print("Failed to fetch category: \(error.localizedDescription)")
            return nil
        }
    }
    func updateCategoryCountInCoreData(categoryID: Int, newCount: Int) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        if let category = fetchCategoryFromCoreData(categoryID: categoryID) {
            category.count = Int32(newCount)
        } else {
            // If category doesn't exist, create new entry
            let newCategory = CartEntity(context: context)
            newCategory.categoryID = Int32(categoryID)
            newCategory.name = categoryList.first { $0.id == categoryID }?.name
            newCategory.image = categoryList.first { $0.id == categoryID }?.image
            newCategory.price = "\(categoryList.first { $0.id == categoryID }?.price ?? 0)"
            newCategory.count = Int32(newCount)
        }

        do {
            try context.save()
        } catch {
            print("Failed to update count: \(error.localizedDescription)")
        }
    }
    func getTotalCartItemCount() -> Int {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return 0 }
        let context = appDelegate.persistentContainer.viewContext

        let fetchRequest: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "count > 0")

        do {
            let cartItems = try context.fetch(fetchRequest)
            return cartItems.count   // ← this is what you need
        } catch {
            print("Error fetching cart count: \(error.localizedDescription)")
            return 0
        }
    }


    func updateCartBadge() {
        let totalItems = getTotalCartItemCount()
        
        if totalItems > 0 {
            LblBadge.isHidden = false
            LblBadge.text = "\(totalItems)"
        } else {
            LblBadge.isHidden = true
        }
    }

}
extension UICollectionViewCell {
    func addShadow(corner: CGFloat = 3, color: UIColor = .black, radius: CGFloat = 5, offset: CGSize = CGSize(width: 3, height: 3), opacity: Float = 0.2) {
        let cell = self
        cell.contentView.layer.borderWidth = 0
        cell.contentView.layer.borderColor = UIColor.clear.cgColor
        cell.contentView.layer.masksToBounds = true
        cell.layer.shadowColor = color.cgColor
        cell.layer.shadowOffset = offset
        cell.layer.shadowRadius = radius
        cell.layer.shadowOpacity = opacity
        cell.layer.cornerRadius = 10
        cell.layer.masksToBounds = false
        cell.layer.shadowPath = UIBezierPath(roundedRect: self.bounds, cornerRadius: cell.contentView.layer.cornerRadius).cgPath
    }
}
