//
//  OrderVC.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 28/03/25.
//

import UIKit
import CoreData

class OrderVC: UIViewController {
//MARK: Outlet and variable Declaration
    @IBOutlet weak var LblAmount: UILabel!
    @IBOutlet weak var LblNewTotalAmount: UILabel!
    @IBOutlet weak var lblOrder: UILabel!
    @IBOutlet weak var lblPayment: UILabel!
    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblSubtotal: UILabel!
    @IBOutlet weak var lblDelivery: UILabel!
    @IBOutlet weak var lblFontTotal: UILabel!
    var totalAmount = 0.0
    var transactions: [(name: String?,  price: Double , imageName: String?, count: Int32, addedItem: Int32)] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchTransactions()
        setUP()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnShoppingClick(_ sender: Any) {
        clearCartData()
        navigationController?.popToRootViewController(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
//MARK: Setup UI
extension OrderVC{
    func setUP(){
        LblAmount.font = UIFont.setFont(type: .Regular, size: 19)
        LblNewTotalAmount.font = UIFont.setFont(type: .ExtraBold, size: 19)
        lblFontTotal.font = .setFont(type: .ExtraBold, size: 20)
        lblId.font = .setFont(type: .Bold, size: 19)
        lblOrder.font = .setFont(type: .Regular, size: 19)
        lblPayment.font = .setFont(type: .Regular, size: 19)
        lblDelivery.font = .setFont(type: .Regular, size: 19)
        lblSubtotal.font = .setFont(type: .Regular, size: 19)
    }
}
//MARK: Custom Functiona
extension OrderVC{
    func fetchTransactions() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        let incomeFetch: NSFetchRequest<CartEntity> = CartEntity.fetchRequest()
        incomeFetch.predicate = NSPredicate(format: "count > 0")
        do {
            let expenseResults = try context.fetch(incomeFetch)
            for expense in expenseResults {
                let newName = expense.name ?? ""
                let newPrice = Double(expense.price ?? "") ?? 0.0
                let newImageName = expense.image
                let newCount = expense.count
                let newItem = expense.addedItem
            
                transactions.append((name: newName, price: newPrice, imageName: newImageName, count: newCount, addedItem: newItem))
                totalAmount += (newPrice * Double(newCount))
                LblAmount.text = "$\(totalAmount)"
                let newTotalAmount = totalAmount + 5
                LblNewTotalAmount.text = "$\(newTotalAmount)"
            
            }
        }catch {
            print("Failed to fetch transactions: \(error)")
        }
    }
    func clearCartData() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = CartEntity.fetchRequest()
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            try context.execute(deleteRequest)
            try context.save()
            print("Cart data cleared successfully")
        } catch {
            print("Failed to clear cart: \(error)")
        }
    }
}
