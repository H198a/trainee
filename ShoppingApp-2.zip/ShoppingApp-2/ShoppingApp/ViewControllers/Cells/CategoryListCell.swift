//
//  CategoryListCell.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 26/03/25.
//

import UIKit

class CategoryListCell: UICollectionViewCell {
//MARK: IBOutlet Declaration
    @IBOutlet weak var LblHead: UILabel!
    @IBOutlet weak var LblPrice: UILabel!
    @IBOutlet weak var BtnMinus: UIButton!
    @IBOutlet weak var BtnPlus: UIButton!
    @IBOutlet weak var LblCount: UILabel!
    @IBOutlet weak var mainImg: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var shadowView: UIView!
    
    var count: Int = 1 {
          didSet {
              LblCount.text = "\(count)"
          }
      }

    var onCountChange: ((Int, CategoryListCell) -> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        BtnMinus.addTarget(self, action: #selector(decreaseCount), for: .touchUpInside)
        BtnPlus.addTarget(self, action: #selector(increaseCount), for: .touchUpInside)
    }
    @objc func decreaseCount() {
           if count > 1 {
               count -= 1
               onCountChange?(count, self)
           }
       }

       @objc func increaseCount() {
           count += 1
           onCountChange?(count, self)
       }
}
