//
//  CategoryListCell.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 26/03/25.
//

import UIKit

class CategoryListCell: UICollectionViewCell {
//MARK: IBOutlet Declaration
    @IBOutlet weak var LblHead: UILabel!
    @IBOutlet weak var LblPrice: UILabel!
    @IBOutlet weak var BtnMinus: UIButton!
    @IBOutlet weak var BtnPlus: UIButton!
    @IBOutlet weak var LblCount: UILabel!
    @IBOutlet weak var mainImg: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var shadowView: UIView!
    
    var count: Int = 1 {
          didSet {
              LblCount.text = "\(count)"
          }
      }

    var onCountChange: ((Int, CategoryListCell) -> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        BtnMinus.addTarget(self, action: #selector(decreaseCount), for: .touchUpInside)
        BtnPlus.addTarget(self, action: #selector(increaseCount), for: .touchUpInside)
    }
    @objc func decreaseCount() {
        if count > 0 {
            count -= 1
            BtnPlus.setTitleColor(.orange, for: .normal)
            BtnPlus.backgroundColor = .white
            BtnPlus.layer.borderColor = UIColor.orange.cgColor
            BtnPlus.layer.borderWidth = 1

            onCountChange?(count, self)
            
        }
    }

    @objc func increaseCount() {
        count += 1
        BtnPlus.setTitleColor(.white, for: .normal)
        BtnPlus.backgroundColor = .orange
        BtnPlus.layer.borderColor = UIColor.clear.cgColor // Clear border when count > 0
        BtnPlus.layer.borderWidth = 0
        onCountChange?(count, self)
        
    }
}
