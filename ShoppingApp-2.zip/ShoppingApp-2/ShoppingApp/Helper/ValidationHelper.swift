//
//  ValidationHelper.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 28/03/25.
//

import Foundation
class Helper{
    
    static var shared: Helper = Helper()
    
    func validateNumber(_ number: String) -> Bool {
        let numberRegEx = "^[0-9]+$"
        return applyPredicateOnRegex(regexStr: numberRegEx, text: number)
    }
    
    // Email Validation
    func validateEmailId(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        return applyPredicateOnRegex(regexStr: emailRegEx, text: email)
    }

    
    // Apply regex to validate string
    func applyPredicateOnRegex(regexStr: String, text: String) -> Bool {
        let trimmedString = text.trimmingCharacters(in: .whitespaces)
        let validateString = NSPredicate(format: "SELF MATCHES %@", regexStr)
        return validateString.evaluate(with: trimmedString)
    }
}
