//
//  CategoryModel.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 26/03/25.
//

import Foundation

// MARK: - Welcome
struct Category: Codable {
    let status: Bool
    let code: Int
    let msg, version: String
    let data: [newData]
}

// MARK: - Datum
struct newData: Codable {
    let id: Int
    let name: String
    let image: String
}
