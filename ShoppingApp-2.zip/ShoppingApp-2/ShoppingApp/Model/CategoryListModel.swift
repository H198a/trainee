//
//  CategoryListModel.swift
//  ShoppingApp
//
//  Created by Hemaxi S on 26/03/25.
//

import Foundation

// MARK: - Welcome
struct CategoryList: Codable {
    let status: Bool
    let code: Int
    let msg, version: String
    let data: [ListData]
}

// MARK: - Datum
struct ListData: Codable {
    let id, categoryID: Int
    let name: String
    let price: Int
    let image: String

    enum CodingKeys: String, CodingKey {
        case id
        case categoryID = "category_id"
        case name, price, image
    }
}
