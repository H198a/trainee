//
//  File.swift
//  ShoppingApp
//
//  Created by admin on 02/04/25.
//

import Foundation
/*
 func storeOrderDataToCoreData() {
     guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
     let context = appDelegate.persistentContainer.viewContext

     // Create a single OrderEntity for the main order details
     let order = OrderEntity(context: context)
     order.address = txtAddress.text
     order.phone = Int32(txtPhone.text ?? "0") ?? 0 // Default to 0 if conversion fails
     order.mail = txtEmail.text
     order.name = txtName.text
     order.orderedID = "12nj2324"
     order.size = "M"
     order.total = Int32(LblNewTotalAmount.text?.replacingOccurrences(of: "$", with: "") ?? "0") ?? 0 // Remove '$' and default to 0

     // Store transaction items as a comma-separated string within the same OrderEntity
     var transactionString = ""
     for item in transactions {
         let itemString = "\(item.name ?? ""),\(item.price),\(item.imageName ?? ""),\(item.count),\(item.addedItem),\(item.categoryID);"
         transactionString += itemString
     }
     order.transactionItemsString = transactionString // Add a new property to OrderEntity

     do {
         try context.save()
         print("Data saved successfully")
     } catch {
         print("Something went wrong: \(error)")
     }
 }
 
 func retrieveOrderData(from order: OrderEntity) -> [String: Any]? {
     guard let transactionString = order.transactionItemsString else { return nil }

     let transactionItems = transactionString.components(separatedBy: ";")
     var transactions: [[String: Any]] = []

     for itemString in transactionItems {
         if !itemString.isEmpty {
             let itemComponents = itemString.components(separatedBy: ",")
             if itemComponents.count == 6 {
                 let transaction: [String: Any] = [
                     "name": itemComponents[0],
                     "price": Double(itemComponents[1]) ?? 0.0,
                     "imageName": itemComponents[2],
                     "count": Int32(itemComponents[3]) ?? 0,
                     "addedItem": Int32(itemComponents[4]) ?? 0,
                     "categoryID": Int32(itemComponents[5]) ?? 0
                 ]
                 transactions.append(transaction)
             }
         }
     }

     // Retrieve other order data
     let orderData: [String: Any] = [
         "name": order.name ?? "",
         "mail": order.mail ?? "",
         "phone": order.phone,
         "address": order.address ?? "",
         "orderedID": order.orderedID ?? "",
         "size": order.size ?? "",
         "total": order.total,
         "transactions": transactions
     ]

     return orderData
 }
 
 
 
 
 
 import UIKit
 import CoreData
 import Kingfisher

 // Custom UITableViewCell for displaying order items
 class OrderItemCell: UITableViewCell {
     @IBOutlet weak var nameLabel: UILabel!
     @IBOutlet weak var priceLabel: UILabel!
     @IBOutlet weak var countLabel: UILabel!
     // Add other labels as needed

     override func awakeFromNib() {
         super.awakeFromNib()
         // Initialization code
     }

     override func setSelected(_ selected: Bool, animated: Bool) {
         super.setSelected(selected, animated: animated)
         // Configure the view for the selected state
     }
 }

 // CartVC (Where you store the order data)
 class CartVC: UIViewController {
     @IBOutlet weak var TblView: UITableView!
     // ... other outlets ...
     var transactions: [(name: String?, price: Double, imageName: String?, count: Int32, addedItem: Int32, categoryID: Int32)] = []

     // ... your existing CartVC code ...

     @IBAction func btnProceedToCheckoutClick(_ sender: Any) {
         if validateFields() {
             let orderVC = self.storyboard?.instantiateViewController(withIdentifier: "OrderVC") as! OrderVC
             orderVC.orderData = storeScreenDataToOrderEntity()
             self.navigationController?.pushViewController(orderVC, animated: true)
         }
     }

     func storeScreenDataToOrderEntity() -> [String: Any]? {
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
         let context = appDelegate.persistentContainer.viewContext

         let newOrder = OrderEntity(context: context)
         newOrder.address = txtAddress.text
         newOrder.phone = Int32(txtPhone.text ?? "0") ?? 0
         newOrder.mail = txtEmail.text
         newOrder.name = txtName.text
         newOrder.orderedID = "12nj2324"
         newOrder.size = "M"
         newOrder.total = Int32(LblNewTotalAmount.text?.replacingOccurrences(of: "$", with: "") ?? "0") ?? 0

         var transactionString = ""
         for item in transactions {
             let itemString = "\(item.name ?? ""),\(item.price),\(item.imageName ?? ""),\(item.count),\(item.addedItem),\(item.categoryID);"
             transactionString += itemString
         }
         newOrder.transactionItemsString = transactionString

         do {
             try context.save()
             print("Screen data saved to OrderEntity successfully")
             return retrieveOrderData(from: newOrder)
         } catch {
             print("Failed to save screen data: \(error)")
             return nil
         }
     }

     func retrieveOrderData(from order: OrderEntity) -> [String: Any]? {
         guard let transactionString = order.transactionItemsString else { return nil }

         let transactionItems = transactionString.components(separatedBy: ";")
         var transactions: [[String: Any]] = []

         for itemString in transactionItems {
             if !itemString.isEmpty {
                 let itemComponents = itemString.components(separatedBy: ",")
                 if itemComponents.count == 6 {
                     let transaction: [String: Any] = [
                         "name": itemComponents[0],
                         "price": Double(itemComponents[1]) ?? 0.0,
                         "imageName": itemComponents[2],
                         "count": Int32(itemComponents[3]) ?? 0,
                         "addedItem": Int32(itemComponents[4]) ?? 0,
                         "categoryID": Int32(itemComponents[5]) ?? 0
                     ]
                     transactions.append(transaction)
                 }
             }
         }

         let orderData: [String: Any] = [
             "name": order.name ?? "",
             "mail": order.mail ?? "",
             "phone": order.phone,
             "address": order.address ?? "",
             "orderedID": order.orderedID ?? "",
             "size": order.size ?? "",
             "total": order.total,
             "transactions": transactions
         ]

         return orderData
     }
 }

 // OrderVC (Where you display the order data)
 class OrderVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
     @IBOutlet weak var orderTableView: UITableView!

     var orderData: [String: Any]?
     var transactions: [[String: Any]] = []

     override func viewDidLoad() {
         super.viewDidLoad()
         orderTableView.dataSource = self
         orderTableView.delegate = self
         orderTableView.register(UINib(nibName: "OrderItemCell", bundle: nil), forCellReuseIdentifier: "OrderItemCell")

         if let order = orderData {
             transactions = order["transactions"] as? [[String: Any]] ?? []
             orderTableView.reloadData()
         }
     }

     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return transactions.count
     }

     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "OrderItemCell", for: indexPath) as! OrderItemCell
         let transaction = transactions[indexPath.row]

         cell.nameLabel.text = transaction["name"] as? String
         cell.priceLabel.text = "\(transaction["price"] as? Double ?? 0.0)"
         cell.countLabel.text = "\(transaction["count"] as? Int32 ?? 0)"

         return cell
     }
 }
 */
