//
//  ShoppingAppTests.swift
//  ShoppingAppTests
//
//  Created by Hemaxi S on 26/03/25.
//

import Testing
@testable import ShoppingApp

struct ShoppingAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
