//
//  File.swift
//  ToDoApp
//
//  Created by Hemaxi S on 06/05/25.
//

import Foundation
/*
 
 func tableView(_ tableView: UITableView,
                trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
     
     let inProgressAction = UIContextualAction(style: .normal, title: "In Progress") { _, _, completionHandler in
         let taskID = self.tasks[indexPath.row].id
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
         let context = appDelegate.persistentContainer.viewContext
         
         let fetchReq: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
         fetchReq.predicate = NSPredicate(format: "taskID == %@", taskID! as CVarArg)
         do {
             let results = try context.fetch(fetchReq)
             if let taskToUpdate = results.first {
                 taskToUpdate.status = "In Progress"
                 try context.save()
                 print("Status updated to In Progress")
                 self.fetchTasks()
             }
         } catch {
             print("Error updating status: \(error)")
         }
         completionHandler(true)
     }
     inProgressAction.backgroundColor = .blue

     let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, completionHandler in
         let taskID = self.tasks[indexPath.row].id
         guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
         let context = appDelegate.persistentContainer.viewContext

         let deleteReq: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
         deleteReq.predicate = NSPredicate(format: "taskID == %@", taskID! as CVarArg)

         let alert = UIAlertController(title: "Delete", message: "Do you want to delete this task?", preferredStyle: .alert)
         alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
             completionHandler(false)
         }))
         alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
             do {
                 let results = try context.fetch(deleteReq)
                 if let taskToDelete = results.first {
                     context.delete(taskToDelete)
                     try context.save()
                     self.fetchTasks()
                     print("Task deleted successfully")
                 }
                 completionHandler(true)
             } catch {
                 print("Failed to delete task: \(error)")
                 completionHandler(false)
             }
         }))
         self.present(alert, animated: true, completion: nil)
     }

     let config = UISwipeActionsConfiguration(actions: [deleteAction, inProgressAction])
     config.performsFirstActionWithFullSwipe = false
     return config
 }

 -------------------------------------------------------------
 struct TaskSection {
     let title: String
     var tasks: [(id: String?, title: String, startDate: Date, endDate: Date, status: String, desc: String, assignTo: String)]
 }
 var taskSections: [TaskSection] = []
 func fetchTasks() {
     lblNoTask.isHidden = true
     guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
     let context = appDelegate.persistentContainer.viewContext

     taskSections.removeAll()

     let tasksFetch: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
     do {
         let taskResults = try context.fetch(tasksFetch)

         var openTasks: [TaskSection.Element] = []
         var inProgressTasks: [TaskSection.Element] = []
         var doneTasks: [TaskSection.Element] = []

         for taskk in taskResults {
             let id = taskk.taskID ?? "0"
             let title = taskk.title ?? "no title"
             let desc = taskk.desc ?? "no desc"
             let endDate = taskk.endDate ?? Date()
             let startDate = taskk.startDate ?? Date()
             let status = taskk.status ?? "no status"

             var arrAssignedUsers: [String] = []
             if let userSet = taskk.assigneUsers as? Set<AssignedUsers> {
                 arrAssignedUsers = Array(Set(userSet.compactMap { $0.name }))
             }

             let assignedUsersString = arrAssignedUsers.joined(separator: ",")
             let taskTuple = (id: id, title: title, startDate: startDate, endDate: endDate, status: status, desc: desc, assignTo: assignedUsersString)

             switch status.lowercased() {
             case "open":
                 openTasks.append(taskTuple)
             case "in progress":
                 inProgressTasks.append(taskTuple)
             case "done":
                 doneTasks.append(taskTuple)
             default:
                 print("Unknown status:", status)
             }
         }

         // Only add sections that have data
         if !openTasks.isEmpty {
             taskSections.append(TaskSection(title: "Open", tasks: openTasks.sorted(by: { $0.startDate > $1.startDate })))
         }
         if !inProgressTasks.isEmpty {
             taskSections.append(TaskSection(title: "In Progress", tasks: inProgressTasks.sorted(by: { $0.startDate > $1.startDate })))
         }
         if !doneTasks.isEmpty {
             taskSections.append(TaskSection(title: "Done", tasks: doneTasks.sorted(by: { $0.startDate > $1.startDate })))
         }

         DispatchQueue.main.async {
             self.tblTasks.reloadData()
         }
     } catch {
         print("Error in fetching tasks-----", error)
     }
 }
 func numberOfSections(in tableView: UITableView) -> Int {
     return taskSections.count
 }

 func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     return taskSections[section].tasks.count
 }

 func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
     return taskSections[section].title
 }

 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell", for: indexPath) as! TaskCell
     let newTask = taskSections[indexPath.section].tasks[indexPath.row]
     cell.lblTitle.text = newTask.title
     cell.lblDesc.text = newTask.desc
     cell.lblStatus.text = newTask.status

     let formatter = DateFormatter()
     formatter.dateFormat = "MMM dd, yyyy"
     cell.lblDate.text = formatter.string(from: newTask.startDate)

     return cell
 }
 
 
 
 */
