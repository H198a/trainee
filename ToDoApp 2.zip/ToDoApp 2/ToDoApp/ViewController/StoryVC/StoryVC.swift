//
//  StoryVC.swift
//  ToDoApp
//
//  Created by admin on 12/05/25.
//

import UIKit

class StoryVC: UIViewController {
    //MARK: Outlet and Variable Declaration
    @IBOutlet weak var cvStory: UICollectionView!
    var arrImages: [StoryData] = [StoryData(name: "John", image: UIImage(named: "Img8"),storyImages:[
        UIImage(named: "Img1")!,
        UIImage(named: "Img7")!
    ]),
        StoryData(name: "Lily", image: UIImage(named: "Img1"),storyImages:[
            UIImage(named: "Img4")!,
            UIImage(named: "Img5")!]),
        StoryData(name: "Allena", image: UIImage(named: "Img2"),storyImages:[
            UIImage(named: "Img3")!,
            UIImage(named: "Img6")!]),
        StoryData(name: "Bob", image: UIImage(named: "Img3"),storyImages:[
            UIImage(named: "Img5")!,
            UIImage(named: "Img2")!]),
        StoryData(name: "Riya", image: UIImage(named: "Img4"),storyImages:[
            UIImage(named: "Img7")!,
            UIImage(named: "Img8")!]),
        StoryData(name: "Rousy", image: UIImage(named: "Img5"),storyImages:[
            UIImage(named: "Img4")!,
            UIImage(named: "Img6")!]),
        StoryData(name: "Kenny", image: UIImage(named: "Img6"),storyImages:[
            UIImage(named: "Img3")!,
            UIImage(named: "Img4")!]),
        StoryData(name: "Justin", image: UIImage(named: "Img7"),storyImages:[
            UIImage(named: "Img1")!,
            UIImage(named: "Img2")!])
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
}
//MARK: Setup
extension StoryVC{
    func setUP(){
        let nibName = UINib(nibName: "StoryCell", bundle: nil)
        cvStory.register(nibName, forCellWithReuseIdentifier: "StoryCell")
    }
}
//MARK: UICollectionViewDataSource, UICollectionViewDelegate,UICollectionViewDelegateFlowLayout
extension StoryVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "StoryCell", for: indexPath) as! StoryCell
        let userData = arrImages[indexPath.item]
        cell.lblUserName.text = userData.name
        cell.ImgUser.image = userData.image
        cell.configureBorder(isSeen: userData.isSeen)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var selectedUser = arrImages[indexPath.item]
        selectedUser.isSeen = true
        collectionView.reloadItems(at: [indexPath])
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            let storyViewVC = self.storyboard?.instantiateViewController(withIdentifier: "StoryViewVC") as! StoryViewVC
            storyViewVC.userName = selectedUser.name
            storyViewVC.profileImage = selectedUser.image
            storyViewVC.storyImages = selectedUser.storyImages
            self.navigationController?.pushViewController(storyViewVC, animated: true)
        }
        
    }
}
