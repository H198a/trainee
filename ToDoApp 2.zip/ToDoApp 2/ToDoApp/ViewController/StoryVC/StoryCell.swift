//
//  StoryCell.swift
//  ToDoApp
//
//  Created by admin on 12/05/25.
//

import UIKit

class StoryCell: UICollectionViewCell {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var ImgUser: UIImageView!
    private var ringLayer: CAShapeLayer?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    func configureBorder(isSeen: Bool) {
            // Remove existing ring if any
            ringLayer?.removeFromSuperlayer()

            // Create circular path
            let radius = ImgUser.frame.width / 2 + 4
            let center = CGPoint(x: ImgUser.center.x, y: ImgUser.center.y)
            let circularPath = UIBezierPath(arcCenter: center, radius: radius, startAngle: -.pi / 2, endAngle: 1.5 * .pi, clockwise: true)

            let shapeLayer = CAShapeLayer()
            shapeLayer.path = circularPath.cgPath
            shapeLayer.strokeColor = (isSeen ? UIColor.lightGray : UIColor.systemPink).cgColor
            shapeLayer.fillColor = UIColor.clear.cgColor
            shapeLayer.lineWidth = 3
            shapeLayer.lineDashPattern = isSeen ? nil : [2, 3] // Dotted for unseen, solid for seen
            shapeLayer.frame = contentView.bounds
            shapeLayer.lineCap = .round

            // Animate the stroke
            if !isSeen {
                let animation = CABasicAnimation(keyPath: "strokeEnd")
                animation.fromValue = 0
                animation.toValue = 1
                animation.duration = 0.6
                shapeLayer.add(animation, forKey: "ringAnimation")
            }

            contentView.layer.addSublayer(shapeLayer)
            ringLayer = shapeLayer
        }

        override func prepareForReuse() {
            super.prepareForReuse()
            ringLayer?.removeFromSuperlayer()
        }
}
