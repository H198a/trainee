//
//  AddTaskCell.swift
//  ToDoApp
//
//  Created by Hemaxi S on 06/05/25.
//

import UIKit

class AddTaskCell: UICollectionViewCell {
//MARK: Outlet and Variable Declartion
    @IBOutlet weak var lblUser: UILabel!
    @IBOutlet weak var btnClose: UIButton!
    @IBOutlet weak var tagView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
