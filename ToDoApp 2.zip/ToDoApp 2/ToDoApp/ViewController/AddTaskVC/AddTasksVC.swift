//
//  AddTasksVC.swift
//  ToDoApp
//
//  Created by Hemaxi S on 06/05/25.
//

import UIKit
import CoreData
import IQKeyboardManager

class AddTasksVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var titleView: UIView!
    @IBOutlet weak var descView: UIView!
    @IBOutlet weak var startDateView: UIView!
    @IBOutlet weak var endDateView: UIView!
    @IBOutlet weak var assignView: UIView!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtDesc: UITextView!
    @IBOutlet weak var startDate: UIDatePicker!
    @IBOutlet weak var endDate: UIDatePicker!
    @IBOutlet weak var txtAssign: UITextField!
    @IBOutlet weak var cvAssignedUsers: UICollectionView!
    @IBOutlet weak var btnAddAndUpdate: UIButton!
    
    var users: [AssignedUsers] = []
    var tasks: TaskEntity?
    var isFormEdit = false
    
    var titlee: String?
    var desc: String?
    var ussers: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        cvAssignedUsers.reloadData()
    }
    @objc func deleteUser(_ sender: UIButton) {
        let index = sender.tag
        users.remove(at: index)
        cvAssignedUsers.reloadData()
    }
    @objc func didPressOnDontBtn(){
        txtAssign.resignFirstResponder()//removes keyboard on done button click
        addUserFromTextField()
    }
}
//MARK: Setup UI
extension AddTasksVC{
    func setUP(){
    
        let nibName = UINib(nibName: "AddTaskCell", bundle: nil)
        cvAssignedUsers.register(nibName, forCellWithReuseIdentifier: "AddTaskCell")
        
        if isFormEdit {
            if let task = tasks {
                txtTitle.text = task.title
                txtDesc.text = task.desc
                startDate.date = task.startDate ?? Date()
                endDate.date = task.endDate ?? Date()
                
                // Load assigned users
                if let userSet = task.assigneUsers as? Set<AssignedUsers> {
                    users = Array(userSet)
                }
            }
            btnAddAndUpdate.setTitle("Update", for: .normal)
        } else{
            txtDesc.text = "Enter Description"
            txtDesc.textColor = UIColor.lightGray
        }

        
        titleView.layer.shadowColor = UIColor.black.cgColor
        titleView.layer.shadowOpacity = 0.4
        titleView.layer.shadowOffset = CGSize(width: 0, height: 0)
        titleView.layer.shadowRadius = 4
        titleView.layer.masksToBounds = false  // Ensures shadow is visible
        
        descView.layer.shadowColor = UIColor.black.cgColor
        descView.layer.shadowOpacity = 0.4
        descView.layer.shadowOffset = CGSize(width: 0, height: 0)
        descView.layer.shadowRadius = 4
        descView.layer.masksToBounds = false  // Ensures shadow is visible
        
        startDateView.layer.shadowColor = UIColor.black.cgColor
        startDateView.layer.shadowOpacity = 0.4
        startDateView.layer.shadowOffset = CGSize(width: 0, height: 0)
        startDateView.layer.shadowRadius = 4
        startDateView.layer.masksToBounds = false  // Ensures shadow is visible
        
        endDateView.layer.shadowColor = UIColor.black.cgColor
        endDateView.layer.shadowOpacity = 0.4
        endDateView.layer.shadowOffset = CGSize(width: 0, height: 0)
        endDateView.layer.shadowRadius = 4
        endDateView.layer.masksToBounds = false  // Ensures shadow is visible
        
        assignView.layer.shadowColor = UIColor.black.cgColor
        assignView.layer.shadowOpacity = 0.4
        assignView.layer.shadowOffset = CGSize(width: 0, height: 0)
        assignView.layer.shadowRadius = 4
        assignView.layer.masksToBounds = false  // Ensures shadow is visible
        
       
        txtDesc.delegate = self
        
        txtAssign.delegate = self
        
        startDate.minimumDate = Date()
        endDate.minimumDate = Date()
    }
}
//MARK: Custom Functions
extension AddTasksVC{
    func validateFields() -> Bool {
        var isValid = true
        if let number = txtTitle.text, number.isEmpty {
            showAlert(message: "Please enter your title")
            isValid = false
        }
        if let number = txtDesc.text, number.isEmpty {
            showAlert(message: "Please enter Description")
            isValid = false
        }
        return isValid
    }
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    func addUserFromTextField() {
        guard let name = txtAssign.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { return }

           guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
           let context = appDelegate.persistentContainer.viewContext

           let newUser = AssignedUsers(context: context)
           newUser.name = name
           users.append(newUser)

           txtAssign.text = ""
           cvAssignedUsers.reloadData()
    }
    func fetchUsersFromCoreData() -> [String]{
        guard let appDeletegate = UIApplication.shared.delegate as? AppDelegate else{return []}
        let context = appDeletegate.persistentContainer.viewContext
        let request: NSFetchRequest<AssignedUsers> = AssignedUsers.fetchRequest()
        do{
            let result = try context.fetch(request)
            DispatchQueue.main.async{
                self.cvAssignedUsers.reloadData()
            }
            print("data saved succssfully of assignedusers")
            return result.compactMap { $0.name }
        } catch{
            print("error in fetching data",error)
            return []
        }
    }
    func scheduleNotification(eventName: String, eventDescription: String, eventDate: Date, notificationID: String) {
        let notificationContent = UNMutableNotificationContent()
        notificationContent.title = eventName
        notificationContent.body = eventDescription
        notificationContent.sound = .default
        
        let notificationDate = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: eventDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: notificationDate, repeats: false)
        
        let request = UNNotificationRequest(identifier: notificationID, content: notificationContent, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                self.showAlert(message: "Failed to schedule notification: \(error.localizedDescription)")
            }
        }
    }
}
//MARK: UITextViewDelegate
extension AddTasksVC: UITextViewDelegate{
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == "" {
            textView.text = "Enter Description"
            textView.textColor = UIColor.lightGray
        }
    }
}
//MARK: UICollectionViewDataSource, UICollectionViewDelegate
extension AddTasksVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("uaers--------",users.count)
        return users.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddTaskCell", for: indexPath) as! AddTaskCell
        cell.lblUser.text = users[indexPath.item].name
        cell.btnClose.tag = indexPath.item
        cell.btnClose.addTarget(self, action: #selector(deleteUser), for: .touchUpInside)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: 30)
    }
}
//MARK: UITextFieldDelegate
extension AddTasksVC: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        addUserFromTextField()
        view.endEditing(true)
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.addDoneOnKeyboard(withTarget: self, action: #selector(didPressOnDontBtn))
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.addDoneOnKeyboard(withTarget: self, action: #selector(didPressOnDontBtn))
    }
}
//MARK: Click Events
extension AddTasksVC{
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func onClickAddTask(_ sender: UIButton) {
        if validateFields(){
           
            if txtDesc.textColor == .lightGray{
                showAlert(message: "Please enter description")
            }
            guard users.count >= 1 else{
                showAlert(message: "please assign users")
                return
            }
            guard let titlee = txtTitle.text, !titlee.isEmpty else{
                print("error in title")
                return
            }
            guard let desc = txtDesc.text, !desc.isEmpty else{
                print("error in desc")
                return
            }
            let assign = users.count
            let id = "\(Int.random(in: 1000...9999))"
            let startDate = startDate.date
            let endDate = endDate.date
            
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
                return
            }
            let context = appDelegate.persistentContainer.viewContext
            let newTask = ToDoApp.TaskEntity(context: context)
            if isFormEdit{
                guard let taskToUpdate = tasks else { return }
                   taskToUpdate.title = txtTitle.text
                   taskToUpdate.desc = txtDesc.text
                   taskToUpdate.endDate = endDate
                   taskToUpdate.startDate = startDate
                   taskToUpdate.assignTo = "\(users.count)"
                   taskToUpdate.status = "Open"
                   
                 

                   do {
                       try context.save()
                       navigationController?.popToRootViewController(animated: true)
                       showAlert(message: "Task updated successfully")
                       print("Task updated successfully:", taskToUpdate)
                       scheduleNotification(eventName: taskToUpdate.title ?? "", eventDescription: taskToUpdate.desc ?? "", eventDate: taskToUpdate.endDate ?? Date(), notificationID: taskToUpdate.taskID ?? "")
//                       users = []
                       cvAssignedUsers.reloadData()
                   } catch {
                       print("Failed to update task:", error)
                       showAlert(message: "Failed to update task.")
                   }
            } else{
                newTask.title = titlee
                newTask.desc = desc
                newTask.assignTo = "\(assign)"
                newTask.startDate = startDate
                newTask.endDate = endDate
                newTask.taskID = id
                newTask.status = "Open"
                
                //Link assigned users to this taskEntity
                for user in users {
                    user.taskEntity = newTask
                }
                do{
                    try context.save()
                    self.dismiss(animated: true)
                    navigationController?.popToRootViewController(animated: true)
                    showAlert(message: "Task added successfully")
                    print("task added successfully",newTask)
//                    users = []
                    scheduleNotification(eventName: newTask.title!, eventDescription: newTask.desc!, eventDate: newTask.endDate!, notificationID: newTask.taskID!)
                    cvAssignedUsers.reloadData()
                } catch{
                    print("failed to add task:----",error)
                }
            }
          
        }
    }
}
