//
//  DetailCell.swift
//  ToDoApp
//
//  Created by Hemaxi S on 07/05/25.
//

import UIKit

class DetailCell: UICollectionViewCell {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var mainView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
