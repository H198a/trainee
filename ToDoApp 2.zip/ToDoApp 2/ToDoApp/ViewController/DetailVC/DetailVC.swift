//
//  DetailVC.swift
//  ToDoApp
//
//  Created by Hemaxi S on 07/05/25.
//

import UIKit
import CoreData

class DetailVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var cvAssignedUsers: UICollectionView!    
    @IBOutlet weak var lblDesc: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var lblID: UILabel!
 
    var tasks: TaskEntity?
    
    var titleText: String?
    var descText: String?
    var endDate: Date?
    var startDate: Date?
    var status: String?
    var ID: String?
    var assignedUsers: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
    }
}
//MARK: SetUp UI
extension DetailVC{
    func setUP(){
        let nibName = UINib(nibName: "DetailCell", bundle: nil)
        cvAssignedUsers.register(nibName, forCellWithReuseIdentifier: "DetailCell")
        cvAssignedUsers.reloadData()
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy"
        lblEndDate.text = formatter.string(from: endDate!)
        lblStartDate.text = formatter.string(from: startDate!)
        lblTitle.text = titleText
        lblDesc.text = descText
        lblID.text = ID
        lblStatus.text = status
    }
}
//MARK: Custom Functions
extension DetailVC{
    func deleteData(){
        lblID.text = ""
        lblDesc.text = ""
        lblTitle.text = ""
        lblStatus.text = ""
        lblStartDate.text = ""
        lblEndDate.text = ""
        assignedUsers = [""]
    }
}
//MARK: UICollectionViewDataSource, UICollectionViewDelegate
extension DetailVC: UICollectionViewDataSource, UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("assigned users count--------",assignedUsers.count)
        return assignedUsers.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DetailCell", for: indexPath) as! DetailCell
        cell.lblName.text = assignedUsers[indexPath.row]
        return cell
    }
}
//MARK: Click Events
extension DetailVC{
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    @IBAction func onClickUpdate(_ sender: Any) {
        let updateVC = storyboard?.instantiateViewController(withIdentifier: "AddTasksVC") as! AddTasksVC
        updateVC.isFormEdit = true
        updateVC.tasks = tasks
        updateVC.titlee = titleText
        updateVC.desc = descText
        updateVC.ussers = assignedUsers
        navigationController?.pushViewController(updateVC, animated: true)
    }
    @IBAction func onClickDone(_ sender: Any) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{return}
        let context = appDelegate.persistentContainer.viewContext
        let taskID = ID
        
        let fetchReq: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
        fetchReq.predicate = NSPredicate(format: "taskID == %@", taskID! as CVarArg)
        do{
            let results = try context.fetch(fetchReq)
            if let taskToUpdate = results.first {
                taskToUpdate.status = "Done"
                lblStatus.text = "Done"
                try context.save()
                print("Status updated to Done")
            }
        } catch{
            print("Error updating status: \(error)")
        }
    }
    
    @IBAction func onClickInProgress(_ sender: Any) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{return}
        let context = appDelegate.persistentContainer.viewContext
        let taskID = ID
        
        let fetchReq: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
        fetchReq.predicate = NSPredicate(format: "taskID == %@", taskID! as CVarArg)
        do{
            let results = try context.fetch(fetchReq)
            if let taskToUpdate = results.first {
                taskToUpdate.status = "In Progress"
                lblStatus.text = "In Progress"
                try context.save()
                print("Status updated to In Progress")
            }
        } catch{
            print("Error updating status: \(error)")
        }
    }

    @IBAction func onClickDelete(_ sender: Any) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        let taskID = ID
        
        let deleteReq: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
        deleteReq.predicate = NSPredicate(format: "taskID == %@", taskID! as CVarArg)
        
        let alert = UIAlertController(title: "Delete", message: "Do you want to delete this task?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
            do {
                let results = try context.fetch(deleteReq)
                if let taskToDelete = results.first {
                    context.delete(taskToDelete)
                    try context.save()
                    self.deleteData()
                    self.cvAssignedUsers.reloadData()
                    print("task deleted successfully")
                }
            } catch {
                print("failed to delete task: \(error)")
            }
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
}

