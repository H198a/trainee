//
//  ReelsVC.swift
//  ToDoApp
//
//  Created by admin on 11/05/25.
//

import UIKit

class ReelsVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var tblReels: UITableView!
    var currentlyPlayingCell: ReelsCell?
    var arrVideos: [String] = [
            "https://videos.pexels.com/video-files/3468587/3468587-sd_360_640_30fps.mp4",
            "https://videos.pexels.com/video-files/3403532/3403532-sd_506_960_25fps.mp4",
            "https://videos.pexels.com/video-files/3468587/3468587-sd_360_640_30fps.mp4",
            "https://videos.pexels.com/video-files/3403532/3403532-sd_506_960_25fps.mp4",
            "https://videos.pexels.com/video-files/3468587/3468587-sd_360_640_30fps.mp4",
            "https://videos.pexels.com/video-files/3403532/3403532-sd_506_960_25fps.mp4",
            "https://videos.pexels.com/video-files/3468587/3468587-sd_360_640_30fps.mp4",
            "https://videos.pexels.com/video-files/3403532/3403532-sd_506_960_25fps.mp4",
            "https://videos.pexels.com/video-files/3468587/3468587-sd_360_640_30fps.mp4",
            "https://videos.pexels.com/video-files/3403532/3403532-sd_506_960_25fps.mp4"
        ]
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        playVisibleVideo()
    }
}
extension ReelsVC {
    func setUP() {
        tblReels.delegate = self
        tblReels.dataSource = self
        tblReels.register(UINib(nibName: "ReelsCell", bundle: nil), forCellReuseIdentifier: "ReelsCell")
        tblReels.separatorStyle = .none
        tblReels.isPagingEnabled = true
    }
      
        func playVisibleVideo() {
            let visibleRect = CGRect(origin: tblReels.contentOffset, size: tblReels.bounds.size)
            let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)

            guard let indexPath = tblReels.indexPathForRow(at: visiblePoint),
                  let cell = tblReels.cellForRow(at: indexPath) as? ReelsCell else { return }

            // Stop previously playing cell
            if currentlyPlayingCell != cell {
                currentlyPlayingCell?.pauseVideo()
                currentlyPlayingCell = cell
                cell.playVideo()
            }

//            SwiftLoader.hide()
        }
}
//MARK: UITableViewDelegate, UITableViewDataSource
extension ReelsVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrVideos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReelsCell", for: indexPath) as! ReelsCell
        cell.configure(with: arrVideos[indexPath.row])
        return cell
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        playVisibleVideo()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tblReels.frame.height
    }
    
}
