//
//  ReelsCell.swift
//  ToDoApp
//
//  Created by admin on 11/05/25.
//

import UIKit
import AVFoundation

class ReelsCell: UITableViewCell {
    //MARK: Outlet and Variabke Declaration
    @IBOutlet weak var mainView: UIView!
    
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var videoURL: URL?
    private var playerLooperObserver: NSObjectProtocol?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        pauseVideo()
    }
    func configure(with urlStr: String) {
        guard let url = URL(string: urlStr), url != videoURL else { return }
        
        videoURL = url
        
        // Clean up existing player before creating new one
        pauseVideo()
        
        player = AVPlayer(url: url)
        player?.isMuted = true
        
        // Add looping behavior
        addLoopObserver()
        
        if playerLayer == nil {
            playerLayer = AVPlayerLayer(player: player)
            playerLayer?.videoGravity = .resizeAspectFill
            playerLayer?.frame = mainView.bounds
            mainView.layer.insertSublayer(playerLayer!, at: 0) // Use mainView, not contentView
        } else {
            playerLayer?.player = player
        }
    }
    
    func playVideo() {
        player?.play()
    }
    
    func pauseVideo() {
        player?.pause()
        player?.replaceCurrentItem(with: nil)
        playerLayer?.removeFromSuperlayer()
        player = nil
        playerLayer = nil
        
        // Remove observer
        if let observer = playerLooperObserver {
            NotificationCenter.default.removeObserver(observer)
            playerLooperObserver = nil
        }
        NotificationCenter.default.removeObserver(self, name: .AVPlayerItemNewAccessLogEntry, object: nil)
    }
    
    
    private func addLoopObserver() {
        guard let player = player else { return }
        
        playerLooperObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player.currentItem,
            queue: .main
        ) { [weak self] _ in
            self?.player?.seek(to: .zero)
            self?.player?.play()
        }
    }
}
