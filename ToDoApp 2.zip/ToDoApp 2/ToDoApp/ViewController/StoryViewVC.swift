//
//  StoryViewVC.swift
//  ToDoApp
//
//  Created by admin on 12/05/25.
//

import UIKit

class StoryViewVC: UIViewController {
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var storyProgressStack: UIStackView!
    @IBOutlet weak var storyImage: UIImageView!
    private var isAnimating = false

    var userName: String = ""
    var profileImage: UIImage?
    var storyImages: [UIImage] = []
    
    private var progressBars: [UIProgressView] = []
    private var currentIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUserInfo()
        setupProgressBars()
        setupGestures()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.startStory()
        }
    }
    @objc func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        if gesture.direction == .right {
            navigationController?.popViewController(animated: true)
        }
    }
    @objc func handleLongPress(_ gesture: UILongPressGestureRecognizer) {
        guard currentIndex < progressBars.count else { return }
        let currentProgress = progressBars[currentIndex]

        switch gesture.state {
        case .began:
            currentProgress.layer.removeAllAnimations()
        case .ended, .cancelled, .failed:
            guard !isAnimating else { return } // 🔐 Avoid duplicate animation
            let remaining = 1.0 - currentProgress.progress
            isAnimating = true
            UIView.animate(withDuration: Double(remaining) * 5.0, delay: 0, options: .curveLinear, animations: {
                currentProgress.setProgress(1.0, animated: true)
            }) { [weak self] finished in
                guard let self = self else { return }
                self.isAnimating = false
                if finished {
                    self.nextStory()
                }
            }
        default:
            break
        }
    }


}
//MARK: All Functions
extension StoryViewVC{
    func setupUserInfo() {
        lblName.text = userName
        imgUser.image = profileImage
    }
    func setupProgressBars() {
        storyProgressStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        progressBars.removeAll()

        for _ in storyImages {
            let progress = UIProgressView(progressViewStyle: .default)
            progress.progressTintColor = .white
            progress.trackTintColor = UIColor.black.withAlphaComponent(0.3)
            progress.progress = 0.0001
            progress.translatesAutoresizingMaskIntoConstraints = false
            progress.heightAnchor.constraint(equalToConstant: 2).isActive = true

            storyProgressStack.addArrangedSubview(progress)
            progressBars.append(progress)
        }
    }
    func startStory() {
        guard !storyImages.isEmpty else { print("something wrong here"); return }
        currentIndex = 0
        showImage(at: currentIndex)
        animateProgressBar(at: currentIndex)
    }


    func showImage(at index: Int) {
        storyImage.image = storyImages[index]
    }


    func animateProgressBar(at index: Int) {
        guard index < progressBars.count else { return }

        let currentProgress = progressBars[index]
        isAnimating = true
        currentProgress.setProgress(0, animated: false)

        UIView.animate(withDuration: 5.0, delay: 0, options: .curveLinear, animations: {
            currentProgress.setProgress(1.0, animated: true)
        }) { [weak self] finished in
            guard let self = self else { return }
            self.isAnimating = false
            if finished {
                self.nextStory()
            }
        }
    }


    func nextStory() {
        currentIndex += 1
        if currentIndex < storyImages.count {
            showImage(at: currentIndex)
            animateProgressBar(at: currentIndex)
        } else {
            print("Something is wring here")
            // Wait a bit before popping to show the last image properly
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }

    func setupGestures() {
        // Swipe Right to Dismiss
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeRight.direction = .right
        view.addGestureRecognizer(swipeRight)

        // Long Press to Pause
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
        view.addGestureRecognizer(longPress)
    }

}
