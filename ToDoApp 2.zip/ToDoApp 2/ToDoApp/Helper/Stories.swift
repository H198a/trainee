//
//  Stories.swift
//  ToDoApp
//
//  Created by admin on 12/05/25.
//

import Foundation
import UIKit
struct StoryData{
    let name: String
    let image: UIImage?
    let storyImages: [UIImage]
    var isSeen: Bool = false
}
