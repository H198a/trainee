//
//  Tasks.swift
//  ToDoApp
//
//  Created by Hemaxi S on 07/05/25.
//

import Foundation
struct TaskSection{
//    type alias allows us to create our type from existing types.Instead of repeatedly using 'String'(data type), we can create a type alias.
    typealias Element = (id: String?, title: String?, startDate: Date?, endDate: Date?, status: String?, desc: String?, assignTo: String?)
        
        let Tasktitle: String
        var tasks: [Element]//in task we can directly get all the parameters like id,titile..assignTo
}
