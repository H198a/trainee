//
//  AssignedUsers+CoreDataClass.swift
//  
//
//  Created by Hemaxi S on 06/05/25.
//
//

import Foundation
import CoreData

@objc(AssignedUsers)
public class AssignedUsers: NSManagedObject {

}
