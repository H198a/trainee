//
//  TabBar.swift
//  KhataBook
//
//  Created by Hemaxi S on 17/03/25.
//
import Foundation
import UIKit

class CustomTabBarController: UITabBarController, UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the delegate to self to track tab bar selection
        self.delegate = self
        
        // Optionally, add default shadow for the tab bar
        // Set the shadow color, opacity, and offset
        if let tabBar = self.tabBarController?.tabBar {
            tabBar.layer.shadowColor = UIColor.white.cgColor  // Set shadow color
            tabBar.layer.shadowOpacity = 2.5  // Set shadow opacity (0.0 to 1.0)
            tabBar.layer.shadowOffset = CGSize(width: 0, height: -2)  // Set shadow offset (horizontal, vertical)
            tabBar.layer.shadowRadius = 4  // Set shadow blur radius
        }
    }
}
    
/*
 // In your ViewController or wherever you have access to the tabBar
 override func viewDidLoad() {
     super.viewDidLoad()

     // Set the shadow color, opacity, and offset
     if let tabBar = self.tabBarController?.tabBar {
         tabBar.layer.shadowColor = UIColor.black.cgColor  // Set shadow color
         tabBar.layer.shadowOpacity = 0.5  // Set shadow opacity (0.0 to 1.0)
         tabBar.layer.shadowOffset = CGSize(width: 0, height: -2)  // Set shadow offset (horizontal, vertical)
         tabBar.layer.shadowRadius = 4  // Set shadow blur radius
     }
 }

 */
