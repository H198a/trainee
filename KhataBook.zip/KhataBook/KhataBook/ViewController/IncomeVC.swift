//
//  IncomeVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 07/03/25.
//

import UIKit
import CoreData
import iOSDropDown

class IncomeVC: UIViewController {

    @IBOutlet weak var lblCurrency: UILabel!
    @IBOutlet weak var InsertView: UIView!
    @IBOutlet weak var btnIcomeView: UIView!
    @IBOutlet weak var btnexpenseView: UIView!
    @IBOutlet weak var TxtDescription: UITextField!
    @IBOutlet weak var TxtAmount: UITextField!
    
    var Income: Income?
    let dropdownMenu = DropDown()
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
  
    @IBAction func btnCloseClick(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

    @IBAction func btnIncomeClick(_ sender: Any) {
    }
    
    @IBAction func btnExpenseClick(_ sender: Any) {
        let incomeVC = self.storyboard?.instantiateViewController(withIdentifier: "ExpenseVC") as! ExpenseVC
        self.navigationController?.pushViewController(incomeVC , animated: true)
    }
    
    @IBAction func btnInsertClick(_ sender: Any) {
        if validateFields(){
            guard let title = TxtDescription.text, !title.isEmpty else {
                print("error in desc")
                return
            }
            guard let amountText = TxtAmount.text,!amountText.isEmpty else {
                print("error in amount")
                return
            }
            guard let currency = lblCurrency.text else{
                print("error in currency")
                return
            }//24-sat
            let date = Date.from(year: 2025, month: 03, day: 19)//thu
            let selectedImageName = getFirstLetterImage(from: title)
            let imageBase64 = convertImageToBase64(image: selectedImageName)
            
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let context = appDelegate.persistentContainer.viewContext
            
            let newIncome = KhataBook.Income(context: context)
            newIncome.title = title
            newIncome.date = date//Date()//date
            newIncome.amount = amountText // Positive for income
            newIncome.image = imageBase64
            newIncome.currency = currency
            newIncome.type = 1
            do {
                try context.save()
                self.dismiss(animated: true) // Close this view
                navigationController?.popViewController(animated: true)
                //show alert
                //navigate to homescreen
                print("template added successfully")
            } catch {
                print("Failed to save income: \(error)")
            }
        }
    }
}
//MARK: setUp UI
extension IncomeVC{

    func setUp(){
        // Create a new gradient layer
        TxtAmount.becomeFirstResponder()
//        TxtAmount.requireCursor = false
        self.TxtAmount.adjustsFontSizeToFitWidth = true
        self.TxtAmount.minimumFontSize = 20.0
        TxtAmount.backgroundColor = .clear
        TxtAmount.textColor = .white
        TxtAmount.keyboardType = .numberPad
        TxtDescription.backgroundColor = .clear
        TxtAmount.layer.borderColor = UIColor.clear.cgColor
        TxtDescription.layer.borderColor = UIColor.clear.cgColor
        TxtDescription.attributedPlaceholder = NSAttributedString(
            string: "Add Description",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )

    }
    func getFirstLetterImage(from text: String) -> UIImage {
        let firstLetter = String(text.prefix(1)).uppercased() // Get the first letter
        
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        label.text = firstLetter
        label.textAlignment = .center
        label.font = UIFont.boldSystemFont(ofSize: 60)
        label.textColor = .white
        label.backgroundColor = .gray
        label.layer.cornerRadius = 50
        //label.clipsToBounds = true
        
        // Convert label to UIImage
        UIGraphicsBeginImageContextWithOptions(label.bounds.size, false, 0)
        if let context = UIGraphicsGetCurrentContext() {
            label.layer.render(in: context)
        }
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return image ?? UIImage()
    }
    func convertImageToBase64(image: UIImage) -> String? {
        if let imageData = image.jpegData(compressionQuality: 1.0) {
            return imageData.base64EncodedString(options: .lineLength64Characters)
        }
        return nil
    }
    func validateFields() -> Bool {
        var isValid = true
        if let number = TxtAmount.text, number.isEmpty {
            showAlert(message: "Please enter your Amount")
            isValid = false
        }
        if let number = TxtDescription.text, number.isEmpty {
            showAlert(message: "Please enter Description")
            isValid = false
        }
        return isValid
    }
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }

}
//extension Date {
//
//    /// Create a date from specified parameters
//    ///
//    /// - Parameters:
//    ///   - year: The desired year
//    ///   - month: The desired month
//    ///   - day: The desired day
//    /// - Returns: A `Date` object
//    static func from(year: Int, month: Int, day: Int) -> Date? {
//        let calendar = Calendar(identifier: .gregorian)
//        var dateComponents = DateComponents()
//        dateComponents.year = year
//        dateComponents.month = month
//        dateComponents.day = day
//        return calendar.date(from: dateComponents) ?? nil
//    }
//}
