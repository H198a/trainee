//
//  TableViewCellHome.swift
//  KhataBook
//
//  Created by Hemaxi S on 07/03/25.
//

import UIKit

class TableViewCellHome: UITableViewCell {

    @IBOutlet weak var MainView: UIView!
    @IBOutlet weak var ColorView: UIView!
    @IBOutlet weak var ImgColoriew: UIView!
    @IBOutlet weak var LblAmonut: UILabel!
    @IBOutlet weak var amountView: UIView!
    @IBOutlet weak var LblDate: UILabel!
    @IBOutlet weak var LblHead: UILabel!
    @IBOutlet weak var colorImg: UIImageView!
    @IBOutlet weak var LblCurrency: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setUP()
    }
    func setUP(){
        MainView.layer.cornerRadius = 20
        MainView.layer.borderWidth = 1
        MainView.clipsToBounds = true
//        MainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner, .layerMinXMaxYCorner, .layerMaxXMaxYCorner]
//        ColorView.applyRoundedLeftCorners(parentView: MainView)
        
        amountView.layer.cornerRadius = 20
        amountView.layer.borderWidth = 0.5
        amountView.layer.borderColor = UIColor.lightGray.cgColor
        
        ImgColoriew.layer.masksToBounds = true
        ImgColoriew.layer.cornerRadius = ImgColoriew.frame.height / 2
        
        colorImg.layer.backgroundColor = UIColor.clear.cgColor
    }
}
