//
//  CategoryChartVCViewController.swift
//  KhataBook
//
//  Created by Hemaxi S on 25/03/25.
//

import UIKit
import DropDown
import Charts
import CoreData
import Foundation

class CategoryChartVCViewController: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var txtDaySelection: UITextField!
    @IBOutlet weak var txtChartSelection: UITextField!
    @IBOutlet weak var BtnChartSelection: UIButton!
    @IBOutlet weak var BtnDaySelection: UIButton!
    @IBOutlet weak var dayView: UIView!
    @IBOutlet weak var chartView: UIView!
    @IBOutlet weak var mainChartView: BarChartView!
    
    
    let dayDropdown = DropDown()
    let chartDropdown = DropDown()
    let barChart = BarChartView()
    let pieChart = PieChartView()
    var dataPoints: [String] = ["Grocery","Electronics","Apparels","Investemts","Life"]
    var transactions: [(date: Date?, amount: Double, type: Int32, title: String?, color: String?)] = []
    
    var labels:[String] = []
    var values: [Double] = []
    
    var chartEntries: [ChartDataEntry] = []
    
    let arrDay = ["Today","This Month","This Year"]
    let arrChart = ["Bar Chart", "Pie Chart"]
    let colorArr = [
        UIColor.groceryClr,
        UIColor.electronicsClr,
        UIColor.aooarelsClr,
        UIColor.investClr,
        UIColor.lifeClr
        ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayBarChart()
        txtDaySelection.isUserInteractionEnabled = false
        txtChartSelection.isUserInteractionEnabled = false
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupDropDowns()
        fetchTransaction()
        
        let savedAction = txtDaySelection.text
        if savedAction == "Today"{
            updateChart(type: "Daily")
        } else if savedAction == "This Month"{
            updateChart(type: "Monthly")
        } else if savedAction == "This year"{
            updateChart(type: "Yearly")
        }
    }
    @IBAction func BtnDaySelectionClick(_ sender: Any) {
        print("btnclicked")
        dayDropdown.show()
    }
    
    @IBAction func BtnChartSelectionClick(_ sender: Any) {
        chartDropdown.show()
    }
}
//MARK: Custom FUnctions
extension CategoryChartVCViewController{
    func setupDropDowns(){
        dayDropdown.anchorView = dayView
        dayDropdown.dataSource = arrDay
        dayDropdown.selectionAction = { (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.txtDaySelection.text = self.arrDay[index]
            if item == "Today"{
                print("today selected")
                self.updateChart(type: "Daily")
            } else if item == "This Month"{
                print("this month selected")
                self.updateChart(type: "Monthly")
            } else if item == "This Year"{
                print("this year selected")
                self.updateChart(type: "Yearly")
            }
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        dayDropdown.bottomOffset = CGPoint(x: 0, y:(dayDropdown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        dayDropdown.topOffset = CGPoint(x: 0, y:-(dayDropdown.anchorView?.plainView.bounds.height)!)
        dayDropdown.direction = .bottom
        dayDropdown.cellHeight = 50
        dayDropdown.backgroundColor = .black
        dayDropdown.textColor = .white
        dayDropdown.cornerRadius = 10

        chartDropdown.anchorView = chartView
        chartDropdown.dataSource = arrChart
        chartDropdown.selectionAction = { (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.txtChartSelection.text = self.arrChart[index]
            // Switch chart based on selection
            if item == "Bar Chart" {
                self.displayBarChart()
                self.mainChartView.isHidden = false
                self.pieChart.isHidden = true
            } else if item == "Pie Chart" {
                self.displayPiechart()
                self.mainChartView.isHidden = true
                self.pieChart.isHidden = false
            }
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        chartDropdown.bottomOffset = CGPoint(x: 0, y:(chartDropdown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        chartDropdown.topOffset = CGPoint(x: 0, y:-(chartDropdown.anchorView?.plainView.bounds.height)!)
        chartDropdown.direction = .bottom
        chartDropdown.cellHeight = 50
        chartDropdown.backgroundColor = .black
        chartDropdown.textColor = .white
        chartDropdown.cornerRadius = 10
    }
    
    func displayBarChart(){
        pieChart.isHidden = true
        mainChartView.isHidden = false
        mainChartView.data = nil
        //updateChart(type: "Daily")
        setChart(dataPoints: labels, values: values)
    }
    
    func setChart(dataPoints: [String], values: [Double]) {
        mainChartView.noDataText = "No data available!"
        mainChartView.noDataTextColor = UIColor.white

        // Clear previous entries
        var barChartEntries: [BarChartDataEntry] = []
        var pieChartEntries: [PieChartDataEntry] = []

        for i in 0..<values.count {
            print("chart point : \(values[i])")
            let dataEntry = BarChartDataEntry(x: Double(i), y: values[i])
            barChartEntries.append(dataEntry)

            let pieDataEntry = PieChartDataEntry(value: values[i], label: dataPoints[i])
            pieChartEntries.append(pieDataEntry)
        }

        // Bar Chart Setup
        let barDataSet = BarChartDataSet(entries: barChartEntries, label: "Category")
        barDataSet.colors = colorArr
        barDataSet.valueTextColor = .white
        barDataSet.valueFont = UIFont.systemFont(ofSize: 12)

        let barData = BarChartData(dataSet: barDataSet)
        mainChartView.data = barData

        let description = Description()
        description.text = ""
        mainChartView.chartDescription = description

        // X-Axis Labels
        mainChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: dataPoints)
        mainChartView.xAxis.granularity = 1
        mainChartView.xAxis.labelPosition = .bottom
        mainChartView.xAxis.labelTextColor = UIColor.white
        mainChartView.xAxis.drawGridLinesEnabled = false

        // Left Axis
        mainChartView.leftAxis.drawAxisLineEnabled = true
        mainChartView.leftAxis.drawGridLinesEnabled = false
        mainChartView.leftAxis.axisMinimum = 0

        // Disable Right Axis
        mainChartView.rightAxis.enabled = false

        // UI settings
        mainChartView.setScaleEnabled(false)
        mainChartView.legend.enabled = true

        let marker = BalloonMarker(color: UIColor.orange,
                                   font: UIFont.systemFont(ofSize: 15),
                                   textColor: UIColor.white,
                                   insets: UIEdgeInsets(top: 8, left: 8, bottom: 20, right: 8))
        marker.chartView = mainChartView
        marker.minimumSize = CGSize(width: 90, height: 50)
        mainChartView.marker = marker
        mainChartView.legend.form = .line

        // Pie Chart Setup
        pieChart.noDataText = "No Data available"
        
        let pieDataset = PieChartDataSet(entries: pieChartEntries, label: "Category")
        pieDataset.colors = colorArr
        pieDataset.valueTextColor = .white
        pieDataset.valueFont = UIFont.systemFont(ofSize: 12)

        let pieData = PieChartData(dataSet: pieDataset)
        pieChart.data = pieData

        let pieDescription = Description()
        pieDescription.text = ""
        pieChart.chartDescription = pieDescription
    }

    func displayPiechart(){
        mainChartView.isHidden = true
        pieChart.isHidden = false
       
        let pieChartEntries: [PieChartDataEntry] = values.enumerated().map { index, value in
            return PieChartDataEntry(value: value, label: labels[index])
        }
        
        let pieDataSet = PieChartDataSet(entries: pieChartEntries, label: "Categories")
        pieDataSet.colors = colorArr //ChartColorTemplates.material() // Use a color template
        pieDataSet.valueTextColor = .white
        pieDataSet.valueFont = UIFont.systemFont(ofSize: 12)
        
        let pieData = PieChartData(dataSet: pieDataSet)
        pieData.setValueTextColor(.white)
        
        // Hide bar chart and show pie chart
        mainChartView.isHidden = true
        pieChart.isHidden = false
        pieChart.data = pieData
        pieChart.chartDescription.text = ""
        //pieChart.animate(yAxisDuration: 1.5)
        pieChart.frame = mainChartView.frame
        view.addSubview(pieChart)
        setChart(dataPoints: labels, values: values)

    }
    
    func updateChart(type: String) {
        chartEntries.removeAll()
        dataPoints.removeAll()
        values.removeAll()

        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date()) // Get start of today

        // Define all category labels
        labels = ["Grocery", "Electronics", "Apparels", "Investments", "Life"]
       
        // initialize category-wise expense dictionary
        var categoryExpenses: [String: Double] = [:]
        for label in labels {
            categoryExpenses[label] = 0.0
        }

        switch type {
        case "Daily":
            for transaction in transactions {
                if let transactionDate = transaction.date,
                   calendar.isDate(transactionDate, inSameDayAs: today),
                   transaction.type == 0 { // Expense type
                  
                    categoryExpenses[transaction.title!, default: 0.0] += transaction.amount
                }
            }
       
        case "Monthly":
            let currentMonth = calendar.component(.month, from: today)
            let currentYear = calendar.component(.year, from: today)

            for transaction in transactions {
                if let transactionDate = transaction.date,
                   calendar.component(.month, from: transactionDate) == currentMonth,
                   calendar.component(.year, from: transactionDate) == currentYear,
                   transaction.type == 0 { // Expense type
                  
                    categoryExpenses[transaction.title!, default: 0.0] += transaction.amount
                }
            }
       
        case "Yearly":
            let currentYear = calendar.component(.year, from: today)

            for transaction in transactions {
                if let transactionDate = transaction.date,
                   calendar.component(.year, from: transactionDate) == currentYear,
                   transaction.type == 0 { // Expense type
                  
                    categoryExpenses[transaction.title!, default: 0.0] += transaction.amount
                }
            }

        default:
            return
        }

        // Populate values array for chart
        for label in labels {
            values.append(categoryExpenses[label] ?? 0.0)
        }

        // Update chart with labels and values
        setChart(dataPoints: labels, values: values)
    }
    
    func fetchTransaction(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        transactions.removeAll()

        let expenseFetch: NSFetchRequest<Expense> = Expense.fetchRequest()
        
        do{
            let expenseResults = try context.fetch(expenseFetch)

            for expense in expenseResults{
                let date = expense.date
                let amount = Double(expense.amount ?? "") ?? 0.0
                let type = expense.type
                let title = expense.title
                let color = expense.viewColor
                
                transactions.append((date: date, amount: amount, type: type, title: title, color: color))
            }
        } catch{
            print("eror in fetching data",error)
        }
    }
}
//extension String {
//    var toDate: Date {
//        return Date.Formatter.customDate.date(from: self)!
//    }
//}
//extension Date {
//    struct Formatter {
//        static let customDate: DateFormatter = {
//            let formatter = DateFormatter()
//            formatter.locale = Locale(identifier: "en_US_POSIX")
//            formatter.dateFormat = "MM-dd-yyyy hh:mm:ss a"
//            return formatter
//        }()
//    }
//}
