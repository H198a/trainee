//
//  HomeVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 06/03/25.
//

import UIKit
import CoreData

class HomeVC: UIViewController {
//MARK: IBOutlet and Variable Declaration
    @IBOutlet weak var homeTblView: UITableView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var TblView: UITableView!
    @IBOutlet weak var sideView: UIView!
    @IBOutlet weak var LblAvilbleBalance: UILabel!
    
    var transactions: [(title: String, date: Date, amount: Double, imageName: String, currency: String, colorView: UIColor, type: Int32)] = []
    private var sideViewIsOpen = false
    
    var nameArr = ["Records","Bank Sync","Imports","Reciepts","Tags","Cards","Set Budget","CVV","Lists","Settings"]
    var imgArr = ["Records","Bank Sync","Imports","Reciepts","Tags","Cards","Set Budget","CVV","Lists","Settings"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        self.tabBarController?.delegate = self
        //applyGradient(to: sideView)
       // LblAvilbleBalance.text = "$\(String(format: "%.2f", calculateBalance()))"
        homeTblView.backgroundColor = .clear
        sideView.isHidden = true
        TblView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        homeTblView.register(UINib(nibName: "TableViewCellHome", bundle: nil), forCellReuseIdentifier: "TableViewCellHome")

        let swipeLeftGesture = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipeLeft))
           swipeLeftGesture.direction = .left
           view.addGestureRecognizer(swipeLeftGesture)
           
           // Optionally, you can add a swipe gesture to open the side view from left swipe too
           let swipeRightGesture = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipeRight))
           swipeRightGesture.direction = .right
           view.addGestureRecognizer(swipeRightGesture)

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchTransactions()
        navigationController?.setNavigationBarHidden(true, animated: true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
  
    @objc func handleSwipeLeft() {
           // Handle swipe left (to close the side view)
           if sideViewIsOpen {
               closeSideView()
           }
       }

       @objc func handleSwipeRight() {
           // Handle swipe right (to open the side view)
           if !sideViewIsOpen {
               openSideView()
           }
       }
    @IBAction func SideViewBtn(_ sender: Any) {
        toggleSideView()
    }
    
    @IBAction func PlusBtnClick(_ sender: Any) {
        let incomeVC = self.storyboard?.instantiateViewController(withIdentifier: "IncomeVC") as! IncomeVC
        self.navigationController?.pushViewController(incomeVC , animated: true)
    }
}
//MARK: Custom Funciton
extension HomeVC{
    func toggleSideView() {
        if sideViewIsOpen {
            closeSideView()
        } else {
            openSideView()
        }
    }
    
    func openSideView() {
        // Animate the side view to appear
        sideView.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.sideView.frame.origin.x = 0 // Move sideView to its original position
        }) { _ in
            self.sideViewIsOpen = true
        }
    }
    
    func closeSideView() {
        // Animate the side view to slide out
        UIView.animate(withDuration: 0.3, animations: {
            self.sideView.frame.origin.x = -self.sideView.frame.width // Move sideView out of the screen
        }) { _ in
            self.sideView.isHidden = true
            self.sideViewIsOpen = false
        }
    }
    func fetchTransactions() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        transactions.removeAll()

        let incomeFetch: NSFetchRequest<Income> = Income.fetchRequest()
        let expenseFetch: NSFetchRequest<Expense> = Expense.fetchRequest()

        do {
            let incomeResults = try context.fetch(incomeFetch)
            let expenseResults = try context.fetch(expenseFetch)

//            let numberFormatter = NumberFormatter()
//            numberFormatter.numberStyle = .decimal // Handle decimal numbers

            for income in incomeResults {
                let title = income.title ?? ""
                let date = income.date ?? Date()
                let amountString = Double(income.amount ?? "") ?? 0.0
                let imageName = income.image ?? "defaultImage"
                let currency = income.currency ?? ""
                let newType = income.type
                let newColorView = ViewBackgroundColor.shared.hexStringToUIColor(hex: income.viewColor ?? "")

//                let cleanedAmountString = amountString.components(separatedBy: CharacterSet.decimalDigits.inverted).joined() //remove all non digit characters.
//
//                if let amount = numberFormatter.number(from: cleanedAmountString)?.doubleValue {
                transactions.append((title: title, date: date, amount: amountString, imageName: imageName, currency: currency, colorView: newColorView, type: newType))
//                } else {
//                    print("Invalid amount string for income: \(title): \(amountString)")
//                    // Handle the error (e.g., set amount to 0 or exclude the transaction)
//                    transactions.append((title: title, date: date, amount: 0.0, imageName: imageName, currency: currency, colorView: newColorView, type: newType)) //Add the transaction with 0.0 value, or you can exclude it.
//                }
            }

            for expense in expenseResults {
                let title = expense.title ?? ""
                let date = expense.date ?? Date()
                let amountString = Double(expense.amount ?? "") ?? 0.0
                let imageName = expense.image ?? "defaultImage"
                let currency = expense.currency ?? ""
                let newType = expense.type
                let newColorView = ViewBackgroundColor.shared.hexStringToUIColor(hex: expense.viewColor ?? "")
//                let cleanedAmountString = amountString.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()

//                if let amount = numberFormatter.number(from: cleanedAmountString)?.doubleValue {
                transactions.append((title: title, date: date, amount:  amountString, imageName: imageName, currency: currency, colorView: newColorView, type: newType))//expense should be negative.
//                } else {
//                    print("Invalid amount string for expense: \(title): \(amountString)")
//                     transactions.append((title: title, date: date, amount: 0.0, imageName: imageName, currency: currency, colorView: newColorView, type: newType))
//                }
            }

            transactions.sort { $0.date > $1.date }
            homeTblView.reloadData()

        } catch {
            print("Failed to fetch transactions: \(error)")
        }
        LblAvilbleBalance.text = "$\(String(format: "%.2f", calculateBalance()))"
    }
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    func decodeBase64ToImage(base64String: String) -> UIImage? {
        guard let imageData = Data(base64Encoded: base64String, options: .ignoreUnknownCharacters) else { return nil }
        return UIImage(data: imageData)
    }
    func calculateBalance() -> Double/* -> Double*/ {
        var incomeTotal = 0.0
        var expenseTotal = 0.0

        for transaction in transactions {
            if transaction.type == 1 {
                incomeTotal += transaction.amount
                //expenseTotal += transaction.amount
                //return incomeTotal
            } else if transaction.type == 0 {
                expenseTotal += transaction.amount
              
            }
        }

        print("Income Total: \(incomeTotal)")
        print("Expense Total: \(expenseTotal)")
        print(incomeTotal - expenseTotal)
        return incomeTotal - expenseTotal
    }
    func applyShadowToSelectedTab(selectedIndex: Int) {
        guard let tabBar = self.tabBarController?.tabBar else { return }
        
        // Remove shadow from all items
        for (index, item) in tabBar.items?.enumerated() ?? [].enumerated() {
            if let tabButton = tabBar.subviews.first(where: { $0 is UIControl && $0.frame.origin.x == CGFloat(index) }) {
                tabButton.layer.shadowOpacity = 0 // Remove shadow
            }
        }
        
        // Apply shadow to selected tab
        if let selectedTabButton = tabBar.subviews.first(where: { $0 is UIControl && $0.frame.origin.x == CGFloat(selectedIndex) }) {
            selectedTabButton.layer.shadowColor = UIColor.white.cgColor  // Set shadow color
            selectedTabButton.layer.shadowOpacity = 2.5 // Set shadow opacity
            selectedTabButton.layer.shadowOffset = CGSize(width: 0, height: -4)  // Set shadow offset
            selectedTabButton.layer.shadowRadius = 5  // Set shadow blur radius
        }
    }

}
//MARK: TableviewDataSource, Delegate
extension HomeVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1{
            return transactions.count
        } else if tableView.tag == 0{
            return nameArr.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCellHome", for: indexPath) as! TableViewCellHome
            let transaction = transactions[indexPath.row]
            cell.LblHead.text = transaction.title
            
            let formatter = DateFormatter()
            formatter.dateFormat = "MMM dd, yyyy"
            cell.LblDate.text = formatter.string(from: transaction.date)
            
            let text = transaction.type
            if text == 0 {//expense
                cell.LblCurrency.text = "-\(transaction.currency)"
                if !transaction.imageName.isEmpty, let image = UIImage(named: transaction.imageName) {
                    cell.colorImg.image = image
                } else {
                    cell.colorImg.image = UIImage(named: "") // Default image
                }
            } else{//income
                cell.LblCurrency.text = "+\(transaction.currency)"
                cell.colorImg.image = decodeBase64ToImage(base64String: transaction.imageName) ?? UIImage(named: "Ellipse 8")
            }
            
            cell.LblAmonut.text = transaction.amount >= 0 ?  "\(transaction.amount)" : "\(abs(transaction.amount))"
//            if !transaction.imageName.isEmpty, let image = UIImage(named: transaction.imageName) {
//                cell.colorImg.image = image
//            } else {
//                cell.colorImg.image = UIImage(named: "") // Default image
//            }
            
            cell.ColorView.backgroundColor =  transaction.colorView
            cell.ImgColoriew.backgroundColor = transaction.colorView
            print("Number of rows in tableview 1 : \(transactions.count)")
            return cell
        }else if tableView.tag == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
            cell.TblImg.image = UIImage(named: imgArr[indexPath.row])
            cell.TblLbl.text = nameArr[indexPath.row]
            return cell
        }
        return UITableViewCell()
    }
}
extension HomeVC: UITabBarControllerDelegate{
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        guard let selectedIndex = tabBar.items?.firstIndex(of: item) else { return }
        applyShadowToSelectedTab(selectedIndex: selectedIndex)
    }

}

