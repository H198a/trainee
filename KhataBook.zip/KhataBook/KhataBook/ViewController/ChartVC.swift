//
//  ChartVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 18/03/25.
//

import UIKit
import BetterSegmentedControl
import Charts
import CoreData

class ChartVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var BtnDaily: UIButton!
    @IBOutlet weak var BtnMonthly: UIButton!
    @IBOutlet weak var BtnYearly: UIButton!
    @IBOutlet weak var LblAvailableBalance: UILabel!
    @IBOutlet weak var LblTotalText: UILabel!
    @IBOutlet weak var BtnIncome: UIButton!
    @IBOutlet weak var BtnExpense: UIButton!
    @IBOutlet weak var BtnAmount: UIButton!
    @IBOutlet weak var ViewIncome: UIView!
    @IBOutlet weak var ViewExpense: UIView!
    @IBOutlet weak var Linechart: LineChartView!
    
    private var chartDataEntries: [ChartDataEntry] = []
    let newSegemnt = BetterSegmentedControl()
    var transactions: [(date: Date?, amount: Double, type: Int32)] = []
//    var selectedMonthIndex: Int?
//    var selectedYearIndex: Int?
    var dataPoints: [String] = []
    var chartType = 1 // 1 for income, 0 for expense
    var selectedPeriod: String = "Daily" // Default selection
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUP()
//        Linechart.delegate = self
        fetchTransaction()
        updateChart(type: "Daily")
        LblAvailableBalance.text = "\(calculateBalanceForIncome())"
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchTransaction()
    }
}
//MARK: SetUP UI
extension ChartVC{
    func setUP(){
        BtnDaily.layer.cornerRadius = 15
        BtnMonthly.layer.cornerRadius = 15
        BtnYearly.layer.cornerRadius = 15
        //display shadow by default on incomeview
        ViewIncome.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: -1, height: 3)
        ViewIncome.layer.shadowRadius = 3
        ViewIncome.layer.shadowOpacity = 1
//        Linechart.xAxis.setLabelCount(12, force: true)
       
    }
    func btnExpenseSetUp(){
        ViewExpense.backgroundColor = UIColor.view
        ViewIncome.backgroundColor = UIColor.lightGray
        BtnIncome.titleLabel?.textColor = UIColor.white
        BtnExpense.titleLabel?.textColor = UIColor.view
        //display shadow when expense button clicked
        ViewExpense.layer.shadowColor = UIColor.view.cgColor
        ViewExpense.layer.masksToBounds = false
        ViewExpense.layer.shadowOffset = CGSize(width: 0, height: 3)
        ViewExpense.layer.shadowRadius = 3
        ViewExpense.layer.shadowOpacity = 0.5
        //remove shadow when expense button clicked
        ViewExpense.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: 0, height: 0)
        ViewIncome.layer.shadowRadius = 0
        ViewIncome.layer.shadowOpacity = 0
        LblAvailableBalance.text = "\(calculateBalanceForExpense())"
        LblTotalText.text = "Total Expense"
        
    }
    func btnIncomeSetUp(){
        ViewIncome.backgroundColor = UIColor.view
        ViewExpense.backgroundColor = UIColor.lightGray
        BtnIncome.titleLabel?.textColor = UIColor.view
        BtnExpense.titleLabel?.textColor = UIColor.white
        //display shadow when income button clicked
        ViewExpense.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: 0, height: 3)
        ViewIncome.layer.shadowRadius = 3
        ViewIncome.layer.shadowOpacity = 0.5
        //remove shadow when income button clicked
        ViewExpense.layer.shadowColor = UIColor.view.cgColor
        ViewExpense.layer.masksToBounds = false
        ViewExpense.layer.shadowOffset = CGSize(width: 0, height: 0)
        ViewExpense.layer.shadowRadius = 0
        ViewExpense.layer.shadowOpacity = 0
        LblAvailableBalance.text = "\(calculateBalanceForIncome())"
        LblTotalText.text = "Total Income"
    }
    func calculateBalanceForIncome() -> Double/* -> Double*/ {
        var incomeTotal = 0.0

        for transaction in transactions {
            if transaction.type == 1 {
                incomeTotal += transaction.amount
                //expenseTotal += transaction.amount
                //return incomeTotal
            }
        }
        if incomeTotal == 0.0 {
            LblAvailableBalance.text = "0.0"
        }
        print("Income Total: \(incomeTotal)")
        return incomeTotal
    }
    func calculateBalanceForExpense() -> Double/* -> Double*/ {
        var expenseTotal = 0.0

        for transaction in transactions {
            if transaction.type == 0 {
                expenseTotal += transaction.amount
                //expenseTotal += transaction.amount
                //return expenseTotal
            }
        }
        if expenseTotal == 0.0{
            LblAvailableBalance.text = "0.0"
        }
        print("expense Total: \(expenseTotal)")
        return expenseTotal
    }
}
//MARK: Chart Custom Function
extension ChartVC{
    func setChart(dataPoints: [String],values: [Double]) {
        Linechart.noDataText = "No data available!"
        for i in 0..<values.count {
            print("chart point : \(values[i])")
            let dataEntry = ChartDataEntry(x: Double(i),y: values[i],data: dataPoints)
            chartDataEntries.append(dataEntry)
        }
        let line1 = LineChartDataSet(entries: chartDataEntries, label: "")
        line1.colors = [NSUIColor.white]
        line1.mode = .horizontalBezier
        line1.valueTextColor = .clear
        line1.valueFont = UIFont.systemFont(ofSize: 20)
        //        line1.cubicIntensity = 60.0
        line1.drawCirclesEnabled = false
        line1.drawVerticalHighlightIndicatorEnabled = false
        line1.drawHorizontalHighlightIndicatorEnabled = false
        
        let gradient = getGradientFilling()
        line1.fill = LinearGradientFill(gradient: gradient, angle: 90.0)
        line1.drawFilledEnabled = true
        
        let data = LineChartData(dataSet: line1)
        Linechart.data = data
        // let indexData = data[1] as? LineChartDataSet
        
        Linechart.setScaleEnabled(true)
        //Linechart.animate(xAxisDuration: 1.5)
        Linechart.drawGridBackgroundEnabled = false
        Linechart.xAxis.drawAxisLineEnabled = false
        Linechart.xAxis.drawGridLinesEnabled = true//display vertical lines in charts
        Linechart.leftAxis.drawAxisLineEnabled = true
        Linechart.leftAxis.drawGridLinesEnabled = false
        Linechart.rightAxis.drawAxisLineEnabled = true
        Linechart.rightAxis.drawGridLinesEnabled = true
        Linechart.legend.enabled = true
        Linechart.xAxis.enabled = true
        Linechart.leftAxis.enabled = false
        Linechart.scaleXEnabled = true
        Linechart.scaleYEnabled = true
        Linechart.xAxis.spaceMax = 0.3
        Linechart.xAxis.spaceMin = 0.3
        Linechart.leftAxis.spaceBottom = 0
        Linechart.rightAxis.enabled = false//remove upper text line
        Linechart.xAxis.drawLabelsEnabled = true//display bottom labes
        Linechart.xAxis.labelTextColor = .white
        Linechart.doubleTapToZoomEnabled = false
        Linechart.xAxis.avoidFirstLastClippingEnabled = false
        Linechart.rightAxis.axisMaximum = 100.0
        Linechart.xAxis.labelFont = UIFont.systemFont(ofSize: 15)
        Linechart.xAxis.labelPosition = .bottom
        Linechart.xAxis.wordWrapEnabled = true
        //Linechart.legend.font = UIFont.systemFont(ofSize: 15)
       
        let marker = BalloonMarker(color: UIColor.orange,
                                   font: UIFont.systemFont(ofSize: 15),
                                   textColor: UIColor.white,
                                   insets: UIEdgeInsets(top: 8, left: 8, bottom: 20, right: 8))
        marker.chartView = Linechart
        marker.minimumSize = CGSize(width: 90, height: 50)
        Linechart.marker = marker
        Linechart.legend.form = .line
    }
    private func getGradientFilling() -> CGGradient {
        
        let coloTop = UIColor(red: 227/255, green: 181/255, blue: 60/255, alpha: 1).cgColor
        let colorBottom = UIColor(red: 227/255, green: 130/255, blue: 60/255, alpha: 0).cgColor
        let gradientColors = [coloTop, colorBottom] as CFArray
        let colorLocations: [CGFloat] = [0.7, 0.0]
        return CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColors, locations: colorLocations)!
    }
    //MARK: Update Charts
    func updateChart(type: String) {
        var values: [Double] = []  // Holds the amounts (income or expense)
        chartDataEntries.removeAll()
        var labels: [String] = []
        
        let calendar = Calendar.current
        
        switch type {
        case "Daily":
            // Clear previous chart data
            dataPoints.removeAll()
            values.removeAll()
            labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

            let arrCurrentWeekDate = Date().daysOfWeek(using: Calendar(identifier: .iso8601))
            
            for date in arrCurrentWeekDate {
                var dailyIncome = 0.0
                var dailyExpense = 0.0
                var hasTransaction = false
                
                for transaction in transactions {
                    let isSameDay = calendar.isDate(date, equalTo: transaction.date ?? Date(), toGranularity: .day)
                    
                    if isSameDay {
                        hasTransaction = true
                        if transaction.type == 1 {  // Income
                            dailyIncome += transaction.amount
                        } else if transaction.type == 0 {  // Expense
                            dailyExpense += transaction.amount
                        }
                    }
                }
                
                // Append values based on chartType
                dataPoints.append(date.formattedDate())
                values.append(hasTransaction ? (chartType == 1 ? dailyIncome : dailyExpense) : 0)
            }

        case "Monthly":
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMM" // Format: "Sep, Oct, Nov, ..."

            labels = []
            values = []

            let calendar = Calendar.current
            let currentDate = Date()
            let currentMonth = calendar.component(.month, from: currentDate)
            let currentYear = calendar.component(.year, from: currentDate)

            // Define start month: 6 months before the current month
            var startMonth = currentMonth - 6
            var startYear = currentYear

            if startMonth < 1 {
                startMonth += 12
                startYear -= 1
            }

            // Generate labels for 7 months (rolling window)
            for i in 0..<7 {
                let month = (startMonth + i - 1) % 12 + 1
                let year = (startMonth + i > 12) ? startYear + 1 : startYear

                let monthStart = calendar.date(from: DateComponents(year: year, month: month, day: 1))!
                let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)!

                var monthlyIncome = 0.0
                var monthlyExpense = 0.0

                for transaction in transactions {
                    if let transactionDate = transaction.date,
                       transactionDate >= monthStart && transactionDate < monthEnd {
                        if transaction.type == 1 {  // Income
                            monthlyIncome += transaction.amount
                        } else if transaction.type == 0 {  // Expense
                            monthlyExpense += transaction.amount
                        }
                    }
                }

                labels.append(dateFormatter.string(from: monthStart))
                values.append(chartType == 1 ? monthlyIncome : monthlyExpense)
            }

        case "Yearly":
            labels = []
            values = []

            let startYear = 2019
            let endYear = 2025

            for year in startYear...endYear {
                let yearStart = calendar.date(from: DateComponents(year: year, month: 1, day: 1))!
                let yearEnd = calendar.date(from: DateComponents(year: year, month: 12, day: 31))!

                var yearlyIncome = 0.0
                var yearlyExpense = 0.0

                for transaction in transactions {
                    if let transactionDate = transaction.date,
                       transactionDate >= yearStart && transactionDate <= yearEnd {
                        if transaction.type == 1 {  // Income
                            yearlyIncome += transaction.amount
                        } else if transaction.type == 0 {  // Expense
                            yearlyExpense += transaction.amount
                        }
                    }
                }

                labels.append("\(year)")
                values.append(chartType == 1 ? yearlyIncome : yearlyExpense)
            }

        default:
            return
        }
        
        let description = Description()
        description.text = ""
        Linechart.chartDescription = description
        Linechart.xAxis.valueFormatter = IndexAxisValueFormatter(values: labels)
        Linechart.xAxis.labelPosition = .bottom
        
        setChart(dataPoints: labels, values: values)
    }

}

extension Date {
    func formattedDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE" // "Mon", "Tue", "Wed", etc.
        return formatter.string(from: self)
    }
}
//MARK: Custom Function
extension ChartVC{
    func fetchTransaction(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        transactions.removeAll()
        
        let incomeFetch: NSFetchRequest<Income> = Income.fetchRequest()
        let expenseFetch: NSFetchRequest<Expense> = Expense.fetchRequest()
        
        do{
            let incomeResults = try context.fetch(incomeFetch)
            let expenseResults = try context.fetch(expenseFetch)
            
            for income in incomeResults {
                let date = income.date
                let amount = Double(income.amount ?? "") ?? 0.0
                let type = income.type
                
                transactions.append((date: date, amount: amount, type: type))
            }
            for expense in expenseResults{
                let date = expense.date
                let amount = Double(expense.amount ?? "") ?? 0.0
                let type = expense.type
                
                transactions.append((date: date, amount: amount, type: type))
            }
        } catch{
            print("eror in fetching data",error)
        }
    }
    
    func calculateDailyAmount(from startDate: Date, to endDate: Date) -> Double {
        var totalAmount: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate {
                if transaction.type == 1 { // Income
                    totalAmount += transaction.amount
                } else { // Expense
                    totalAmount -= transaction.amount
                }
            }
        }
        return totalAmount
    }
    
    func calculateMonthlyAmount(from startDate: Date, to endDate: Date) -> Double {
        var totalAmount: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate {
                if transaction.type == 1 { // Income
                    totalAmount += transaction.amount
                } else { // Expense
                    totalAmount -= transaction.amount
                }
            }
        }
        return totalAmount
    }
    
    func calculateYearlyAmount(from startDate: Date, to endDate: Date) -> Double {
        var totalAmount: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate {
                if transaction.type == 1 { // Income
                    totalAmount += transaction.amount
                } else { // Expense
                    totalAmount -= transaction.amount
                }
            }
        }
        return totalAmount
    }
    
    func calculateDailyIncome(from startDate: Date, to endDate: Date) -> Double {
        var totalIncome: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 1 {
                totalIncome += transaction.amount
            }
        }
        return totalIncome
    }
    
    func calculateDailyExpense(from startDate: Date, to endDate: Date) -> Double {
        var totalExpense: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 0 {
                totalExpense += transaction.amount
            }
        }
        return totalExpense
    }
    func updateButtonSelection(selectedButton: UIButton) {
        BtnDaily.isSelected = false
        BtnMonthly.isSelected = false
        BtnYearly.isSelected = false

        selectedButton.isSelected = true  // Mark the clicked button as selected
    }
}
//MARK: Click Events
extension ChartVC{
    @IBAction func BtnDailyClick(_ sender: Any) {
        LblAvailableBalance.text = ("\(calculateBalanceForIncome())")
        BtnDaily.backgroundColor = UIColor.chartBtnColors
        BtnYearly.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.clear
        //setChart(dataPoints: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        selectedPeriod = "Daily"
        updateButtonSelection(selectedButton: sender as! UIButton)
        updateChart(type: "Daily")
    }
    
    @IBAction func BtnMonthlyClick(_ sender: Any) {
        LblAvailableBalance.text = ("\(calculateBalanceForIncome())")
        BtnDaily.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.chartBtnColors
        BtnYearly.backgroundColor = UIColor.clear
        //setChart(dataPoints: ["Mar","Apr","May","Jun","Jul","Aug","Sep"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        selectedPeriod = "Monthly"
        updateButtonSelection(selectedButton: sender as! UIButton)
        updateChart(type: "Monthly")
    }
    
    @IBAction func BtnYearlyClick(_ sender: Any) {
        LblAvailableBalance.text = ("\(calculateBalanceForIncome())")
        BtnDaily.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.clear
        BtnYearly.backgroundColor = UIColor.chartBtnColors
        //setChart(dataPoints: ["2019","2020","2021","2022","2023","2024","2025"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        selectedPeriod = "Yearly"
        updateButtonSelection(selectedButton: sender as! UIButton)
        updateChart(type: "Yearly")
    }
    
    @IBAction func BtnIncomeClick(_ sender: Any) {
        chartType = 1
        btnIncomeSetUp()
        updateChart(type: selectedPeriod)
      
    }
    
    @IBAction func BtnExpenseClick(_ sender: Any) {
        chartType = 0
        btnExpenseSetUp()
        updateChart(type: selectedPeriod)
        
    }
}

/*---x
 |y*/
extension Date {
    func byAdding(component: Calendar.Component, value: Int, wrappingComponents: Bool = false, using calendar: Calendar = .current) -> Date? {
        calendar.date(byAdding: component, value: value, to: self, wrappingComponents: wrappingComponents)
    }
    func dateComponents(_ components: Set<Calendar.Component>, using calendar: Calendar = .current) -> DateComponents {
        calendar.dateComponents(components, from: self)
    }
    func startOfWeek(using calendar: Calendar = .current) -> Date {
        calendar.date(from: dateComponents([.yearForWeekOfYear, .weekOfYear], using: calendar))!
    }
    var noon: Date {
        Calendar.current.date(bySettingHour: 12, minute: 0, second: 0, of: self)!
    }
    func daysOfWeek(using calendar: Calendar = .current) -> [Date] {
        let startOfWeek = self.startOfWeek(using: calendar).noon
        return (0...6).map { startOfWeek.byAdding(component: .day, value: $0, using: calendar)! }
    }
}
