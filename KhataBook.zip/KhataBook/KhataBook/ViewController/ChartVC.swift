//
//  ChartVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 18/03/25.
//

import UIKit
import BetterSegmentedControl
import Charts
import CoreData

class ChartVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var BtnDaily: UIButton!
    @IBOutlet weak var BtnMonthly: UIButton!
    @IBOutlet weak var BtnYearly: UIButton!
    @IBOutlet weak var LblAvailableBalance: UILabel!
    @IBOutlet weak var BtnIncome: UIButton!
    @IBOutlet weak var BtnExpense: UIButton!
    @IBOutlet weak var BtnAmount: UIButton!
    @IBOutlet weak var ViewIncome: UIView!
    @IBOutlet weak var ViewExpense: UIView!
    @IBOutlet weak var Linechart: LineChartView!
    
    private var chartDataEntries: [ChartDataEntry] = []
    let newSegemnt = BetterSegmentedControl()
    var transactions: [(date: Date?, amount: Double, type: Int32)] = []
    var selectedIndex: Int?
    var selectedMonthIndex: Int?
     var selectedYearIndex: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        updateChart(type: "Daily")
//        setChart(dataPoints: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
    }
}
//MARK: SetUP UI
extension ChartVC{
    func setUP(){
        BtnDaily.layer.cornerRadius = 15
        BtnMonthly.layer.cornerRadius = 15
        BtnYearly.layer.cornerRadius = 15
        //display shadow by default on incomeview
        ViewIncome.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: -1, height: 3)
        ViewIncome.layer.shadowRadius = 3
        ViewIncome.layer.shadowOpacity = 1
        Linechart.xAxis.setLabelCount(12, force: true)
       
    }
    func btnExpenseSetUp(){
        ViewExpense.backgroundColor = UIColor.view
        ViewIncome.backgroundColor = UIColor.lightGray
        BtnIncome.titleLabel?.textColor = UIColor.white
        BtnExpense.titleLabel?.textColor = UIColor.view
        //display shadow when expense button clicked
        ViewExpense.layer.shadowColor = UIColor.view.cgColor
        ViewExpense.layer.masksToBounds = false
        ViewExpense.layer.shadowOffset = CGSize(width: 0, height: 3)
        ViewExpense.layer.shadowRadius = 3
        ViewExpense.layer.shadowOpacity = 0.5
        //remove shadow when expense button clicked
        ViewExpense.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: 0, height: 0)
        ViewIncome.layer.shadowRadius = 0
        ViewIncome.layer.shadowOpacity = 0
    }
    func btnIncomeSetUp(){
        ViewIncome.backgroundColor = UIColor.view
        ViewExpense.backgroundColor = UIColor.lightGray
        BtnIncome.titleLabel?.textColor = UIColor.view
        BtnExpense.titleLabel?.textColor = UIColor.white
        //display shadow when income button clicked
        ViewExpense.layer.masksToBounds = false
        ViewIncome.layer.shadowColor = UIColor.view.cgColor
        ViewIncome.layer.shadowOffset = CGSize(width: 0, height: 3)
        ViewIncome.layer.shadowRadius = 3
        ViewIncome.layer.shadowOpacity = 0.5
        //remove shadow when income button clicked
        ViewExpense.layer.shadowColor = UIColor.view.cgColor
        ViewExpense.layer.masksToBounds = false
        ViewExpense.layer.shadowOffset = CGSize(width: 0, height: 0)
        ViewExpense.layer.shadowRadius = 0
        ViewExpense.layer.shadowOpacity = 0
    }
}
//MARK: Chart Custom Function
extension ChartVC{
    func setChart(dataPoints: [String], values: [Double]) {
            Linechart.noDataText = "No data available!"
            chartDataEntries.removeAll()

            for i in 0..<values.count {
                print("chart point : \(values[i])")
                let dataEntry = ChartDataEntry(x: Double(i), y: values[i], data: dataPoints[i]) //dataPoints[i]
                chartDataEntries.append(dataEntry)
            }
            let line1 = LineChartDataSet(entries: chartDataEntries, label: "")
            line1.colors = [NSUIColor.white]
            line1.mode = .cubicBezier
            line1.valueTextColor = .clear
            line1.cubicIntensity = 0.2
            line1.drawCirclesEnabled = false
        // Highlight today's point
              let todayIndex = Calendar.current.component(.weekday, from: Date()) - 2 // Adjust to 0-6 index
              if todayIndex >= 0 && todayIndex < chartDataEntries.count {
                  line1.highlightColor = .yellow
                  line1.highlightLineWidth = 3.0
                  line1.highlightLineDashLengths = nil
                  line1.highlightLineDashPhase = 0.0
                  line1.highlightEnabled = true
//                  line1.highlightValues([ChartHighlight(x: Double(todayIndex), y: values[todayIndex], dataSetIndex: 0)])
              } else {
                  line1.highlightEnabled = false
              }

            let gradient = getGradientFilling()
            line1.fill = LinearGradientFill(gradient: gradient, angle: 90.0)
            line1.drawFilledEnabled = true

            let data = LineChartData(dataSet: line1)
            Linechart.data = data
            Linechart.setScaleEnabled(true)
            //Linechart.animate(xAxisDuration: 1.5)
            Linechart.drawGridBackgroundEnabled = false
            Linechart.xAxis.drawAxisLineEnabled = true
            Linechart.xAxis.drawGridLinesEnabled = false
            Linechart.leftAxis.drawAxisLineEnabled = false
            Linechart.leftAxis.drawGridLinesEnabled = false
            Linechart.rightAxis.drawAxisLineEnabled = false
            Linechart.rightAxis.drawGridLinesEnabled = false
            Linechart.legend.enabled = true
            Linechart.xAxis.enabled = false
            Linechart.leftAxis.enabled = false
            Linechart.rightAxis.enabled = false //remove upper text line
            Linechart.xAxis.drawLabelsEnabled = false
            //Linechart.xAxis.granularity = 1
            Linechart.xAxis.labelFont = UIFont.systemFont(ofSize: 20)
            //Linechart.xAxis.setLabelCount(1, force: true)//labelpoisstion wordwraping
            Linechart.xAxis.labelPosition = .bottom
            Linechart.xAxis.wordWrapEnabled = true
            Linechart.legend.font = UIFont.systemFont(ofSize: 15)
            //Linechart.legend.spac = 5

            let legendEntries: [LegendEntry]

            legendEntries = chartDataEntries.enumerated().map { (index, data) -> LegendEntry in
                let legendEntry = LegendEntry()
                legendEntry.label = dataPoints[index] // Use the correct index
                legendEntry.labelColor = .white
                legendEntry.formSize = 20
                legendEntry.form = .circle // Set the form to a circle
                return legendEntry
            }

            // Set legend customization
            Linechart.legend.setCustom(entries: legendEntries)
        }
    private func getGradientFilling() -> CGGradient {
        // Setting fill gradient color
        let coloTop = UIColor(red: 227/255, green: 181/255, blue: 60/255, alpha: 1).cgColor
        let colorBottom = UIColor(red: 227/255, green: 130/255, blue: 60/255, alpha: 0).cgColor
        // Colors of the gradient
        let gradientColors = [coloTop, colorBottom] as CFArray
        // Positioning of the gradient
        let colorLocations: [CGFloat] = [0.7, 0.0]
        // Gradient Object
        return CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColors, locations: colorLocations)!
    }
    func updateChart(type: String) {
        
        var dataPoints: [String] = []
        var values: [Double] = []
        chartDataEntries.removeAll()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM"
        dateFormatter.dateFormat = "E"
        let currentMonth = dateFormatter.string(from: Date())
        
        let currentYear = Calendar.current.component(.year, from: Date())
        
        switch type {
        case "Daily":
            fetchTransaction()
            let calendar = Calendar.current
            let today = calendar.startOfDay(for: Date())
            let weekDay = calendar.component(.weekday, from: today)
            let currenctweekDay = weekDay == 1 ? 7 : weekDay - 1
            
            for i in 1...7 {
                          let day = calendar.date(byAdding: .day, value: i - currenctweekDay, to: today)!
                          let dayName = dateFormatter.string(from: day)
                          dataPoints.append(dayName)

                          let dayEnd = calendar.date(byAdding: .day, value: 1, to: day)!
                          let dailyAmount = calculateDailyAmount(from: day, to: dayEnd)
                          values.append(dailyAmount)
                      }
            
            dataPoints = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            values = [5.0, 8.0, 3.0, 12.0, 7.0, 10.0, 6.0]
            
        case "Monthly":
            dataPoints = ["Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"]
                   values = [12.0, 23.0, 54.0, 23.0, 76.0, 77.0, 35.0]
            //create single tuole of each dataset
            let filteredData = zip(dataPoints, values).filter{ (month, _) in
                if let monthIndex = dateFormatter.date(from: month){
                    let monthNb = Calendar.current.component(.month, from: monthIndex)
                    let currentMonthNb = Calendar.current.component(.month, from: Date())
                    return monthNb >= currentMonthNb//return current and future month
                }
                return false
            }
            
            dataPoints = filteredData.map { $0.0 }
            values = filteredData.map { $0.1 }
            
            for i in 1...3 {
                if let nextMonth = Calendar.current.date(byAdding: .month, value: i, to: Date()) {
                    let nextMonthName = dateFormatter.string(from: nextMonth)
                    let nextMonthValue = Double.random(in: 10.0...100.0) // You can add logic to generate values for future months
                    dataPoints.append(nextMonthName)
                    values.append(nextMonthValue)
                }
            }
            
        case "Yearly":
            dataPoints = ["2019", "2020", "2021", "2022", "2023", "2024", "2025"]
               values = [120.0, 150.0, 180.0, 200.0, 220.0, 250.0, 270.0]
        default:
            return
        }
        if dataPoints.count == values.count {
              setChart(dataPoints: dataPoints, values: values)
          } else {
              print("Error: dataPoints and values arrays are not the same length")
          }
//        setChart(dataPoints: dataPoints, values: values)
    }
    
}
//MARK: Custom Function
extension ChartVC{
    func fetchTransaction(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        
        transactions.removeAll()
        
        let incomeFetch: NSFetchRequest<Income> = Income.fetchRequest()
        let expenseFetch: NSFetchRequest<Expense> = Expense.fetchRequest()
        
        do{
            let incomeResults = try context.fetch(incomeFetch)
            let expenseResults = try context.fetch(expenseFetch)
            
            for income in incomeResults {
                let date = income.date
                let amount = Double(income.amount ?? "") ?? 0.0
                let type = income.type
                
                transactions.append((date: date, amount: amount, type: type))
            }
            for expense in expenseResults{
                let date = expense.date
                let amount = Double(expense.amount ?? "") ?? 0.0
                let type = expense.type
                
                transactions.append((date: date, amount: amount, type: type))
            }
        } catch{
            print("eror in fetching data",error)
        }
    }
    //    func addOrSubtractDay(day:Int)->Date{
    //      return Calendar.current.date(byAdding: .day, value: day, to: Date())!
    //    }
    //
    //    func addOrSubtractMonth(month:Int)->Date{
    //      return Calendar.current.date(byAdding: .month, value: month, to: Date())!
    //    }
    //
    //    func addOrSubtractYear(year:Int)->Date{
    //      return Calendar.current.date(byAdding: .year, value: year, to: Date())!
    //    }
    
    func calculateDailyAmount(from startDate: Date, to endDate: Date) -> Double {
        var totalAmount: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate {
                if transaction.type == 1 { // Income
                    totalAmount += transaction.amount
                } else { // Expense
                    totalAmount -= transaction.amount
                }
            }
        }
        return totalAmount
    }
    
    func calculateMonthlyAmount(from startDate: Date, to endDate: Date) -> Double {
          var totalAmount: Double = 0.0
        
          for transaction in transactions {
              if let date = transaction.date, date >= startDate, date < endDate {
                  if transaction.type == 1 { // Income
                      totalAmount += transaction.amount
                  } else { // Expense
                      totalAmount -= transaction.amount
                  }
              }
          }
          return totalAmount
      }
    
    func calculateYearlyAmount(from startDate: Date, to endDate: Date) -> Double {
           var totalAmount: Double = 0.0

           for transaction in transactions {
               if let date = transaction.date, date >= startDate, date < endDate {
                   if transaction.type == 1 { // Income
                       totalAmount += transaction.amount
                   } else { // Expense
                       totalAmount -= transaction.amount
                   }
               }
           }
           return totalAmount
       }
    
    func updateAmountLabel(dayIndex: Int) {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let weekday = calendar.component(.weekday, from: today)
        let currentWeekday = weekday == 1 ? 7 : weekday - 1
        let selectedDate = calendar.date(byAdding: .day, value: dayIndex - currentWeekday, to: today)!
        let selectedEndDate = calendar.date(byAdding: .day, value: 1, to: selectedDate)!
        
        let amount: Double
        
        if ViewIncome.backgroundColor == UIColor.view { // Income is selected
            amount = calculateDailyIncome(from: selectedDate, to: selectedEndDate)
            BtnAmount.setTitle("$\(amount)", for: .normal)
        } else { // Expense is selected
            amount = calculateDailyExpense(from: selectedDate, to: selectedEndDate)
            BtnAmount.setTitle("$\(amount)", for: .normal)
        }
    }
    
    func calculateDailyIncome(from startDate: Date, to endDate: Date) -> Double {
        var totalIncome: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 1 {
                totalIncome += transaction.amount
            }
        }
        return totalIncome
    }
    
    func calculateDailyExpense(from startDate: Date, to endDate: Date) -> Double {
        var totalExpense: Double = 0.0
        
        for transaction in transactions {
            if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 0 {
                totalExpense += transaction.amount
            }
        }
        return totalExpense
    }
}
//MARK: Click Events
extension ChartVC{
    @IBAction func BtnDailyClick(_ sender: Any) {
        LblAvailableBalance.text = "hello"
        BtnDaily.backgroundColor = UIColor.chartBtnColors
        BtnYearly.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.clear
        //setChart(dataPoints: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        updateChart(type: "Daily")
    }
    
    @IBAction func BtnMonthlyClick(_ sender: Any) {
        LblAvailableBalance.text = "hii"
        BtnDaily.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.chartBtnColors
        BtnYearly.backgroundColor = UIColor.clear
        //setChart(dataPoints: ["Mar","Apr","May","Jun","Jul","Aug","Sep"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        updateChart(type: "Monthly")
    }
    
    @IBAction func BtnYearlyClick(_ sender: Any) {
        LblAvailableBalance.text = "fwgerg"
        BtnDaily.backgroundColor = UIColor.clear
        BtnMonthly.backgroundColor = UIColor.clear
        BtnYearly.backgroundColor = UIColor.chartBtnColors
        //setChart(dataPoints: ["2019","2020","2021","2022","2023","2024","2025"], values: [12.0,23.0,54.0,23.0,76.0,77.0,35.0])
        updateChart(type: "Yearly")
    }
    
    @IBAction func BtnIncomeClick(_ sender: Any) {
        btnIncomeSetUp()
    }
    
    @IBAction func BtnExpenseClick(_ sender: Any) {
        btnExpenseSetUp()
    }
}

