//
//  ExpenseVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 07/03/25.
//

import UIKit
//import iOSDropDown
import DropDown
import EventKit
import FSCalendar

class ExpenseVC: UIViewController {
    //MARK: IBOutlet and Variable Declaration
    @IBOutlet weak var TxtDesc: UITextField!
    @IBOutlet weak var TxtPayment: UITextField!
    @IBOutlet weak var TxtCurrency: UITextField!
    @IBOutlet weak var TxtAmount: UITextField!
    @IBOutlet weak var TxtGrocery: UITextField!
    @IBOutlet weak var TxtDate: UITextField!
    
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var paymentView: UIView!
    @IBOutlet weak var currencyView: UIView!
    @IBOutlet weak var amountView: UIView!
    @IBOutlet weak var GroceryView: UIView!
    @IBOutlet weak var DateView: UIView!
    @IBOutlet weak var CalendarView: FSCalendar!
    
    @IBOutlet weak var btnGrocery: UIButton!
    @IBOutlet weak var btnPayment: UIButton!
    @IBOutlet weak var btnCurrency: UIButton!
    @IBOutlet weak var btnAmount: UIButton!
    @IBOutlet weak var LblCurrency: UILabel!
    @IBOutlet weak var btnDate: UIButton!
    
    var Expense: Expense?
    let groceryDropDown = DropDown()
    let paymentDropDown = DropDown()
    let currencyDropDown = DropDown()
    let amountDropDown = DropDown()
    var selectedDate: Date?

    
    var selectedCategoryImage: String?
    var selectedCategoryColor: String?
    let now = Date()
    
    let arrCurrency: [String: String] = [
        "INR": "₹",
        "USD": "$",
        "EUR": "€"
    ]
    let arrList = ["Grocery","Electronics","Apparels","Investemts","Life"]
    let paymentArr = ["Physical Cash", "Credit Card", "Debit Card"]
    let amountArr = ["100", "200", "300"]
    
    let arrCategory: [Category] = [
        Category(name: "Grocery", color: "#39C0D4", icon: UIImage(named: "Grocery")),
        Category(name: "Electronics", color: "#E3823C", icon: UIImage(named: "Electronics")),
        Category(name: "Apparels", color: "#A858EE", icon: UIImage(named: "Apparels")),
        Category(name: "Investemts", color: "#E3B53C", icon: UIImage(named: "Investemts")),
        Category(name: "Life", color: "#8EFDAD", icon: UIImage(named: "Life")),
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        CalendarView.isHidden = true
        setUP()
        setupDropDowns()
        print("Current date and time: \(dateStringFromDate(now))")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let currentDate = selectedDate {
            self.CalendarView.select(currentDate)
        }
        // Deselect today's date explicitly
        self.CalendarView.deselect(Date())
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    @IBAction func btnwholeDateSelection(_ sender: Any) {
        CalendarView.isHidden = false
    }
}
//MARK: SetUp UI
extension ExpenseVC{
    
    func setUP(){
        
        CalendarView.appearance.selectionColor = UIColor.orange // Color for selected date
        CalendarView.appearance.todayColor = UIColor.orange // Color for current date
        CalendarView.appearance.todaySelectionColor = UIColor.orange
        CalendarView.appearance.titleTodayColor = UIColor.white // Text color for current date
        CalendarView.appearance.titleSelectionColor = UIColor.white
        CalendarView.allowsMultipleSelection = false
        CalendarView.backgroundColor = .black
        
        //corner Radius
        CalendarView.layer.cornerRadius = 15
        descriptionView.layer.cornerRadius = 20
        paymentView.layer.cornerRadius = 20
        GroceryView.layer.cornerRadius = 20
        amountView.layer.cornerRadius = 20
        DateView.layer.cornerRadius = 20
        currencyView.layer.cornerRadius = 20
        //transperent color
        DateView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        descriptionView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        paymentView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        GroceryView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        amountView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        currencyView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        //Border Width
        descriptionView.layer.borderWidth = 1
        paymentView.layer.borderWidth = 1
        GroceryView.layer.borderWidth = 1
        amountView.layer.borderWidth = 1
        DateView.layer.borderWidth = 1
        currencyView.layer.borderWidth = 1
        
        groceryDropDown.backgroundColor = .white
        paymentDropDown.backgroundColor = .white
        amountDropDown.backgroundColor = .white
        currencyDropDown.backgroundColor = .white
        
        TxtCurrency.text = "INR (₹)"
        TxtGrocery.isUserInteractionEnabled = false
        TxtDate.isUserInteractionEnabled = false
        TxtCurrency.isUserInteractionEnabled = false
        TxtAmount.keyboardType = .numberPad
        TxtAmount.isUserInteractionEnabled = true
        TxtDesc.attributedPlaceholder = NSAttributedString(
            string: "Add Description",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        TxtCurrency.attributedPlaceholder = NSAttributedString(
            string: "INR (₹)",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        
        let date = Date()
       //2:05p.m | sep 01,2020
        let dateFormatter = DateFormatter()
        dateFormatter.amSymbol = "a.m"
        dateFormatter.pmSymbol = "p.m"
        dateFormatter.dateFormat = "a"
        dateFormatter.dateFormat = "hh:mm a ' | ' MMM dd, yyyy"
        TxtDate.text = dateFormatter.string(from: date)
        //self.TxtDate.minimumFontSize = 50.0
        
    }
    
    func dateStringFromDate(_ inputDate: Date) -> String {
        let df = DateFormatter()
        df.dateFormat = "hh:mm a ' | ' MMM dd, yyyy"
        let dateString = df.string(from: inputDate)
        return dateString
    }
    func setupDropDowns(){
        paymentDropDown.anchorView = paymentView
        paymentDropDown.dataSource = paymentArr
        paymentDropDown.selectionAction = { (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.TxtPayment.text = self.paymentArr[index]
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        paymentDropDown.bottomOffset = CGPoint(x: 0, y:(paymentDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        paymentDropDown.topOffset = CGPoint(x: 0, y:-(paymentDropDown.anchorView?.plainView.bounds.height)!)
        paymentDropDown.direction = .bottom
        paymentDropDown.cellHeight = 50
        paymentDropDown.backgroundColor = .black
        paymentDropDown.textColor = .white
        paymentDropDown.cornerRadius = 10
        groceryDropDown.textFont = UIFont.systemFont(ofSize: 19)
        
        
        amountDropDown.anchorView = amountView
        amountDropDown.dataSource = amountArr
        amountDropDown.selectionAction = { (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.TxtAmount.text = self.amountArr[index]
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        amountDropDown.bottomOffset = CGPoint(x: 0, y:(amountDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        amountDropDown.topOffset = CGPoint(x: 0, y:-(amountDropDown.anchorView?.plainView.bounds.height)!)
        amountDropDown.direction = .bottom
        amountDropDown.cellHeight = 50
        amountDropDown.backgroundColor = .black
        amountDropDown.textColor = .white
        amountDropDown.cornerRadius = 10
        amountDropDown.textFont = UIFont.systemFont(ofSize: 19)
        
        
        
        let currencyList = arrCurrency.map { "\($0.key) (\($0.value))" }
        currencyDropDown.anchorView = currencyView
        currencyDropDown.dataSource = currencyList
        currencyDropDown.selectionAction = { (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.TxtCurrency.text = currencyList[index]
            let currency = self.TxtCurrency.text
            let currencyKey = currency!.split(separator: " ").first ?? ""
            let selectedCurrency = self.arrCurrency[String(currencyKey)] ?? ""
            self.LblCurrency.text = "\(selectedCurrency)"
        }

        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        currencyDropDown.bottomOffset = CGPoint(x: 0, y:(currencyDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        currencyDropDown.topOffset = CGPoint(x: 0, y:-(currencyDropDown.anchorView?.plainView.bounds.height)!)
        currencyDropDown.direction = .bottom
        currencyDropDown.cellHeight = 50
        currencyDropDown.backgroundColor = .black
        currencyDropDown.textColor = .white
        currencyDropDown.cornerRadius = 10
        groceryDropDown.textFont = UIFont.systemFont(ofSize: 19)
        
        
        groceryDropDown.anchorView = GroceryView // UIView or UIBarButtonItem
        groceryDropDown.dataSource = arrList
        /*** IMPORTANT PART FOR CUSTOM CELLS ***/
        groceryDropDown.cellNib = UINib(nibName: "MyDropDownCell", bundle: nil)       
        
        groceryDropDown.customCellConfiguration = { (index: Index, item: String, cell: DropDownCell) -> Void in
            guard let cell = cell as? MyDropDownCell else { return }
            let category = self.arrCategory[index]
            cell.ImgDrop.image = category.icon
            cell.optionLabel.text = category.name
            cell.dropView.backgroundColor = ViewBackgroundColor.shared.hexStringToUIColor(hex: category.color)// UIColor(hex: category.color)
            //cell.dropView.backgroundColor = .systemPink
            cell.dropView.layer.cornerRadius = cell.dropView.frame.width / 2
            
        }
        groceryDropDown.selectionAction = { (index: Int, item: String) in
            self.TxtGrocery.text = item
            let category = self.arrCategory[index]
            self.selectedCategoryImage = category.name // Save image name
            self.selectedCategoryColor = category.color
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        groceryDropDown.bottomOffset = CGPoint(x: 0, y:(groceryDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        groceryDropDown.topOffset = CGPoint(x: 0, y:-(groceryDropDown.anchorView?.plainView.bounds.height)!)
        groceryDropDown.direction = .bottom
        groceryDropDown.textFont = UIFont.systemFont(ofSize: 19)
        groceryDropDown.cellHeight = 80
        groceryDropDown.backgroundColor = .black
        groceryDropDown.textColor = .white
        groceryDropDown.cornerRadius = 10
    }
    func validateFields() -> Bool {
        var isValid = true
        if let number = TxtGrocery.text, number.isEmpty {
            showAlert(message: "Please select Category")
            isValid = false
        }
        if let number = TxtAmount.text, number.isEmpty {
            showAlert(message: "Please enter your Amount")
            isValid = false
        }
        if let number = TxtCurrency.text, number.isEmpty {
            showAlert(message: "Please select Currency")
            isValid = false
        }
        if let number = TxtPayment.text, number.isEmpty {
            showAlert(message: "Please select Payment Mode")
            isValid = false
        }
        if let number = TxtDesc.text, number.isEmpty {
            showAlert(message: "Please enter Description")
            isValid = false
        }
        return isValid
    }
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
}
//MARK: Click Events
extension ExpenseVC{
    @IBAction func btnAmountSelectionClick(_ sender: Any) {
        amountDropDown.show()
    }
    
    @IBAction func btnCurrencySelectionclick(_ sender: Any) {
        currencyDropDown.show()
    }
    
    @IBAction func btnPaymentSelectionclick(_ sender: Any) {
        paymentDropDown.show()
    }
    
    @IBAction func btnDateSelection(_ sender: Any) {
        CalendarView.isHidden = false
    }
    
    @IBAction func btnCategorySelectionClick(_ sender: Any) {
        groceryDropDown.show()
    }
    
    @IBAction func btnCloseClick(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func btnIncomeClick(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnGrocerySelection(_ sender: Any) {
        print("buton clicked")
        groceryDropDown.show()
    }
    
    @IBAction func btnAmountSelection(_ sender: Any) {
        amountDropDown.show()
    }
    
    @IBAction func btnCurrencySelection(_ sender: Any) {
        currencyDropDown.show()
    }
    
    @IBAction func btnPaymentSelection(_ sender: Any) {
        paymentDropDown.show()
    }
    
    @IBAction func btnInsertTemplateClick(_ sender: Any) {
        if validateFields(){
            guard let title = TxtGrocery.text, !title.isEmpty else { return }
            guard let amountText = TxtAmount.text, !amountText.isEmpty else { return }
            guard let dateText = TxtDate.text, !dateText.isEmpty else { return }
            guard let currency = TxtCurrency.text else { return }
            // Convert dateText into Date format
            let currencyKey = currency.split(separator: " ").first ?? ""
            let selectedCurrency = arrCurrency[String(currencyKey)] ?? ""
            let dateFormatter = DateFormatter()
            dateFormatter.amSymbol = "a.m"
            dateFormatter.pmSymbol = "p.m"
            dateFormatter.dateFormat = "a"
            dateFormatter.dateFormat = "hh:mm a ' | ' MMM dd, yyyy" // Change format as per your requirement
            guard let date = dateFormatter.date(from: dateText) else {
                print("Invalid date format")
                return
            }
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let context = appDelegate.persistentContainer.viewContext
            
            let newExpense = KhataBook.Expense(context: context)//remove khatabokk if error occur
            newExpense.title = title
            newExpense.date = date //Date()//Date.from(year: 2016, month: 03, day: 19)

            if let amountValue = Double(amountText) {
                newExpense.amount = "\(amountValue)" // Negative for expense
            } else {
                print("Invalid amount entered",(amountText))
            }
            newExpense.image = selectedCategoryImage ?? ""
            newExpense.viewColor = selectedCategoryColor ?? "#FFFFFF"
            newExpense.currency = "\(selectedCurrency)"
            newExpense.type = 0
            newExpense.isDeletedData = false
            print(selectedCurrency)
            
            do {
                try context.save()
                navigationController?.popToRootViewController(animated: true)
                self.dismiss(animated: true) // Close this view
            } catch {
                print("Failed to save expense: \(error)")
            }
        }
    }
}
extension Date {

    /// Create a date from specified parameters
    ///
    /// - Parameters:
    ///   - year: The desired year
    ///   - month: The desired month
    ///   - day: The desired day
    /// - Returns: A `Date` object
    static func from(year: Int, month: Int, day: Int) -> Date? {
        let calendar = Calendar(identifier: .gregorian)
        var dateComponents = DateComponents()
        dateComponents.year = year
        dateComponents.month = month
        dateComponents.day = day
        dateComponents.hour = 11
        dateComponents.minute = 05
        dateComponents.second = 17
        return calendar.date(from: dateComponents) ?? nil
    }
}
//MARK: Custom Calendar DataSource and Delegate
extension ExpenseVC: FSCalendarDataSource, FSCalendarDelegate {
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh:mm a ' | ' MMM dd, yyyy"
        dateFormatter.amSymbol = "a.m"
        dateFormatter.pmSymbol = "p.m"

        // Get current time components
        let currentTime = Date()
        let calendarInstance = Calendar.current

        let currentHour = calendarInstance.component(.hour, from: currentTime)
        let currentMinute = calendarInstance.component(.minute, from: currentTime)
        let currentSecond = calendarInstance.component(.second, from: currentTime)

        // Set selected date with current time
        var selectedDateComponents = calendarInstance.dateComponents([.year, .month, .day], from: date)
        selectedDateComponents.hour = currentHour
        selectedDateComponents.minute = currentMinute
        selectedDateComponents.second = currentSecond

        guard let finalDate = calendarInstance.date(from: selectedDateComponents) else { return }

        let formattedDate = dateFormatter.string(from: finalDate)
        self.TxtDate.text = formattedDate
        print("Selected Date: \(formattedDate)")

        // Check if selected date is today
        let today = Date()
        let todayComponents = calendarInstance.dateComponents([.year, .month, .day], from: today)
        let selectedComponents = calendarInstance.dateComponents([.year, .month, .day], from: date)

        let isToday = (todayComponents.year == selectedComponents.year) &&
                      (todayComponents.month == selectedComponents.month) &&
                      (todayComponents.day == selectedComponents.day)

        if isToday {
            self.CalendarView.appearance.todayColor = UIColor.orange
            self.TxtDate.text = dateFormatter.string(from: today) // Ensure it displays today's formatted date
        } else {
            self.CalendarView.appearance.todayColor = UIColor.clear
        }

        // Deselect previous dates before selecting new one
        for selectedDate in calendar.selectedDates {
            calendar.deselect(selectedDate)
        }

        // Now select the new date
        calendar.select(date)

        // Force Calendar to refresh UI
//        DispatchQueue.main.async {
//            self.CalendarView.reloadData()
//        }
        

        // Hide calendar view after selecting date
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.CalendarView.isHidden = true
        }

        // Ensure selecting a date in another month updates the current page
        if monthPosition == .previous || monthPosition == .next {
            calendar.setCurrentPage(date, animated: true)
        }
    }
}
