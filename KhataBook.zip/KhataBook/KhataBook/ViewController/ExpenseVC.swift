//
//  ExpenseVC.swift
//  KhataBook
//
//  Created by Hemaxi S on 07/03/25.
//

import UIKit
//import iOSDropDown
import DropDown


class ExpenseVC: UIViewController {
    //MARK: IBOutlet and Variable Declaration
    @IBOutlet weak var TxtDesc: UITextField!
    @IBOutlet weak var TxtPayment: UITextField!
    @IBOutlet weak var TxtCurrency: UITextField!
    @IBOutlet weak var TxtAmount: UITextField!
    @IBOutlet weak var TxtGrocery: UITextField!
    @IBOutlet weak var TxtDate: UITextField!
    
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var paymentView: UIView!
    @IBOutlet weak var currencyView: UIView!
    @IBOutlet weak var amountView: UIView!
    @IBOutlet weak var GroceryView: UIView!
    @IBOutlet weak var DateView: UIView!
    
    @IBOutlet weak var btnGrocery: UIButton!
    @IBOutlet weak var btnPayment: UIButton!
    @IBOutlet weak var btnCurrency: UIButton!
    @IBOutlet weak var btnAmount: UIButton!
    @IBOutlet weak var LblCurrency: UILabel!
    
    let groceryDropDown = DropDown()
    let paymentDropDown = DropDown()
    let currencyDropDown = DropDown()
    let amountDropDown = DropDown()
    
    var selectedCategoryImage: String?
    var selectedCategoryColor: String?
    
    let arrCurrency: [String: String] = [
        "INR": "₹",
        "USD": "$",
        "EUR": "€"
    ]
    let arrList = ["Grocery","Electronics","Apparels","Investemts","Life"]
    let paymentArr = ["Physical Cash", "Credit Card", "Debit Card"]
    let amountArr = ["100", "200", "300"]
    
    let arrCategory: [Category] = [
        Category(name: "Grocery", color: "#39C0D4", icon: UIImage(named: "Grocery")),
        Category(name: "Electronics", color: "#E3823C", icon: UIImage(named: "Electronics")),
        Category(name: "Apparels", color: "#A858EE", icon: UIImage(named: "Apparels")),
        Category(name: "Investemts", color: "#E3B53C", icon: UIImage(named: "Investemts")),
        Category(name: "Life", color: "#8EFDAD", icon: UIImage(named: "Life")),
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUP()
        setupDropDowns()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    @IBAction func btnAmountSelectionClick(_ sender: Any) {
        amountDropDown.show()
    }
    
    @IBAction func btnCurrencySelectionclick(_ sender: Any) {
        currencyDropDown.show()
    }
    
    @IBAction func btnPaymentSelectionclick(_ sender: Any) {
        paymentDropDown.show()
    }
    
    @IBAction func btnCategorySelectionClick(_ sender: Any) {
        groceryDropDown.show()
    }
}
//MARK: SetUp UI
extension ExpenseVC{
    
    func setUP(){
        //corner Radius
        descriptionView.layer.cornerRadius = 20
        paymentView.layer.cornerRadius = 20
        GroceryView.layer.cornerRadius = 20
        amountView.layer.cornerRadius = 20
        DateView.layer.cornerRadius = 20
        currencyView.layer.cornerRadius = 20
        //transperent color
        DateView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        descriptionView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        paymentView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        GroceryView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        amountView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        currencyView.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        //Border Width
        descriptionView.layer.borderWidth = 1
        paymentView.layer.borderWidth = 1
        GroceryView.layer.borderWidth = 1
        amountView.layer.borderWidth = 1
        DateView.layer.borderWidth = 1
        currencyView.layer.borderWidth = 1
        
        groceryDropDown.backgroundColor = .white
        paymentDropDown.backgroundColor = .white
        amountDropDown.backgroundColor = .white
        currencyDropDown.backgroundColor = .white
        
        TxtGrocery.isUserInteractionEnabled = false
        TxtDate.isUserInteractionEnabled = false
        TxtCurrency.isUserInteractionEnabled = false
        TxtAmount.keyboardType = .numberPad
        TxtAmount.isUserInteractionEnabled = true
        TxtDesc.attributedPlaceholder = NSAttributedString(
            string: "Add Description",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        TxtCurrency.attributedPlaceholder = NSAttributedString(
            string: "₹",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        
        let date = Date()
       //2:05p.m | sep 01,2020
        let dateFormatter = DateFormatter()
        dateFormatter.amSymbol = "a.m"
        dateFormatter.pmSymbol = "p.m"
        dateFormatter.dateFormat = "a"
        dateFormatter.dateFormat = "hh:mm a ' | ' MMM dd, yyyy"
        TxtDate.text = dateFormatter.string(from: date)
        //self.TxtDate.minimumFontSize = 50.0
        
    }
    func setupDropDowns(){
        paymentDropDown.anchorView = paymentView
        paymentDropDown.dataSource = paymentArr
        paymentDropDown.selectionAction = { (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.TxtPayment.text = self.paymentArr[index]
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        paymentDropDown.bottomOffset = CGPoint(x: 0, y:(paymentDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        paymentDropDown.topOffset = CGPoint(x: 0, y:-(paymentDropDown.anchorView?.plainView.bounds.height)!)
        paymentDropDown.direction = .bottom
        paymentDropDown.cellHeight = 50
        paymentDropDown.backgroundColor = .black
        paymentDropDown.textColor = .white
        paymentDropDown.cornerRadius = 10
        groceryDropDown.textFont = UIFont.systemFont(ofSize: 19)
        
        
        amountDropDown.anchorView = amountView
        amountDropDown.dataSource = amountArr
        amountDropDown.selectionAction = { (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.TxtAmount.text = self.amountArr[index]
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        amountDropDown.bottomOffset = CGPoint(x: 0, y:(amountDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        amountDropDown.topOffset = CGPoint(x: 0, y:-(amountDropDown.anchorView?.plainView.bounds.height)!)
        amountDropDown.direction = .bottom
        amountDropDown.cellHeight = 50
        amountDropDown.backgroundColor = .black
        amountDropDown.textColor = .white
        amountDropDown.cornerRadius = 10
        amountDropDown.textFont = UIFont.systemFont(ofSize: 19)
        
        
        
        let currencyList = arrCurrency.map { "\($0.key) (\($0.value))" }
        currencyDropDown.anchorView = currencyView
        currencyDropDown.dataSource = currencyList
        currencyDropDown.selectionAction = { (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.TxtCurrency.text = currencyList[index]
            let currency = self.TxtCurrency.text
            let currencyKey = currency!.split(separator: " ").first ?? ""
            let selectedCurrency = self.arrCurrency[String(currencyKey)] ?? ""
            self.LblCurrency.text = "\(selectedCurrency)"
        }

        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        currencyDropDown.bottomOffset = CGPoint(x: 0, y:(currencyDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        currencyDropDown.topOffset = CGPoint(x: 0, y:-(currencyDropDown.anchorView?.plainView.bounds.height)!)
        currencyDropDown.direction = .bottom
        currencyDropDown.cellHeight = 50
        currencyDropDown.backgroundColor = .black
        currencyDropDown.textColor = .white
        currencyDropDown.cornerRadius = 10
        groceryDropDown.textFont = UIFont.systemFont(ofSize: 19)
        
        
        groceryDropDown.anchorView = GroceryView // UIView or UIBarButtonItem
        groceryDropDown.dataSource = arrList
        /*** IMPORTANT PART FOR CUSTOM CELLS ***/
        groceryDropDown.cellNib = UINib(nibName: "MyDropDownCell", bundle: nil)       
        
        groceryDropDown.customCellConfiguration = { (index: Index, item: String, cell: DropDownCell) -> Void in
            guard let cell = cell as? MyDropDownCell else { return }
            let category = self.arrCategory[index]
            cell.ImgDrop.image = category.icon
            cell.optionLabel.text = category.name
            cell.dropView.backgroundColor = ViewBackgroundColor.shared.hexStringToUIColor(hex: category.color)// UIColor(hex: category.color)
            //cell.dropView.backgroundColor = .systemPink
            cell.dropView.layer.cornerRadius = cell.dropView.frame.width / 2
            
        }
        groceryDropDown.selectionAction = { (index: Int, item: String) in
            self.TxtGrocery.text = item
            let category = self.arrCategory[index]
            self.selectedCategoryImage = category.name // Save image name
            self.selectedCategoryColor = category.color
        }
        DropDown.startListeningToKeyboard()
        // Top of drop down will be below the anchorView
        groceryDropDown.bottomOffset = CGPoint(x: 0, y:(groceryDropDown.anchorView?.plainView.bounds.height)!)
        // When drop down is displayed with `Direction.top`, it will be above the anchorView
        groceryDropDown.topOffset = CGPoint(x: 0, y:-(groceryDropDown.anchorView?.plainView.bounds.height)!)
        groceryDropDown.direction = .bottom
        groceryDropDown.textFont = UIFont.systemFont(ofSize: 19)
        groceryDropDown.cellHeight = 80
        groceryDropDown.backgroundColor = .black
        groceryDropDown.textColor = .white
        groceryDropDown.cornerRadius = 10
    }
    func validateFields() -> Bool {
        var isValid = true
        if let number = TxtGrocery.text, number.isEmpty {
            showAlert(message: "Please select Category")
            isValid = false
        }
        if let number = TxtAmount.text, number.isEmpty {
            showAlert(message: "Please enter your Amount")
            isValid = false
        }
        if let number = TxtCurrency.text, number.isEmpty {
            showAlert(message: "Please select Currency")
            isValid = false
        }
        if let number = TxtPayment.text, number.isEmpty {
            showAlert(message: "Please select Payment Mode")
            isValid = false
        }
        if let number = TxtDesc.text, number.isEmpty {
            showAlert(message: "Please enter Description")
            isValid = false
        }
        return isValid
    }
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
}
//MARK: Click Events
extension ExpenseVC{
    @IBAction func btnCloseClick(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func btnIncomeClick(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnGrocerySelection(_ sender: Any) {
        print("buton clicked")
        groceryDropDown.show()
    }
    
    @IBAction func btnAmountSelection(_ sender: Any) {
        amountDropDown.show()
    }
    
    @IBAction func btnCurrencySelection(_ sender: Any) {
        currencyDropDown.show()
    }
    
    @IBAction func btnPaymentSelection(_ sender: Any) {
        paymentDropDown.show()
    }
    
    @IBAction func btnInsertTemplateClick(_ sender: Any) {
        if validateFields(){
            guard let title = TxtGrocery.text, !title.isEmpty else { return }
            guard let amountText = TxtAmount.text, !amountText.isEmpty else { return }
            guard let dateText = TxtDate.text, !dateText.isEmpty else { return }
            guard let currency = TxtCurrency.text else { return }
            // Convert dateText into Date format
            let currencyKey = currency.split(separator: " ").first ?? ""
            let selectedCurrency = arrCurrency[String(currencyKey)] ?? ""
            let dateFormatter = DateFormatter()
            dateFormatter.amSymbol = "a.m"
            dateFormatter.pmSymbol = "p.m"
            dateFormatter.dateFormat = "a"
            dateFormatter.dateFormat = "hh:mm a ' | ' MMM dd, yyyy" // Change format as per your requirement
            guard let date = dateFormatter.date(from: dateText) else {
                print("Invalid date format")
                return
            }
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let context = appDelegate.persistentContainer.viewContext
            
            let newExpense = Expense(context: context)
            newExpense.title = title
            newExpense.date = Date()
            if let amountValue = Double(amountText) {
                newExpense.amount = "\(amountValue)" // Negative for expense
            } else {
                print("Invalid amount entered",(amountText))
            }
            newExpense.image = selectedCategoryImage ?? ""
            newExpense.viewColor = selectedCategoryColor ?? "#FFFFFF"
            newExpense.currency = "\(selectedCurrency)"
            newExpense.type = 0
            print(selectedCurrency)
            
            do {
                try context.save()
                navigationController?.popToRootViewController(animated: true)
                self.dismiss(animated: true) // Close this view
            } catch {
                print("Failed to save expense: \(error)")
            }
        }
    }
}
