//
//  File.swift
//  KhataBook
//
//  Created by Hemaxi S on 10/03/25.
//

import Foundation
/*
 extension Date {

     /// Create a date from specified parameters
     ///
     /// - Parameters:
     ///   - year: The desired year
     ///   - month: The desired month
     ///   - day: The desired day
     /// - Returns: A `Date` object
     static func from(year: Int, month: Int, day: Int) -> Date? {
         let calendar = Calendar(identifier: .gregorian)
         var dateComponents = DateComponents()
         dateComponents.year = year
         dateComponents.month = month

 
 case "Monthly":
     let dateFormatter = DateFormatter()
     dateFormatter.dateFormat = "MMM" // Only "Sep, Oct, Nov, ..."

     labels = []
     values = []

     // Months from Sep to Dec (2024)
     for month in 9...12 {
         let monthStart = calendar.date(from: DateComponents(year: 2024, month: month, day: 1))!
         let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)!

         var monthlyIncome = 0.0
         var monthlyExpense = 0.0

         for transaction in transactions {
             if let transactionDate = transaction.date,
                transactionDate >= monthStart && transactionDate < monthEnd {
                 if transaction.type == 1 {  // Income
                     monthlyIncome += transaction.amount
                 } else if transaction.type == 0 {  // Expense
                     monthlyExpense += transaction.amount
                 }
             }
         }

         labels.append(dateFormatter.string(from: monthStart))
         values.append(chartType == 1 ? monthlyIncome : monthlyExpense)
     }

     // Months from Jan to Mar (2025)
     for month in 1...3 {
         let monthStart = calendar.date(from: DateComponents(year: 2025, month: month, day: 1))!
         let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)!

         var monthlyIncome = 0.0
         var monthlyExpense = 0.0

         for transaction in transactions {
             if let transactionDate = transaction.date,
                transactionDate >= monthStart && transactionDate < monthEnd {
                 if transaction.type == 1 {  // Income
                     monthlyIncome += transaction.amount
                 } else if transaction.type == 0 {  // Expense
                     monthlyExpense += transaction.amount
                 }
             }
         }

         labels.append(dateFormatter.string(from: monthStart))
         values.append(chartType == 1 ? monthlyIncome : monthlyExpense)
     }


 
 
 // loop through the weekday
//            for i in 1...7 {
//                let day = calendar.date(byAdding: .day, value: i - currentWeekDay, to: today)!
//                let dayName = dateFormatter.string(from: day) // "Mon", "Tue", "Wed", etc.
//                dataPoints.append(dayName)  // Add the day name to dataPoints
//
//                // Get the start and end date for each day
//                let dayStart = calendar.startOfDay(for: day)
//                let dayEnd = calendar.date(byAdding: .day, value: 1, to: dayStart)!
//
//                // Calculate the daily amount for this day (Income - Expense)
//                let dailyAmount = calculateDailyAmount(from: dayStart, to: dayEnd)
//                let arrCurrentWeekDate = Date().daysOfWeek(using: Calendar(identifier: .iso8601))
//                //values = [100, 10, 20, 0, 0, 50, 60]
//                values.append(dailyAmount)  // Add the calculated daily amount to values
//            }
 */
//
