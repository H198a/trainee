//
//  File.swift
//  KhataBook
//
//  Created by Hemaxi S on 10/03/25.
//

import Foundation
/*
 func updateChart(type: String) {
     chartType = type
     var dataPoints: [String] = []
     var values: [Double] = []
     chartDataEntries.removeAll()
     let dateFormatter = DateFormatter()

     switch type {
     case "Daily":
         fetchTransaction()
         let calendar = Calendar.current
         let today = calendar.startOfDay(for: Date())
         let weekDay = calendar.component(.weekday, from: today)
         let currenctweekDay = weekDay == 1 ? 7 : weekDay - 1

         for i in 1...7 {
             let day = calendar.date(byAdding: .day, value: i - currenctweekDay, to: today)!
             let dayName = dateFormatter.string(from: day)
             dataPoints.append(dayName)

             let dayEnd = calendar.date(byAdding: .day, value: 1, to: day)!
             let dailyAmount = calculateDailyAmount(from: day, to: dayEnd)
             values.append(dailyAmount)
         }

         // Update amount label for Daily chart
         if let selectedIndex = selectedDayIndex {
             let selectedDate = calendar.date(byAdding: .day, value: selectedIndex - currenctweekDay, to: today)!
             let selectedEndDate = calendar.date(byAdding: .day, value: 1, to: selectedDate)!
             let amount: Double

             if ViewIncome.backgroundColor == UIColor.view {
                 amount = calculateDailyIncome(from: selectedDate, to: selectedEndDate)
             } else {
                 amount = calculateDailyExpense(from: selectedDate, to: selectedEndDate)
             }
             BtnAmount.setTitle("$\(amount)", for: .normal)
         }

     case "Monthly":
         // ... (your existing Monthly logic) ...

         // Update amount label for Monthly chart
         if let selectedIndex = selectedMonthIndex {
             let monthOffset = selectedIndex - 6
             if let date = calendar.date(byAdding: .month, value: monthOffset, to: Date()) {
                 let monthStart = calendar.date(from: DateComponents(year: calendar.component(.year, from: date), month: calendar.component(.month, from: date), day: 1))!
                 let nextMonthStart = calendar.date(byAdding: .month, value: 1, to: monthStart)!
                 let amount: Double

                 if ViewIncome.backgroundColor == UIColor.view {
                     amount = calculateMonthlyIncome(from: monthStart, to: nextMonthStart)
                 } else {
                     amount = calculateMonthlyExpense(from: monthStart, to: nextMonthStart)
                 }
                 BtnAmount.setTitle("$\(amount)", for: .normal)
             }
         }

     case "Yearly":
         // ... (your existing Yearly logic) ...

         // Update amount label for Yearly chart
         if let selectedIndex = selectedYearIndex {
             let yearOffset = selectedIndex - 6
             let year = calendar.component(.year, from: Date()) + yearOffset
             let yearStart = calendar.date(from: DateComponents(year: year, month: 1, day: 1))!
             let nextYearStart = calendar.date(from: DateComponents(year: year + 1, month: 1, day: 1))!
             let amount: Double

             if ViewIncome.backgroundColor == UIColor.view {
                 amount = calculateYearlyIncome(from: yearStart, to: nextYearStart)
             } else {
                 amount = calculateYearlyExpense(from: yearStart, to: nextYearStart)
             }
             BtnAmount.setTitle("$\(amount)", for: .normal)
         }

     default:
         return
     }

     if dataPoints.count == values.count {
         setChart(dataPoints: dataPoints, values: values)
     } else {
         print("Error: dataPoints and values arrays are not the same length")
     }
 }
 
 
 import UIKit
 import BetterSegmentedControl
 import Charts
 import CoreData

 class ChartVC: UIViewController, ChartViewDelegate {
     // ... (Your other properties and viewDidLoad, setUP, button actions, etc.) ...

     func updateAmountLabel(chartType: String, index: Int) {
         let calendar = Calendar.current
         let amount: Double

         switch chartType {
         case "Daily":
             let today = calendar.startOfDay(for: Date())
             let weekday = calendar.component(.weekday, from: today)
             let currentWeekday = weekday == 1 ? 7 : weekday - 1
             let selectedDate = calendar.date(byAdding: .day, value: index - currentWeekday, to: today)!
             let selectedEndDate = calendar.date(byAdding: .day, value: 1, to: selectedDate)!

             if ViewIncome.backgroundColor == UIColor.view {
                 amount = calculateDailyIncome(from: selectedDate, to: selectedEndDate)
             } else {
                 amount = calculateDailyExpense(from: selectedDate, to: selectedEndDate)
             }
             BtnAmount.setTitle("$\(amount)", for: .normal)

         case "Monthly":
             let monthOffset = index - 6
             if let date = calendar.date(byAdding: .month, value: monthOffset, to: Date()) {
                 let monthStart = calendar.date(from: DateComponents(year: calendar.component(.year, from: date), month: calendar.component(.month, from: date), day: 1))!
                 let nextMonthStart = calendar.date(byAdding: .month, value: 1, to: monthStart)!

                 if ViewIncome.backgroundColor == UIColor.view {
                     amount = calculateMonthlyIncome(from: monthStart, to: nextMonthStart)
                 } else {
                     amount = calculateMonthlyExpense(from: monthStart, to: nextMonthStart)
                 }
                 BtnAmount.setTitle("$\(amount)", for: .normal)
             }

         case "Yearly":
             let yearOffset = index - 6
             let year = calendar.component(.year, from: Date()) + yearOffset
             let yearStart = calendar.date(from: DateComponents(year: year, month: 1, day: 1))!
             let nextYearStart = calendar.date(from: DateComponents(year: year + 1, month: 1, day: 1))!

             if ViewIncome.backgroundColor == UIColor.view {
                 amount = calculateYearlyIncome(from: yearStart, to: nextYearStart)
             } else {
                 amount = calculateYearlyExpense(from: yearStart, to: nextYearStart)
             }
             BtnAmount.setTitle("$\(amount)", for: .normal)

         default:
             break
         }
     }

     func calculateDailyIncome(from startDate: Date, to endDate: Date) -> Double {
         var totalIncome: Double = 0.0
         for transaction in transactions {
             if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 1 {
                 totalIncome += transaction.amount
             }
         }
         return totalIncome
     }

     func calculateDailyExpense(from startDate: Date, to endDate: Date) -> Double {
         var totalExpense: Double = 0.0
         for transaction in transactions {
             if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 0 {
                 totalExpense += transaction.amount
             }
         }
         return totalExpense
     }

     func calculateMonthlyIncome(from startDate: Date, to endDate: Date) -> Double {
         var totalIncome: Double = 0.0
         for transaction in transactions {
             if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 1 {
                 totalIncome += transaction.amount
             }
         }
         return totalIncome
     }

     func calculateMonthlyExpense(from startDate: Date, to endDate: Date) -> Double {
         var totalExpense: Double = 0.0
         for transaction in transactions {
             if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 0 {
                 totalExpense += transaction.amount
             }
         }
         return totalExpense
     }

     func calculateYearlyIncome(from startDate: Date, to endDate: Date) -> Double {
         var totalIncome: Double = 0.0
         for transaction in transactions {
             if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 1 {
                 totalIncome += transaction.amount
             }
         }
         return totalIncome
     }

     func calculateYearlyExpense(from startDate: Date, to endDate: Date) -> Double {
         var totalExpense: Double = 0.0
         for transaction in transactions {
             if let date = transaction.date, date >= startDate, date < endDate, transaction.type == 0 {
                 totalExpense += transaction.amount
             }
         }
         return totalExpense
     }

     // ... (Your other functions: fetchTransaction, calculateDailyAmount, calculateMonthlyAmount, calculateYearlyAmount, etc.) ...
 }

 */
