//
//  ToDoAppTests.swift
//  ToDoAppTests
//
//  Created by Hemaxi S on 06/05/25.
//

import Testing
@testable import ToDoApp

struct ToDoAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
