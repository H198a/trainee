//
//  TaskEntity+CoreDataClass.swift
//  
//
//  Created by Hemaxi S on 06/05/25.
//
//

import Foundation
import CoreData

@objc(TaskEntity)
public class TaskEntity: NSManagedObject {

}
