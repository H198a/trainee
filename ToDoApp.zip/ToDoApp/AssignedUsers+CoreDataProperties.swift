//
//  AssignedUsers+CoreDataProperties.swift
//  
//
//  Created by Hemaxi S on 06/05/25.
//
//

import Foundation
import CoreData


extension AssignedUsers {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<AssignedUsers> {
        return NSFetchRequest<AssignedUsers>(entityName: "AssignedUsers")
    }

    @NSManaged public var name: String?
    @NSManaged public var taskEntity: NSSet?

}

// MARK: Generated accessors for taskEntity
extension AssignedUsers {

    @objc(addTaskEntityObject:)
    @NSManaged public func addToTaskEntity(_ value: TaskEntity)

    @objc(removeTaskEntityObject:)
    @NSManaged public func removeFromTaskEntity(_ value: TaskEntity)

    @objc(addTaskEntity:)
    @NSManaged public func addToTaskEntity(_ values: NSSet)

    @objc(removeTaskEntity:)
    @NSManaged public func removeFromTaskEntity(_ values: NSSet)

}
