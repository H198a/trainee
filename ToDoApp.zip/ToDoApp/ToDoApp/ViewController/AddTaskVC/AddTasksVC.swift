//
//  AddTasksVC.swift
//  ToDoApp
//
//  Created by Hemaxi S on 06/05/25.
//

import UIKit
import CoreData

class AddTasksVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var titleView: UIView!
    @IBOutlet weak var descView: UIView!
    @IBOutlet weak var startDateView: UIView!
    @IBOutlet weak var endDateView: UIView!
    @IBOutlet weak var assignView: UIView!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtDesc: UITextView!
    @IBOutlet weak var startDate: UIDatePicker!
    @IBOutlet weak var endDate: UIDatePicker!
    @IBOutlet weak var txtAssign: UITextField!
    @IBOutlet weak var cvAssignedUsers: UICollectionView!
    
    var users: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
        users = []
//        users = fetchUsersFromCoreData()
        cvAssignedUsers.reloadData()
    }
    @objc func deleteUser(_ sender: UIButton) {
        let index = sender.tag
        let nameToDelete = users[index]
        deleteUserFromCoreData(name: nameToDelete)
        users.remove(at: index)
        cvAssignedUsers.reloadData()
    }
    @objc func didPressOnDontBtn(){
        addUserFromTextField()
    }
}
//MARK: Setup UI
extension AddTasksVC{
    func setUP(){
    
        let nibName = UINib(nibName: "AddTaskCell", bundle: nil)
        cvAssignedUsers.register(nibName, forCellWithReuseIdentifier: "AddTaskCell")
        
        
        titleView.layer.shadowColor = UIColor.black.cgColor
        titleView.layer.shadowOpacity = 0.4
        titleView.layer.shadowOffset = CGSize(width: 0, height: 0)
        titleView.layer.shadowRadius = 4
        titleView.layer.masksToBounds = false  // Ensures shadow is visible
        
        descView.layer.shadowColor = UIColor.black.cgColor
        descView.layer.shadowOpacity = 0.4
        descView.layer.shadowOffset = CGSize(width: 0, height: 0)
        descView.layer.shadowRadius = 4
        descView.layer.masksToBounds = false  // Ensures shadow is visible
        
        startDateView.layer.shadowColor = UIColor.black.cgColor
        startDateView.layer.shadowOpacity = 0.4
        startDateView.layer.shadowOffset = CGSize(width: 0, height: 0)
        startDateView.layer.shadowRadius = 4
        startDateView.layer.masksToBounds = false  // Ensures shadow is visible
        
        endDateView.layer.shadowColor = UIColor.black.cgColor
        endDateView.layer.shadowOpacity = 0.4
        endDateView.layer.shadowOffset = CGSize(width: 0, height: 0)
        endDateView.layer.shadowRadius = 4
        endDateView.layer.masksToBounds = false  // Ensures shadow is visible
        
        assignView.layer.shadowColor = UIColor.black.cgColor
        assignView.layer.shadowOpacity = 0.4
        assignView.layer.shadowOffset = CGSize(width: 0, height: 0)
        assignView.layer.shadowRadius = 4
        assignView.layer.masksToBounds = false  // Ensures shadow is visible
        
        txtDesc.text = "Enter Description"
        txtDesc.textColor = UIColor.lightGray
        txtDesc.delegate = self
        
        txtAssign.delegate = self
        
        startDate.minimumDate = Date()
        endDate.minimumDate = Date()
    }
}
//MARK: Custom Functions
extension AddTasksVC{
    func validateFields() -> Bool {
        var isValid = true
        if let number = txtTitle.text, number.isEmpty {
            showAlert(message: "Please enter your title")
            isValid = false
        }
        if let number = txtDesc.text, number.isEmpty {
            showAlert(message: "Please enter Description")
            isValid = false
        }
        if let number = txtAssign.text, number.isEmpty {
            showAlert(message: "Please assign someone")
            isValid = false
        }
        return isValid
    }
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    func addUserFromTextField() {
        guard let name = txtAssign.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { return }
        users.append(name)
        saveUserToCoreData(name: name)
        txtAssign.text = ""
        cvAssignedUsers.reloadData()
    }
    func saveUserToCoreData(name: String){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{return}
        let context = appDelegate.persistentContainer.viewContext
        let newUser = ToDoApp.AssignedUsers(context: context)
        newUser.name = name
        do{
            try context.save()
            print("data saved successfully...")
        } catch{
            print("erro in saving data", error)
        }
    }
    func fetchUsersFromCoreData() -> [String]{
        guard let appDeletegate = UIApplication.shared.delegate as? AppDelegate else{return []}
        let context = appDeletegate.persistentContainer.viewContext
        let request: NSFetchRequest<AssignedUsers> = AssignedUsers.fetchRequest()
        do{
//            let userReq = try context.fetch(request)
            
            let result = try context.fetch(request)
            DispatchQueue.main.async{
                self.cvAssignedUsers.reloadData()
            }
            print("data saved succssfully of assignedusers")
            return result.compactMap { $0.name }
        } catch{
            print("Error in fetching data",error)
            return []
        }
    }
    func deleteUserFromCoreData(name: String){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{return}
        let context = appDelegate.persistentContainer.viewContext
        let deletereq: NSFetchRequest<AssignedUsers> = AssignedUsers.fetchRequest()
        deletereq.predicate = NSPredicate(format: "name == %@", name)
        do{
            let deleteUser = try context.fetch(deletereq)
            for userss in deleteUser{
               context.delete(userss)
            }
            try context.save()
            print("user deleted successfully")
        } catch{
            print("cant delete user",error)
        }
    }
}
//MARK: UITextViewDelegate
extension AddTasksVC: UITextViewDelegate{
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == "" {
            textView.text = "Enter Description"
            textView.textColor = UIColor.lightGray
        }
    }
}
//MARK: UICollectionViewDataSource, UICollectionViewDelegate
extension AddTasksVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("uaers--------",users.count)
        return users.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddTaskCell", for: indexPath) as! AddTaskCell
        cell.lblUser.text = users[indexPath.item]
        cell.btnClose.tag = indexPath.item
        cell.btnClose.addTarget(self, action: #selector(deleteUser), for: .touchUpInside)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let name = users[indexPath.item]
//        let size = (name as String).size(withAttributes: [.font: UIFont.systemFont(ofSize: 15)])
        return CGSize(width: 100, height: 30)
    }
}
//MARK: UITextFieldDelegate
extension AddTasksVC: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        addUserFromTextField()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.addDoneOnKeyboard(withTarget: self, action: #selector(didPressOnDontBtn))
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.addDoneOnKeyboard(withTarget: self, action: #selector(didPressOnDontBtn))
    }
}
//MARK: Click Events
extension AddTasksVC{
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    @IBAction func onClickAddTask(_ sender: UIButton) {
        if validateFields(){
            guard let titlee = txtTitle.text, !titlee.isEmpty else{
                print("error in title")
                return
            }
            guard let desc = txtDesc.text, !desc.isEmpty else{
                print("error in desc")
                return
            }
            guard let assign = txtAssign.text, !assign.isEmpty else{
                print("erro in assign")
                return
            }
            let id = "\(Int.random(in: 1000...9999))"
            let startDate = startDate.date
            let endDate = endDate.date
            
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
                return
            }
            let context = appDelegate.persistentContainer.viewContext
            
            let newTask = ToDoApp.TaskEntity(context: context)
            newTask.title = titlee
            newTask.desc = desc
            newTask.assignTo = assign
            newTask.startDate = startDate
            newTask.endDate = endDate
            newTask.taskID = id
            newTask.status = "Open"
            
            // ✅ Link assigned users to this task
                    for userName in users {
                        let user = ToDoApp.AssignedUsers(context: context)
                        user.name = userName
                        user.taskEntity = newTask  // This sets the relationship
                    }
            
            do{
                try context.save()
                self.dismiss(animated: true)
                navigationController?.popViewController(animated: true)
                showAlert(message: "Task added successfully")
                print("task added successfully",newTask)
                users = [] // Reset the users array
                cvAssignedUsers.reloadData() // Reload the collection view to reflect the changes
            } catch{
                print("failed to add task:----",error)
            }
        }
    }
}
