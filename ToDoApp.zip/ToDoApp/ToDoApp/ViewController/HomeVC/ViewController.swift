//
//  ViewController.swift
//  ToDoApp
//
//  Created by Hemaxi S on 06/05/25.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    //MARK: Outlet and Variable Declaration
    @IBOutlet weak var tblTasks: UITableView!
    @IBOutlet weak var lblNoTask: UILabel!
    
     var tasks: [(id: String?,title: String, startDate: Date, endDate: Date, status: String, desc: String, assignTo: String)] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUP()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchTasks()
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
}
//MARK: Setup UI
extension ViewController{
    func setUP(){
        let nibName = UINib(nibName: "TaskCell", bundle: nil)
        tblTasks.register(nibName, forCellReuseIdentifier: "TaskCell")
    }
}
//MARK: Custom Functions
extension ViewController{
    func fetchTasks(){
        lblNoTask.isHidden = true
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{return}
        let context = appDelegate.persistentContainer.viewContext
        
        tasks.removeAll()
        
        let tasksFetch: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
        do{
            let taskResults = try context.fetch(tasksFetch)
            
            for taskk in taskResults{
                 let id = taskk.taskID ?? "0"
                let title = taskk.title ?? "no title"
                let desc = taskk.desc ?? "no desc"
                let endDate = taskk.endDate ?? Date()
                let startDate = taskk.startDate ?? Date()
                let status = taskk.status ?? "no status"
//                let assign = taskk.assignTo ?? "no user assigned"
                var assignedUserNames: [String] = []
                if let usersSet = taskk.assigneUsers as? Set<AssignedUsers> {
                    // Remove duplicates by converting Set to Array, then back to Set
                    assignedUserNames = Array(Set(usersSet.compactMap { $0.name }))
                    print("Assigned Users for task \(title): \(assignedUserNames)")
                }
                    
                    // Combine user names as string for display
                    let assignedUsersString = assignedUserNames.joined(separator: ", ")
                
                tasks.append((id: id,title: title, startDate: startDate, endDate: endDate, status: status, desc: desc, assignTo: assignedUsersString))
            }
            tasks.sort { $0.startDate > $1.startDate }
            DispatchQueue.main.async{
                self.tblTasks.reloadData()
            }
        } catch{
            print("Error in fetching tasks-----",error)
        }
    }
     func updateStatusInCoreData(){
         
     }
     func deleteUserFromCoreData(){
          
     }
}
//MARK: UITableViewDataSource, UITableViewDelegate
extension ViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell", for: indexPath) as! TaskCell
        let newTask = tasks[indexPath.row]
         cell.lblTitle.text = newTask.title
        cell.lblDesc.text = newTask.desc
         cell.lblStatus.text = newTask.status
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy"
        cell.lblDate.text = formatter.string(from: newTask.startDate)
        
        return cell
    }
     func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
          
          // action one
          let editAction = UITableViewRowAction(style: .default, title: "In Progress", handler: { (action, indexPath) in
               print("Edit tapped")
               let taskID = self.tasks[indexPath.row].id
               guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{return}
               let context = appDelegate.persistentContainer.viewContext
               
               let fetchReq: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
               fetchReq.predicate = NSPredicate(format: "taskID == %@", taskID! as CVarArg)
               do{
                    let results = try context.fetch(fetchReq)
                    if let taskToUpdate = results.first {
                         taskToUpdate.status = "In Progress"
                         try context.save()
                         print("Status updated to In Progress")
                         self.fetchTasks()
                    }
               } catch{
                    print("Error updating status: \(error)")
               }
          })
          editAction.backgroundColor = UIColor.blue
          
          // action two
          let deleteAction = UITableViewRowAction(style: .default, title: "Delete") { (action, indexPath) in
              print("Delete tapped")
              let taskID = self.tasks[indexPath.row].id
              guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
              let context = appDelegate.persistentContainer.viewContext

              let deleteReq: NSFetchRequest<TaskEntity> = TaskEntity.fetchRequest()
               deleteReq.predicate = NSPredicate(format: "taskID == %@", taskID! as CVarArg)

              let alert = UIAlertController(title: "Delete", message: "Do you want to delete this task?", preferredStyle: .alert)
              alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
              alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { _ in
                  do {
                      let results = try context.fetch(deleteReq)
                      if let taskToDelete = results.first {
                          context.delete(taskToDelete)
                          try context.save()
                          self.fetchTasks()
                          self.tblTasks.deleteRows(at: [indexPath], with: .none)
                          print("task deleted successfully")
                      }
                  } catch {
                      print("failed to delete task: \(error)")
                  }
              }))

              self.present(alert, animated: true, completion: nil)
          }
          deleteAction.backgroundColor = UIColor.red
          
          return [editAction, deleteAction]
     }
}
//MARK: Click Events
extension ViewController{
    @IBAction func onClickAddTasks(_ sender: UIButton) {
        let addtaskVC = storyboard?.instantiateViewController(withIdentifier: "AddTasksVC") as! AddTasksVC
        navigationController?.pushViewController(addtaskVC, animated: true)
    }
}
