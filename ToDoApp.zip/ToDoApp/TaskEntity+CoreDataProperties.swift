//
//  TaskEntity+CoreDataProperties.swift
//  
//
//  Created by Hemaxi S on 06/05/25.
//
//

import Foundation
import CoreData


extension TaskEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TaskEntity> {
        return NSFetchRequest<TaskEntity>(entityName: "TaskEntity")
    }

    @NSManaged public var title: String?
    @NSManaged public var desc: String?
    @NSManaged public var startDate: Date?
    @NSManaged public var endDate: Date?
    @NSManaged public var assignTo: String?
    @NSManaged public var status: String?
    @NSManaged public var taskID: String?
    @NSManaged public var assigneUsers: NSSet?

}

// MARK: Generated accessors for assigneUsers
extension TaskEntity {

    @objc(addAssigneUsersObject:)
    @NSManaged public func addToAssigneUsers(_ value: AssignedUsers)

    @objc(removeAssigneUsersObject:)
    @NSManaged public func removeFromAssigneUsers(_ value: AssignedUsers)

    @objc(addAssigneUsers:)
    @NSManaged public func addToAssigneUsers(_ values: NSSet)

    @objc(removeAssigneUsers:)
    @NSManaged public func removeFromAssigneUsers(_ values: NSSet)

}
