//
//  File.swift
//  CupidArrow
//
//  Created by Hemaxi S on 04/04/25.
//

import Foundation
/*

import UIKit

class FirstViewController: UIViewController {
    @IBOutlet weak var progressView: UIProgressView!
    var currentStep = 1

    override func viewDidLoad() {
        super.viewDidLoad()
        updateProgress(currentStep: currentStep, totalSteps: 5)
    }

    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressView.setProgress(progressValue, animated: true)
    }

    @IBAction func nextScreen(_ sender: UIButton) {
        let nextVC = SecondViewController()
        nextVC.currentStep = self.currentStep + 1
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
}


import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var progressView: UIProgressView!
    var currentStep = 2

    override func viewDidLoad() {
        super.viewDidLoad()
        updateProgress(currentStep: currentStep, totalSteps: 5)
    }

    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressView.setProgress(progressValue, animated: true)
    }

    @IBAction func nextScreen(_ sender: UIButton) {
        let nextVC = ThirdViewController()
        nextVC.currentStep = self.currentStep + 1
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
}
 
 
 import UIKit
 import CountryPickerView

 class SignUpVC: UIViewController {
     //MARK: Outlet and Variable Declaration
     @IBOutlet weak var progressBar: UIProgressView!
     @IBOutlet weak var txtPhone: UITextField!
     @IBOutlet weak var txtEnterPhone: UITextField!
     @IBOutlet weak var dropdownImg: UIImageView!
     let countryPicker = CountryPickerView()
     var currentStep = 1
     
     override func viewDidLoad() {
         super.viewDidLoad()
         setUP()
         countryPicker.delegate = self
     }
     
     override func viewWillAppear(_ animated: Bool) {
         super.viewWillAppear(animated)
         navigationController?.setNavigationBarHidden(true, animated: true)
     }
     
     override func viewWillDisappear(_ animated: Bool) {
         super.viewWillDisappear(animated)
         navigationController?.setNavigationBarHidden(true, animated: true)
     }
     
     @IBAction func onClickBackButton(_ sender: Any) {
         navigationController?.popViewController(animated: true)
     }
     
     @IBAction func onClickPhoneDropdown(_ sender: Any) {
         countryPicker.showCountriesList(from: self)
     }
     
     @IBAction func onClickContinueToOTP(_ sender: Any) {
         let otpVC = storyboard?.instantiateViewController(withIdentifier: "OTPVC") as? OTPVC
         otpVC?.currentStep = self.currentStep // Send the correct step
         navigationController?.pushViewController(otpVC!, animated: false)
     }
 }

 //MARK: SetUP UI
 extension SignUpVC{
     func setUP(){
         progressBar.transform = CGAffineTransformMakeScale(1, 2)
         txtPhone.borderStyle = .none
         txtEnterPhone.borderStyle = .none
         txtEnterPhone.keyboardType = .numberPad
         txtPhone.text = "+91"
         dropdownImg.image = UIImage(named: "India")
     }
 }

 //MARK: Custom Functions
 extension SignUpVC{
     func setCountyPickerView(){
         countryPicker.showPhoneCodeInView = true
         countryPicker.showCountryNameInView = false
         countryPicker.setCountryByPhoneCode("+91")
         
         txtPhone.text = countryPicker.selectedCountry.phoneCode
         dropdownImg.image = countryPicker.selectedCountry.flag
     }
     
     func updateProgress(currentStep: Int, totalSteps: Int) {
         let progressValue = Float(currentStep) / Float(totalSteps)
         progressBar.setProgress(progressValue, animated: true)
     }
 }

 //MARK: CountryPickerViewDelegate
 extension SignUpVC: CountryPickerViewDelegate{
     func countryPickerView(_ countryPickerView: CountryPickerView, didSelectCountry country: Country) {
         txtPhone.text = country.phoneCode  // Set phone code
         dropdownImg.image = country.flag   // Set country flag
     }
 }

 import UIKit

 class OTPVC: UIViewController {
     //MARK: Outlet and Variable Declaration
     @IBOutlet weak var progressBar: UIProgressView!
     var currentStep = 2 // Default to 2 but update properly in viewDidLoad
     
     override func viewDidLoad() {
         super.viewDidLoad()
         setUp()
         updateProgress(currentStep: currentStep, totalSteps: 5) // Update progress bar with currentStep
     }
     
     @IBAction func onClickBack(_ sender: Any) {
         navigationController?.popViewController(animated: false)
     }
 }

 //MARK: SetUP UI
 extension OTPVC {
     func setUp() {
         // Scaling the progress bar (optional)
         progressBar.transform = CGAffineTransformMakeScale(1, 2)
         
         // Apply corner radius to the progressBar
         progressBar.layer.cornerRadius = 5
         progressBar.clipsToBounds = true
         
         // Optional: Apply a corner radius to the track layer for more rounded effect
         progressBar.subviews.forEach { subview in
             subview.layer.cornerRadius = 5
             subview.clipsToBounds = true
         }
     }
     
     func updateProgress(currentStep: Int, totalSteps: Int) {
         let progressValue = Float(currentStep) / Float(totalSteps)
         progressBar.setProgress(progressValue, animated: true)
     }
 }

 let rowHeight = pickerView.frame.height * 0.1  // Row height is 10% of picker view height
 (i == 0 ? -rowHeight / 2 : rowHeight / 2):

 This is a conditional (ternary) operator. It checks if i == 0 (i.e., if the index i is 0).

 If i == 0 is true, then it subtracts rowHeight / 2 from the center (pickerView.frame.height / 2), meaning it moves the row upwards.

 If i != 0, it adds rowHeight / 2 to the center, meaning it moves the row downwards.

 This ensures that the first row is positioned above the center and subsequent rows are positioned below the center, adjusting for the height of the rows.

 In summary:
 The line calculates the y position (vertical position) for each row in the picker view.

 If i == 0, the row is positioned above the center, and for all other rows (i != 0), it is positioned below the center.
*/
