//
//  OTPVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 04/04/25.
//

import UIKit
import OTPFieldView

class OTPVC: UIViewController {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var otpView: OTPFieldView!
    @IBOutlet weak var btnResendCode: UIButton!
    var currentStep = 2
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        updateProgress(currentStep: currentStep, totalSteps: 9)
        implementOtpView()
    }
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onClickVerify(_ sender: Any) {
        let nameandEmailVc = storyboard?.instantiateViewController(withIdentifier: "NameAndEmailVC") as? NameAndEmailVC
        nameandEmailVc?.currentStep = self.currentStep + 1
        navigationController?.pushViewController(nameandEmailVc!, animated: false)
    }
}
//MARK: SetUP UI
extension OTPVC{
    func setUp() {
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Functions
extension OTPVC{
    func implementOtpView(){
        self.otpView.fieldsCount = 4

        self.otpView.defaultBorderColor = .black
      
        self.otpView.backgroundColor = .clear
        self.otpView.defaultBorderColor = .clear
        self.otpView.fieldFont = UIFont.systemFont(ofSize: 30)
        self.otpView.filledBackgroundColor = .white
        self.otpView.requireCursor = false
        self.otpView.fieldSize = 63
        self.otpView.separatorSpace = 20
        self.otpView.toolbarPlaceholder = "-"
        self.otpView.shouldAllowIntermediateEditing = true
        self.otpView.delegate = self
     
//        self.otpView.secureEntry = false
//        self.otpView.secureEntry = true
        //self.otpView.secureCharacter = "-"
        //self.otpView.filledBackgroundColor = .black
        self.otpView.defaultBackgroundColor = .white
        self.otpView.initializeUI()
        //  Set placeholder
        for textField in otpView.subviews.compactMap({ $0 as? UITextField }) {//gets all subviews inside otpView,  tries to cast each subview to UITextField.
            textField.placeholder = "-"
            textField.textAlignment = .center
            textField.textColor = .black
        }
        let attributedString = NSAttributedString(
            string: "Resend Code",
            attributes: [
                .underlineStyle: NSUnderlineStyle.single.rawValue,
                .foregroundColor: UIColor.btn,
                .font: UIFont.boldSystemFont(ofSize: 18)
            ]
        )
        btnResendCode.setAttributedTitle(attributedString, for: .normal)
    }
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
    
}
//MARK: OTPFieldDelgate
extension OTPVC: OTPFieldViewDelegate{
//    Show keyboard automatically.
    func shouldBecomeFirstResponderForOTP(otpTextFieldIndex index: Int) -> Bool {
        return true
    }
    
    func enteredOTP(otp: String) {
       // handlePinEntry(otp)
        //implementOtpView()
        print(otp)
    }
    
    func hasEnteredAllOTP(hasEnteredAll: Bool) -> Bool {
        print("entered OTP: \(hasEnteredAll)")
        return false
    }
}
