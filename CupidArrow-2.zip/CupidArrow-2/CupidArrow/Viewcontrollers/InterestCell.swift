//
//  InterestCell.swift
//  CupidArrow
//
//  Created by admin on 07/04/25.
//

import UIKit

class InterestCell: UICollectionViewCell {
//MARK: Outlet and Variable Declaration
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var interestImg: UIImageView!
    @IBOutlet weak var lblInterest: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
