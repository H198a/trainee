//
//  AgeVC.swift
//  CupidArrow
//
//  Created by Hemaxi S on 04/04/25.
//

import UIKit

class AgeVC: UIViewController {
//MARK: Outlet and variable Declatation
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var pickerView: UIPickerView!
    var currentStep = 5
    var selectedRow = 3
    var arrPckerViewData = Array(18...70).map { "\($0)" }
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        updateProgress(currentStep: currentStep, totalSteps: 9)
        addHighlightLines()
        DispatchQueue.main.async {
            // reload only the specific component
            
            
            // select the row immediately with the updated styling
            self.pickerView.selectRow(self.selectedRow, inComponent: 0, animated: false)
        }
        pickerView.subviews[1].backgroundColor = UIColor.clear//clear background color of selected age
        // Do any additional setup after loading the view.
    }

}
extension AgeVC{
    func setUp() {
        // Scaling the progress bar (optional, as per your code)
        progressBar.transform = CGAffineTransformMakeScale(1, 2)
        
        // Apply corner radius to the progressBar
        progressBar.layer.cornerRadius = 5
        progressBar.clipsToBounds = true
        
        // Optional: Apply a corner radius to the track layer for more rounded effect
        progressBar.subviews.forEach { subview in
            subview.layer.cornerRadius = 5
            subview.clipsToBounds = true
        }
    }
}
//MARK: Custom Function
extension AgeVC{
    func updateProgress(currentStep: Int, totalSteps: Int) {
        let progressValue = Float(currentStep) / Float(totalSteps)
        progressBar.setProgress(progressValue, animated: false)
    }
    func addHighlightLines() {
        let lineHeight: CGFloat = 4
        let lineWidth: CGFloat = 110  //Desired width
        let rowHeight: CGFloat = pickerView.rowSize(forComponent: 0).height
//        let rowHeight = pickerView.frame.height * 0.1  // Row height is 10% of picker view height
        let pickerWidth = pickerView.bounds.width

        for i in 0...1 {
//       The line calculates the y position (vertical position) for each row in the picker view.
            let y = pickerView.frame.height / 2 + (i == 0 ? -rowHeight / 2 : rowHeight / 2)

            //Calculate x to center the line
            let x = (pickerWidth - lineWidth) / 2

            //Create the line view
            let line = UIView(frame: CGRect(x: x, y: y, width: lineWidth, height: lineHeight))
            line.backgroundColor = .btn
            line.isUserInteractionEnabled = false
            pickerView.addSubview(line)
        }
    }
}

//MARK: UIPickerViewDatasource, Delegate
extension AgeVC: UIPickerViewDataSource, UIPickerViewDelegate{
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 20 /*arrPckerViewData.count*/
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrPckerViewData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 60  //Make the row height big
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedRow = row
        DispatchQueue.main.async {
            // reload only the specific component
            pickerView.reloadComponent(component)
            
            // select the row immediately with the updated styling
            pickerView.selectRow(self.selectedRow, inComponent: component, animated: false)
        }
    }
    
//    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
//        let title = arrPckerViewData[row]
//        return NSAttributedString(string: title, attributes: [
//            .font: UIFont.systemFont(ofSize: 120),  //Make the font big
//            .foregroundColor: UIColor.btn
//        ])
//    }
    //Set label of selected date
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = UILabel()
        label.text = arrPckerViewData[row]
        label.textAlignment = .center
        label.backgroundColor = .clear
        
        let distance = abs(row - selectedRow)//calculate distance between row and selected row
        
        // Set font size based on distance from selected row
        if distance == 0 {
            label.font = UIFont.boldSystemFont(ofSize: 50)  // Selected row
            label.textColor = .btn
        } else if distance == 1 {
            label.font = UIFont.systemFont(ofSize: 40)  // 1 position away
            label.textColor = .black
        } else if distance == 2 {
            label.font = UIFont.systemFont(ofSize: 30)  // 2 positions away
            label.textColor = .black
        } else if distance == 3 {
            label.font = UIFont.systemFont(ofSize: 20)  // 3 positions away
            label.textColor = .black
        } else if distance == 4 {
            label.font = UIFont.systemFont(ofSize: 10)  // 4 positions away
        } else {
            label.font = UIFont.systemFont(ofSize: 5)  // 5 or more positions away
        }
        
        // Set text color for all rows
        //label.textColor = .black
        
        return label
    }


}
//MARK: Click Events
extension AgeVC{
    
    @IBAction func onClickContinue(_ sender: Any) {
        let genderVC = storyboard?.instantiateViewController(withIdentifier: "GenderVC") as? GenderVC
        genderVC?.currentStep = self.currentStep + 1
        navigationController?.pushViewController(genderVC!, animated: false)
    }
    
    @IBAction func onClickBack(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
}

